# AVM streamed music

AVM plays signed PCM8 music at exactly **15,625 samples/s**, using mixed
one/two-bit prediction with **256-sample independent frames**. The native
oscillator sequencer, synthesized score format, sound effects, direct tones,
and selectable synthesis rates have been removed.

## Runtime API

Include `<avm/audio.h>` or `<avm.h>`:

```c
avm_audio_play(song);        /* replaces the current track; enables output */
avm_audio_pause();           /* freezes compressed position and histories */
avm_audio_resume();
avm_audio_volume(128);       /* unity; 0=mute, 255=255/128 gain */
avm_audio_music_volume(64);  /* same gain control; half amplitude */
avm_audio_stop();            /* ends playback, leaves output enabled */
avm_audio_disable();         /* stops playback and releases timers/pins */
avm_audio_enable();          /* enables silent output without restarting */
uint8_t status = avm_audio_status(); /* 0 stopped, 1 playing, 2 paused */
```

No guest update calls or guest RAM buffers are required. Pause/resume retains
the current frame, bit position, histories, and remaining sample count. Muting
continues decoding. The default gain is 128 (unity), changed from the old
synthesizer's 32=unity convention. Gain uses floor(sample * volume / 128),
saturates to [-128,127], and never affects predictor history.

`avm_audio_sfx`, `avm_audio_stop_sfx`, `avm_audio_sfx_volume`, `avm_audio_tone`,
and `avm_audio_rate` are no longer declared or linked. Their old SYS command
numbers are reserved and ignored. Existing A4/C1/C2/C3 assets must be replaced.
The historical `avm_music.py` score compiler remains an offline tool only.

## Native asset generation

The standard-library-only SDK packer accepts mixed-256 AVAX v1 files from
the codec evaluation harness. It validates every frame, exact sample count,
padding, payload bounds, rate, and the canonical scale table. It copies the
compressed payload without re-encoding or changing any reconstructed samples:

```sh
python tools/avm_audio_pack.py song.avax song.avm --loop
python tools/avm_audio_pack.py song.avax song.h --loop --name song
```

Omit `--loop` for one-shot music. Generated C headers use byte-aligned uint64
chunks in program memory, supporting assets larger than 64 KiB without
widening code pointers. The packer is installed in `<sdk>/bin`.

The AVM1 header is 12 bytes:

| Offset | Bytes | Meaning |
|---:|---:|---|
| 0 | 4 | ASCII `AVM1` |
| 4 | 3 | Little-endian compressed payload length (uint24, nonzero) |
| 7 | 1 | Flags: bit 0 loops; all other bits zero |
| 8 | 4 | Little-endian output sample count (uint32, nonzero) |
| 12 | length | Unchanged mixed-256 frame payload |

The sample rate, frame size, and scale table are fixed by this format. Compared
with the evaluation container it saves 22 bytes and adds an explicit payload
length and loop flag. FX addresses and lengths remain 24 bits; output counts
are 32 bits to support recordings longer than 65,535 samples.

## Frame decoder

Each frame begins with a signed seed byte and a parameter byte:

| Parameter bits | Meaning |
|---|---|
| 7..6 | 0=hold, 1=one-bit residual, 2=two-bit residual; 3 invalid |
| 5..4 | 0=previous sample, 1=linear extrapolation, 2=half slope; 3 invalid |
| 3..0 | Index into scales `1,2,3,4,5,6,8,10,12,15,18,22,26,31,36,42` |

A hold frame requires parameter 0. Its seed repeats for the whole frame.
Other frames emit the seed once, initialize both histories to it, and decode
255 residuals (fewer in the final partial frame). One-bit codes select -S,+S;
two-bit codes select -3S,-S,+S,+3S. Codes are packed least-significant bit
first. Frame padding is zero and each frame starts at a byte boundary.

Prediction uses signed 16-bit intermediates. Linear extrapolation is
`previous + (previous - older)`; half slope is
`previous + floor((previous - older) / 2)`. Add the residual before saturating
once to [-128,127], then update reconstructed histories. The runtime never
uses source PCM history. A partial final frame stops at the exact uint32
sample count; looping discards its unused padding and starts the next seed.

## Streaming and peripherals

Timer1 COMPA emits the held sample at a fixed 14-cycle body latency, then
decodes its successor. OCR1A=127 and prescaler=8 give a 1024 CPU-cycle period
at 16 MHz. Timer4 retains differential PC6/PC7 PWM with its 250 kHz carrier.
Timer0 independently maintains the 1 kHz millisecond clock. Timer1 phase
alignment to Timer0 is preserved.

Only the foreground reads FX, at interpreter stream restarts and idle wakeups.
The ISR consumes a **64-byte compressed ring**, requests refill at <=32 bytes,
and never uses SPI or a decoded PCM buffer. Independent uint8 producer/consumer
heads publish complete chunks atomically; foreground reads are interruptible,
at most 32 bytes, split at ring wrap and payload end. Looping may prefetch the
beginning before the final samples finish, so no foreground rewind is required
at the output boundary. Reads never extend beyond the declared payload.

Persistent state occupies **99 bytes**, including the ring (35 bytes of control
and decoder state). The scale table occupies 16 firmware bytes. A temporary
12-byte header aliases the existing foreground service workspace. The ISR
preserves all interrupted registers, SREG, and the guest flags, including when
native libm temporarily borrows the usual zero register.

On compressed-buffer underrun the player emits silence and freezes decoding
until data arrives; its saturating diagnostic counter records the event. Bad
native headers, unsupported frame parameters, and nonzero frame padding fail
closed. As with other program-memory APIs, the caller must supply a valid
asset pointer and a truthful header; the offline packer validates file bounds.

## Validation

Build and run the native Ardens checks in RelWithDebInfo:

```sh
cmake --build build --config RelWithDebInfo --target avm_audio_tests_run
python -m pytest tools/tests tests/audio/test_score.py -q
```

Native tests compare the actual AVR ISR's samples against an independent scalar
decoder for all widths, predictors and scales, saturation, partial frames,
ring/uint8-head/24-bit address wrap, exact one-shot endings, and loops. They also
decode both complete RPG recordings twice, exercise C/C++ exports beyond 64 KiB,
and run autonomous playback during animation, libm and formatted output.
RPG integration tests cover the two-song selection and pause/resume menu.
Measured timing and resource results are recorded in [audio-benchmarks.md](audio-benchmarks.md).
