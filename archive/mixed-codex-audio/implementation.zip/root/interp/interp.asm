;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Interpreter
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; avr-libc/libm-derived floating-point snippets
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; The BSD-licensed notice below applies to the portions of this file derived
; from avr-libc/libm. It is included here because those routines are embedded
; directly in the interpreter for local optimization and manual relaxation.
;
; Copyright (c) 2002  Michael Stumpf  <mistumpf@de.pepperl-fuchs.com>
; Copyright (c) 2005  Dmitry Xmelkov
; Copyright (c) 2006  Dmitry Xmelkov
; Copyright (c) 2025  Georg-Johann Lay
; All rights reserved.
;
; Redistribution and use in source and binary forms, with or without
; modification, are permitted provided that the following conditions are met:
;
; * Redistributions of source code must retain the above copyright
;   notice, this list of conditions and the following disclaimer.
; * Redistributions in binary form must reproduce the above copyright
;   notice, this list of conditions and the following disclaimer in
;   the documentation and/or other materials provided with the
;   distribution.
; * Neither the name of the copyright holders nor the names of
;   contributors may be used to endorse or promote products derived
;   from this software without specific prior written permission.
;
; THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
; AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
; IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
; ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR CONTRIBUTORS BE
; LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR
; CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF
; SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
; INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN
; CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE)
; ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
; POSSIBILITY OF SUCH DAMAGE.


;; SRAM:
;;     0x0100–0x04FF  static storage (.saved + .data, including zero-initialized bytes)
;;     0x0500–0x08FF  framebuffer
;;     0x0900–0x09FF  VM stack
;;     0x0A00-0x0A03  FX image/save page
;;     0x0A04         startup flags
;;     0x0A05–0x0A08  millisecond counter (little-endian uint32)
;;     0x0A09–0x0A0B  selected raw sprite pointer (little-endian uint24)
;;     0x0A0C–0x0A0D  selected sprite width and height
;;     0x0A0E–0x0A14  selected text glyph-table base/header/mode
;;     0x0A15–0x0A77  persistent audio state (99 bytes)
;;     0x0A78–0x0ABF  aliased formatter/text or audio service workspace
;;     ...–0x0AFF       remaining interpreter-private / native hardware stack

#define data_globals    0x0100
#define data_display    0x0500
#define data_stack      0x0900
#define data_page_data      0x0A00
#define data_page_save      (data_page_data+2)
#define data_startup_flags  (data_page_save+2)
#define data_millis         (data_startup_flags+1)
#define data_sprite_ptr         (data_millis+4)
#define data_sprite_width       (data_sprite_ptr+3)
#define data_sprite_height      (data_sprite_width+1)
#define data_text_glyph_table   (data_sprite_height+1)
#define data_text_line_height   (data_text_glyph_table+3)
#define data_text_glyph_first   (data_text_line_height+1)
#define data_text_num_glyphs    (data_text_glyph_first+1)
#define data_text_mode          (data_text_num_glyphs+1)

; Music decoder: a 64-byte compressed ring and 35 bytes of persistent state.
; Producer and consumer publish independent uint8 heads; their difference is
; bounded by 64. FX cursors and lengths remain uint24 throughout.
#define data_audio_begin             (data_text_mode+1)
#define data_audio_ticks_pending     (data_audio_begin+0)
#define data_audio_volume            (data_audio_begin+1)
#define data_audio_status            (data_audio_begin+2)
#define data_audio_flags             (data_audio_begin+3)
#define data_audio_read              (data_audio_begin+4)
#define data_audio_write             (data_audio_begin+5)
#define data_audio_cursor            (data_audio_begin+6)
#define data_audio_start             (data_audio_begin+9)
#define data_audio_bytes             (data_audio_begin+12)
#define data_audio_length            (data_audio_begin+15)
#define data_audio_remaining         (data_audio_begin+18)
#define data_audio_total             (data_audio_begin+22)
#define data_audio_frame_left        (data_audio_begin+26)
#define data_audio_parameter         (data_audio_begin+27)
#define data_audio_step              (data_audio_begin+28)
#define data_audio_previous          (data_audio_begin+29)
#define data_audio_older             (data_audio_begin+30)
#define data_audio_bits              (data_audio_begin+31)
#define data_audio_bit_count         (data_audio_begin+32)
#define data_audio_sample            (data_audio_begin+33)
#define data_audio_underruns         (data_audio_begin+34)
#define data_audio_ring              (data_audio_begin+35)
#define data_audio_end               (data_audio_ring+64)

.if (data_audio_end - data_audio_begin) != 99
    .error "audio persistent SRAM must occupy 99 bytes"
.endif
.if (data_audio_begin >> 8) != ((data_audio_end-1) >> 8)
    .error "audio compact pointers must fit in one SRAM page"
.endif

#define data_end_private             data_audio_end
#define data_audio_header            data_end_private

; Native formatter workspace. This storage is valid only while VS(N)PRINTF is
; executing; future nonreentrant SYS services may alias the same range.
#define data_format_program_cache       (data_end_private+0)
#define data_format_program_next        (data_end_private+16)
#define data_format_cache_index         (data_end_private+19)
#define data_format_cache_length        (data_end_private+20)
; Formatter status remains in native r17 for the complete call.
#define data_format_digit_buffer        (data_end_private+21)
#define data_format_progstr_original    (data_end_private+33)
#define data_format_string_original     data_format_progstr_original
#define data_format_progstr_cursor      (data_end_private+36)
#define data_format_string_length       (data_end_private+39)
#define data_format_ram_ptr             (data_end_private+41)
#define data_format_arg_ptr             (data_end_private+43)
#define data_format_padding             (data_end_private+45)
#define data_format_precision_zeroes    (data_end_private+47)
#define data_format_digit_count         (data_end_private+49)
#define data_format_sign                (data_end_private+50)
#define data_format_conversion          (data_end_private+51)
#define data_format_value_nonzero       (data_end_private+52)
#define data_format_integer_mode        (data_end_private+53)
#define data_format_prefix              (data_end_private+54)
#define data_format_read_source         (data_end_private+55)
#define data_format_float_value         (data_end_private+58)
#define data_format_float_exponent      (data_end_private+62)
#define data_format_float_ndigits       (data_end_private+64)
#define data_format_float_flags         (data_end_private+65)
#define data_format_float_precision     (data_end_private+66)
#define data_format_scratch_end         (data_end_private+68)

; Text drawing aliases the formatter workspace and extends it with cursor and
; glyph-record state. Formatted text needs both areas simultaneously, so this
; suffix must not overlap the formatter fields above.
#define data_text_initial_x              (data_format_scratch_end+0)
#define data_text_current_y              (data_format_scratch_end+2)
#define data_text_scratch_end            (data_format_scratch_end+4)

.if data_text_scratch_end > (0x0B00-48)
    .error "Formatter/text workspace must leave at least 48 bytes for native stack"
.endif

#define FORMAT_STATUS_SOURCE_PROGRAM 0
#define FORMAT_STATUS_SIZE_NONZERO   1
#define FORMAT_STATUS_COUNT_OVERFLOW 2
#define FORMAT_STATUS_FATAL_ERROR    3
#define FORMAT_STATUS_SINK_TEXT      4
#define FORMAT_STATUS_SINK_DEBUG     5

#define FORMAT_FLAG_LEFT             0
#define FORMAT_FLAG_PLUS             1
#define FORMAT_FLAG_SPACE            2
#define FORMAT_FLAG_ALT              3
#define FORMAT_FLAG_ZERO             4
#define FORMAT_FLAG_PRECISION        5
#define FORMAT_FLAG_WIDTH_STAR       6
#define FORMAT_FLAG_PRECISION_STAR   7

#define FORMAT_LENGTH_DEFAULT        0
#define FORMAT_LENGTH_HH             1
#define FORMAT_LENGTH_H              2
#define FORMAT_LENGTH_L              3
#define FORMAT_LENGTH_Z              4
#define FORMAT_LENGTH_T              5

#define FORMAT_INT_BASE_MASK         0x03
#define FORMAT_INT_BASE_DEC          0
#define FORMAT_INT_BASE_OCT          1
#define FORMAT_INT_BASE_HEX          2
#define FORMAT_INT_SIGNED_BIT        2
#define FORMAT_INT_UPPER_BIT         3

#define FORMAT_PREFIX_NONE           0
#define FORMAT_PREFIX_OCTAL          1
#define FORMAT_PREFIX_HEX_LOWER      2
#define FORMAT_PREFIX_HEX_UPPER      3

#define FORMAT_FTOA_MINUS            1
#define FORMAT_FTOA_ZERO             2
#define FORMAT_FTOA_INF              4
#define FORMAT_FTOA_NAN              8
#define FORMAT_FTOA_CARRY            16

#define STARTUP_SAVE_PAGE_VALID  0


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Hardware configuration
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Select at most one complete device preset on the assembler command line:
;
;   -DAVM_DEVICE_ARDUBOY_FX    Arduboy FX; FX chip select is SDA/PD1.
;   -DAVM_DEVICE_ARDUBOY_MINI  Arduboy Mini; FX chip select is HWB/PE2.
;   -DAVM_DEVICE_ARDUBOY_FXC   Arduboy FX-C; FX chip select is HWB/PE2.
;
; AVM_DEVICE_ARDUBOY_FX is the default so existing builds retain their current
; flash wiring. Presets provide defaults only: any individual AVM_* definition
; supplied by the build overrides the corresponding preset/default value.
;
; Supported SPI display controller selections (choose at most one):
;
;   -DAVM_DISPLAY_SSD1306      Default for all standard device presets.
;   -DAVM_DISPLAY_SSD1309
;   -DAVM_DISPLAY_SH1106
;   -DAVM_OLED_CONTRAST=value  Default: 0xCF.
;
; Arduboy2-compatible OLED_SSD1306, OLED_SSD1309, OLED_SH1106, and
; OLED_CONTRAST definitions are also accepted. I2C display definitions are
; intentionally rejected; this interpreter startup supports SPI displays only.
;
; Pin overrides are triples consisting of PORT, DDR, and bit definitions:
;
;   AVM_OLED_CS_PORT / AVM_OLED_CS_DDR / AVM_OLED_CS_BIT
;   AVM_OLED_DC_PORT / AVM_OLED_DC_DDR / AVM_OLED_DC_BIT
;   AVM_OLED_RST_PORT / AVM_OLED_RST_DDR / AVM_OLED_RST_BIT
;   AVM_FX_PORT / AVM_FX_DDR / AVM_FX_BIT
;   AVM_BUTTON_{LEFT,RIGHT,UP,DOWN,A,B}_{PIN,PORT,DDR,BIT}
;   AVM_LED_{RED,GREEN,BLUE,TX,RX}_{PORT,DDR,BIT}
;   AVM_RANDOM_SEED_PORT / AVM_RANDOM_SEED_DDR / AVM_RANDOM_SEED_BIT
;
; The hardware SPI pins are fixed by the ATmega32U4: PB1=SCK, PB2=MOSI, and
; PB3=MISO. Set AVM_INIT_RGB_LED or AVM_INIT_TX_RX_LEDS to 0 to omit those
; outputs. Set AVM_INIT_BUTTONS or AVM_INIT_RANDOM_SEED_ADC to 0 to omit those
; inputs. Startup resets and configures the OLED controller, clears the
; framebuffer, and performs one display update so controller RAM starts blank.
; Later framebuffer transfers are performed by SYS display.

#if !defined(AVM_DEVICE_ARDUBOY_FX) && \
    !defined(AVM_DEVICE_ARDUBOY_MINI) && \
    !defined(AVM_DEVICE_ARDUBOY_FXC)
#  define AVM_DEVICE_ARDUBOY_FX
#endif

#if (defined(AVM_DEVICE_ARDUBOY_FX) + \
     defined(AVM_DEVICE_ARDUBOY_MINI) + \
     defined(AVM_DEVICE_ARDUBOY_FXC)) > 1
#  error "Select only one AVM_DEVICE_* preset"
#endif

; Normalize Arduboy2/homemade display-selection names.
#if defined(OLED_SSD1306) && !defined(AVM_DISPLAY_SSD1306)
#  define AVM_DISPLAY_SSD1306
#endif
#if defined(OLED_SSD1309) && !defined(AVM_DISPLAY_SSD1309)
#  define AVM_DISPLAY_SSD1309
#endif
#if defined(OLED_SH1106) && !defined(AVM_DISPLAY_SH1106)
#  define AVM_DISPLAY_SH1106
#endif

#if defined(OLED_SSD1306_I2C) || defined(OLED_SSD1306_I2CX) || \
    defined(OLED_SH1106_I2C) || defined(AVM_DISPLAY_I2C)
#  error "I2C displays are not supported by interpreter startup"
#endif

#if !defined(AVM_DISPLAY_SSD1306) && \
    !defined(AVM_DISPLAY_SSD1309) && \
    !defined(AVM_DISPLAY_SH1106)
#  define AVM_DISPLAY_SSD1306
#endif

#if (defined(AVM_DISPLAY_SSD1306) + \
     defined(AVM_DISPLAY_SSD1309) + \
     defined(AVM_DISPLAY_SH1106)) > 1
#  error "Select only one SPI AVM_DISPLAY_* controller"
#endif

#ifndef AVM_OLED_CONTRAST
#  ifdef OLED_CONTRAST
#    define AVM_OLED_CONTRAST OLED_CONTRAST
#  else
#    define AVM_OLED_CONTRAST 0xCF
#  endif
#endif

#ifndef AVM_INIT_RGB_LED
#  define AVM_INIT_RGB_LED 1
#endif
#ifndef AVM_INIT_TX_RX_LEDS
#  define AVM_INIT_TX_RX_LEDS 1
#endif
#ifndef AVM_INIT_BUTTONS
#  define AVM_INIT_BUTTONS 1
#endif
#ifndef AVM_INIT_RANDOM_SEED_ADC
#  define AVM_INIT_RANDOM_SEED_ADC 1
#endif

; Common OLED wiring for the supported device presets.
#ifndef AVM_OLED_CS_PORT
#  define AVM_OLED_CS_PORT PORTD
#endif
#ifndef AVM_OLED_CS_DDR
#  define AVM_OLED_CS_DDR DDRD
#endif
#ifndef AVM_OLED_CS_BIT
#  define AVM_OLED_CS_BIT PORTD6
#endif

#ifndef AVM_OLED_DC_PORT
#  define AVM_OLED_DC_PORT PORTD
#endif
#ifndef AVM_OLED_DC_DDR
#  define AVM_OLED_DC_DDR DDRD
#endif
#ifndef AVM_OLED_DC_BIT
#  define AVM_OLED_DC_BIT PORTD4
#endif

#ifndef AVM_OLED_RST_PORT
#  define AVM_OLED_RST_PORT PORTD
#endif
#ifndef AVM_OLED_RST_DDR
#  define AVM_OLED_RST_DDR DDRD
#endif
#ifndef AVM_OLED_RST_BIT
#  define AVM_OLED_RST_BIT PORTD7
#endif

; Device-specific serial-flash chip select.
#ifndef AVM_FX_PORT
#  if defined(AVM_DEVICE_ARDUBOY_FX)
#    define AVM_FX_PORT PORTD
#  else
#    define AVM_FX_PORT PORTE
#  endif
#endif
#ifndef AVM_FX_DDR
#  if defined(AVM_DEVICE_ARDUBOY_FX)
#    define AVM_FX_DDR DDRD
#  else
#    define AVM_FX_DDR DDRE
#  endif
#endif
#ifndef AVM_FX_BIT
#  if defined(AVM_DEVICE_ARDUBOY_FX)
#    define AVM_FX_BIT PORTD1
#  else
#    define AVM_FX_BIT PORTE2
#  endif
#endif

; Common button wiring for the supported device presets.
#ifndef AVM_BUTTON_LEFT_PIN
#  define AVM_BUTTON_LEFT_PIN PINF
#endif
#ifndef AVM_BUTTON_LEFT_PORT
#  define AVM_BUTTON_LEFT_PORT PORTF
#endif
#ifndef AVM_BUTTON_LEFT_DDR
#  define AVM_BUTTON_LEFT_DDR DDRF
#endif
#ifndef AVM_BUTTON_LEFT_BIT
#  define AVM_BUTTON_LEFT_BIT PORTF5
#endif
#ifndef AVM_BUTTON_RIGHT_PIN
#  define AVM_BUTTON_RIGHT_PIN PINF
#endif
#ifndef AVM_BUTTON_RIGHT_PORT
#  define AVM_BUTTON_RIGHT_PORT PORTF
#endif
#ifndef AVM_BUTTON_RIGHT_DDR
#  define AVM_BUTTON_RIGHT_DDR DDRF
#endif
#ifndef AVM_BUTTON_RIGHT_BIT
#  define AVM_BUTTON_RIGHT_BIT PORTF6
#endif
#ifndef AVM_BUTTON_UP_PIN
#  define AVM_BUTTON_UP_PIN PINF
#endif
#ifndef AVM_BUTTON_UP_PORT
#  define AVM_BUTTON_UP_PORT PORTF
#endif
#ifndef AVM_BUTTON_UP_DDR
#  define AVM_BUTTON_UP_DDR DDRF
#endif
#ifndef AVM_BUTTON_UP_BIT
#  define AVM_BUTTON_UP_BIT PORTF7
#endif
#ifndef AVM_BUTTON_DOWN_PIN
#  define AVM_BUTTON_DOWN_PIN PINF
#endif
#ifndef AVM_BUTTON_DOWN_PORT
#  define AVM_BUTTON_DOWN_PORT PORTF
#endif
#ifndef AVM_BUTTON_DOWN_DDR
#  define AVM_BUTTON_DOWN_DDR DDRF
#endif
#ifndef AVM_BUTTON_DOWN_BIT
#  define AVM_BUTTON_DOWN_BIT PORTF4
#endif
#ifndef AVM_BUTTON_A_PIN
#  define AVM_BUTTON_A_PIN PINE
#endif
#ifndef AVM_BUTTON_A_PORT
#  define AVM_BUTTON_A_PORT PORTE
#endif
#ifndef AVM_BUTTON_A_DDR
#  define AVM_BUTTON_A_DDR DDRE
#endif
#ifndef AVM_BUTTON_A_BIT
#  define AVM_BUTTON_A_BIT PORTE6
#endif
#ifndef AVM_BUTTON_B_PIN
#  define AVM_BUTTON_B_PIN PINB
#endif
#ifndef AVM_BUTTON_B_PORT
#  define AVM_BUTTON_B_PORT PORTB
#endif
#ifndef AVM_BUTTON_B_DDR
#  define AVM_BUTTON_B_DDR DDRB
#endif
#ifndef AVM_BUTTON_B_BIT
#  define AVM_BUTTON_B_BIT PORTB4
#endif

; Standard active-low RGB and USB activity LEDs.
#ifndef AVM_LED_RED_PORT
#  define AVM_LED_RED_PORT PORTB
#endif
#ifndef AVM_LED_RED_DDR
#  define AVM_LED_RED_DDR DDRB
#endif
#ifndef AVM_LED_RED_BIT
#  define AVM_LED_RED_BIT PORTB6
#endif
#ifndef AVM_LED_GREEN_PORT
#  define AVM_LED_GREEN_PORT PORTB
#endif
#ifndef AVM_LED_GREEN_DDR
#  define AVM_LED_GREEN_DDR DDRB
#endif
#ifndef AVM_LED_GREEN_BIT
#  define AVM_LED_GREEN_BIT PORTB7
#endif
#ifndef AVM_LED_BLUE_PORT
#  define AVM_LED_BLUE_PORT PORTB
#endif
#ifndef AVM_LED_BLUE_DDR
#  define AVM_LED_BLUE_DDR DDRB
#endif
#ifndef AVM_LED_BLUE_BIT
#  define AVM_LED_BLUE_BIT PORTB5
#endif
#ifndef AVM_LED_TX_PORT
#  define AVM_LED_TX_PORT PORTD
#endif
#ifndef AVM_LED_TX_DDR
#  define AVM_LED_TX_DDR DDRD
#endif
#ifndef AVM_LED_TX_BIT
#  define AVM_LED_TX_BIT PORTD5
#endif
#ifndef AVM_LED_RX_PORT
#  define AVM_LED_RX_PORT PORTB
#endif
#ifndef AVM_LED_RX_DDR
#  define AVM_LED_RX_DDR DDRB
#endif
#ifndef AVM_LED_RX_BIT
#  define AVM_LED_RX_BIT PORTB0
#endif

#ifndef AVM_RANDOM_SEED_PORT
#  define AVM_RANDOM_SEED_PORT PORTF
#endif
#ifndef AVM_RANDOM_SEED_DDR
#  define AVM_RANDOM_SEED_DDR DDRF
#endif
#ifndef AVM_RANDOM_SEED_BIT
#  define AVM_RANDOM_SEED_BIT PORTF1
#endif


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Native register allocation and architectural state
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; AVR r0:r1     MUL result and unrestricted interpreter scratch
; AVR r2        normally zero; SPI dummy-transmit byte; direct-FP temporary
; AVR r3        permanent one
; AVR r4:r6     24-bit VM program counter, little-endian
; AVR r7        permanent four; primary-table stride in AVR words
; AVR r8:r23    AVM architectural registers r0-r7
; AVR r24:r27   general interpreter scratch (X is r26:r27)
; AVR r28:r29   AVM stack pointer (Y)
; AVR r30:r31   general scratch and dispatch target (Z)
; GPIOR0        architectural VM_FLAGS
;
; r3 and r7 are initialized once and remain immutable. Direct FMIN/FMAX/FCMP
; and rounding temporarily use r2 for control, but clear it before entering any
; shared interpreter path. Native r0:r1 have no ABI zero-register requirement.

#define PRIMARY_TABLE_ORG          0x0200
#define PRIMARY_STRIDE_WORDS       4
#define PRIMARY_STRIDE_BYTES       (2 * PRIMARY_STRIDE_WORDS)
#define PRIMARY_OPCODE             r24

; Generic bounded-secondary decoder scratch allocation. PRIMARY_OPCODE and
; SECONDARY_OPCODE deliberately alias r24: once a prefix slot has been entered,
; the primary opcode is no longer needed except by specialized prefix handlers.
#define SECONDARY_OPCODE           r24
#define SECONDARY_LIMIT            r25
#define SECONDARY_MULTIPLIER       r26

; FF table-free decoder scratch allocation. The secondary and trailing
; specifier are consumed in r24. Extended operations are normalized to 0-9 in
; r25, and r26 is used to validate reserved specifier bits.
#define FF_SECONDARY               r24
#define FF_SPEC                    r24
#define FF_OPERATION               r25
#define FF_VALIDATE                r26

; Shared FF/libm bridge ABI. Callers load a helper target into native Z and
; place the encoded operand descriptor in FF_BRIDGE_DESC before jumping to one
; of the typed bridge entries below. GPIOR1 retains the architectural
; destination across helper calls; GPIOR2 carries direct floating-operation
; control while the in-register min/max/compare and rounding cores execute.
#define FF_BRIDGE_DESC             r24
#define FF_BRIDGE_META             r25
#define FF_BRIDGE_INDEX            r26
#define FF_BRIDGE_XH               r27
#define FF_BRIDGE_META_IO          GPIOR1
#define FF_DIRECT_CONTROL_IO       GPIOR2

#define FF_BRIDGE_RESULT_Q32       0x00
#define FF_BRIDGE_RESULT_R16       0x40
#define FF_BRIDGE_RESULT_FCMP      0x80

; Shared F0 operand-fetch ABI. The one-byte helper returns the consumed byte in
; F0_OPERAND_LO. The two-byte helper returns a little-endian operand in
; F0_OPERAND_HI:F0_OPERAND_LO. F0_SPEC aliases the one-byte result for RRSPEC
; and future program-space operand specifiers.
#define F0_OPERAND_LO              r24
#define F0_OPERAND_HI              r25
#define F0_SPEC                    r24
#define F0_DECODE_SCRATCH          r25
; F0 69-6B keep the trailing pre-scaled RRSPEC in native r25. The secondary
; opcode is normalized in r24 to 0=CMP32, 1=LD32, 2=ST32 before this byte is read.
#define F0_COLD32_SPEC             r25
; F0 6C-6D keep dddWaaaP in native r1 after the reverse-order fetch.
; Native r1 has no ABI zero-register requirement in this assembly-only runtime.
#define F0_COLDMEM_SPEC            r1

; ED-EE displaced-memory decoder scratch. The second byte remains in r25 so
; width bit 4 survives the exact offset-byte handoff; the fetched biased
; displacement replaces the no-longer-needed primary/secondary scratch in r24.
#define DISPLACED_SPEC             r25
#define DISPLACED_OFFSET           r24

; FB-FD shared conditional-move gate scratch allocation.
#define CMOV_TEST                  r25
#define CMOV_SECONDARY             r26
#define CMOV_MASK                  r27

#define ZERO                       r2
#define ONE                        r3
#define FOUR                       r7

#define VM_PCL                     r4
#define VM_PCM                     r5
#define VM_PCH                     r6

#define VM_FLAGS                   GPIOR0

#define VM_SP_INITIAL_VALUE        0x0A00
#define VM_SP                      r28
#define VM_SPL                     r28
#define VM_SPH                     r29

#define VM_R0                      r8
#define VM_R1                      r10
#define VM_R2                      r12
#define VM_R3                      r14
#define VM_R4                      r16
#define VM_R5                      r18
#define VM_R6                      r20
#define VM_R7                      r22

#define VM_R0L                     r8
#define VM_R1L                     r10
#define VM_R2L                     r12
#define VM_R3L                     r14
#define VM_R4L                     r16
#define VM_R5L                     r18
#define VM_R6L                     r20
#define VM_R7L                     r22

#define VM_R0H                     r9
#define VM_R1H                     r11
#define VM_R2H                     r13
#define VM_R3H                     r15
#define VM_R4H                     r17
#define VM_R5H                     r19
#define VM_R6H                     r21
#define VM_R7H                     r23

#define __SFR_OFFSET 0
#include <avr/io.h>
#ifndef SREG_C
#  define SREG_C  (0)
#endif
#ifndef SREG_Z
#  define SREG_Z  (1)
#endif
#ifndef SREG_N
#  define SREG_N  (2)
#endif
#ifndef SREG_V
#  define SREG_V  (3)
#endif
#ifndef SREG_S
#  define SREG_S  (4)
#endif
#ifndef SREG_H
#  define SREG_H  (5)
#endif
#ifndef SREG_T
#  define SREG_T  (6)
#endif
#ifndef SREG_I
#  define SREG_I  (7)
#endif

#if (PRIMARY_TABLE_ORG & 0x1FF) != 0
#  error "Primary dispatch requires 256-word (512-byte) alignment"
#endif
; OLED display control. All supported controllers use active-low CS and reset,
; with D/C low for commands and high for display data.
.macro display_enable
    cbi  AVM_OLED_CS_PORT, AVM_OLED_CS_BIT
.endm

.macro display_disable
    sbi  AVM_OLED_CS_PORT, AVM_OLED_CS_BIT
.endm

.macro display_command_mode
    cbi  AVM_OLED_DC_PORT, AVM_OLED_DC_BIT
.endm

.macro display_data_mode
    sbi  AVM_OLED_DC_PORT, AVM_OLED_DC_BIT
.endm

; Generic GPIO setup helpers. PORT is written before DDR for outputs so OLED,
; flash, and active-low LED pins never glitch through an unintended level.
.macro pin_output_high port, ddr, bit
    sbi  \port, \bit
    sbi  \ddr,  \bit
.endm

.macro pin_output_low port, ddr, bit
    cbi  \port, \bit
    sbi  \ddr,  \bit
.endm

.macro pin_input_pullup port, ddr, bit
    cbi  \ddr,  \bit
    sbi  \port, \bit
.endm

.macro pin_input_floating port, ddr, bit
    cbi  \ddr,  \bit
    cbi  \port, \bit
.endm

; Serial Flash Commands (W25Q128)
#define SFC_READ               0x03
#define SFC_READSTATUS1        0x05
#define SFC_WRITE_ENABLE       0x06
#define SFC_WRITE              0x02
#define SFC_ERASE              0x20
#define SFC_RELEASE_POWERDOWN  0xAB

#define FX_VECTOR_KEY_POINTER       0x0014
#define FX_DATA_VECTOR_PAGE_POINTER 0x0016
#define FX_SAVE_VECTOR_KEY_POINTER  0x0018
#define FX_SAVE_VECTOR_PAGE_POINTER 0x001A
#define FX_VECTOR_KEY               0x9518

; AVM linked-image header constants.
#define AVM_HEADER_MAGIC0       0x41
#define AVM_HEADER_MAGIC1       0x56
#define AVM_HEADER_MAGIC2       0x4D
#define AVM_HEADER_MAGIC3       0x01
#define AVM_RUNTIME_VERSION          0x01
#define AVM_HEADER_DATA_SIZE_OFFSET 0x08
#define AVM_HEADER_SAVE_SIZE_OFFSET 0x0A
#define AVM_DATA_IMAGE_OFFSET         0x0100

; The mandatory eight-byte image tail occupies the final eight bytes of the
; linked image. Only the first six bytes are needed by startup:
;   41 56 54 01, imagePageCountLo, imagePageCountHi
#define AVM_TAIL_MAGIC0         0x41
#define AVM_TAIL_MAGIC1         0x56
#define AVM_TAIL_MAGIC2         0x54
#define AVM_TAIL_MAGIC3         0x01
#define AVM_TAIL_OFFSET_IN_PAGE 0xF8

; Arduboy system ABI service identifiers.
#define SYS_DEBUG_PUTC          0x00
#define SYS_DEBUG_BREAK         0x01
#define SYS_MILLIS              0x02
#define SYS_MILLIS32            0x03
#define SYS_SINF                0x04
#define SYS_COSF                0x05
#define SYS_ATAN2F              0x06
#define SYS_TANF                0x07
#define SYS_EXPF                0x08
#define SYS_LOGF                0x09
#define SYS_LOG2F               0x0A
#define SYS_LOG10F              0x0B
#define SYS_POWF                0x0C
#define SYS_HYPOTF              0x0D
#define SYS_FMODF               0x0E
#define SYS_MEMCPY              0x0F
#define SYS_MEMCPY_P            0x10
#define SYS_MEMSET              0x11
#define SYS_MEMMOVE             0x12
#define SYS_MEMCMP_P            0x13
#define SYS_STRCMP_P            0x14
#define SYS_STRLEN_P            0x15
#define SYS_STRNCPY_P           0x16
#define SYS_STRNCAT_P           0x17
#define SYS_MEMCMP              0x18
#define SYS_STRCMP              0x19
#define SYS_STRLEN              0x1A
#define SYS_STRNCPY             0x1B
#define SYS_STRNCAT             0x1C
#define SYS_DISPLAY             0x1D
#define SYS_DRAW_SPRITE_OVERWRITE   0x1E
#define SYS_DRAW_SPRITE_PLUS_MASK   0x1F
#define SYS_DRAW_SPRITE_SELF_MASKED 0x20
#define SYS_DRAW_SPRITE_ERASE       0x21
#define SYS_SET_SPRITE               0x22
#define SYS_DRAW_OVERWRITE           0x23
#define SYS_DRAW_PLUS_MASK           0x24
#define SYS_DRAW_SELF_MASKED         0x25
#define SYS_DRAW_ERASE               0x26
#define SYS_DRAW_FILLED_RECT_WHITE   0x27
#define SYS_DRAW_FILLED_RECT_BLACK   0x28
#define SYS_BUTTONS                  0x29
#define SYS_IDLE                     0x2A
#define SYS_GENERATE_RANDOM_SEED     0x2B
#define SYS_SAVE                     0x2C
#define SYS_LOAD                     0x2D
#define SYS_SAVE_EXISTS              0x2E
#define SYS_VSNPRINTF                 0x2F
#define SYS_VSNPRINTF_P               0x30
#define SYS_SET_TEXT_FONT              0x31
#define SYS_SET_TEXT_MODE              0x32
#define SYS_DRAW_TEXT                  0x33
#define SYS_DRAW_TEXT_P                0x34
#define SYS_DRAW_TEXTFV                0x35
#define SYS_DRAW_TEXTFV_P              0x36
#define SYS_DEBUG_PRINTFV_P             0x37
#define SYS_AUDIO                       0x38
#define SYS_SEND_DISPLAY_COMMAND        0x39
#define SYS_GET_SYSTEM_WIDTH            0x3A
#define SYS_GET_SYSTEM_HEIGHT           0x3B
#define SYS_GET_SYSTEM_DISPLAY_TYPE     0x3C

#define SPRITE_MODE_OVERWRITE    0
#define SPRITE_MODE_PLUS_MASK    1
#define SPRITE_MODE_SELF_MASKED  2
#define SPRITE_MODE_ERASE        3

#define SPRITE_FLAG_TOP          0
#define SPRITE_FLAG_BOTTOM       1
#define SPRITE_FLAG_RESEEK       2
#define SPRITE_FLAG_PARTIAL      3
#define TEXT_GLYPH_FLAG_REJECT   7

; Development/emulator images either end at the end of the 16 MiB flash or
; end immediately before a final 4 KiB save sector.
#define FX_DEV_TAIL_NOSAVE_HI   0xFF
#define FX_DEV_TAIL_NOSAVE_MID  0xFF
#define FX_DEV_TAIL_SAVE_HI     0xFF
#define FX_DEV_TAIL_SAVE_MID    0xEF
#define FX_DEV_SAVE_PAGE_LO     0xF0
#define FX_DEV_SAVE_PAGE_HI     0xFF

.macro fx_enable
cbi  AVM_FX_PORT, AVM_FX_BIT
.endm

.macro fx_disable
sbi  AVM_FX_PORT, AVM_FX_BIT
.endm

.macro delay_1
    nop
.endm

.macro delay_2
    .word 0xC000   ; rjmp .+0
.endm

.macro delay_3
    lpm
.endm

.macro delay_4
    delay_2
    delay_2
.endm

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Shared F0 register-file decode macros
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; These macros convert architectural register indices or pre-scaled RRSPEC
; offsets into native AVR data-space pointers. They intentionally inline at the
; eventual cold handler so decoding adds no RCALL/RET overhead. All
; architectural registers occupy native r8-r23, below data-space address 0x100.
;
; The input scratch register must be in r16-r31 because ANDI/SUBI are used. The
; macro may be called with scratch == pointer-low; the explicit MOV remains
; valid in that case. Native flags are clobbered.

.macro f0_decode_r_index_to_ptr scratch, ptrl, ptrh
    andi  \scratch, 0x07
    lsl   \scratch
    subi  \scratch, -8
    mov   \ptrl, \scratch
    mov   \ptrh, ZERO
.endm

.macro f0_decode_q_index_to_ptr scratch, ptrl, ptrh
    andi  \scratch, 0x03
    lsl   \scratch
    lsl   \scratch
    subi  \scratch, -8
    mov   \ptrl, \scratch
    mov   \ptrh, ZERO
.endm

; Decode dddWaaaP used by F0 6C-6D. X receives the data-register pointer from
; bits 7:5 and Z receives the address-register pointer from bits 3:1. The
; encoded fields are already positioned as doubled native-register indices,
; so no shift or range validation is required. W and P remain in the preserved
; specifier. Native flags are clobbered.
.macro f0_decode_general_pointer_spec spec
    mov   r26, \spec
    swap  r26
    andi  r26, 0x0e
    subi  r26, -8
    mov   r27, ZERO

    mov   r30, \spec
    andi  r30, 0x0e
    subi  r30, -8
    mov   r31, ZERO
.endm


; Decode the pre-scaled nibble offsets used by F0 69-6B. X receives the high
; nibble operand and Z the low nibble operand. Alignment validation remains the
; responsibility of the operation-specific handler. F0_DECODE_SCRATCH is
; clobbered.
.macro f0_decode_prescaled_pair_spec spec
    mov   F0_DECODE_SCRATCH, \spec
    swap  F0_DECODE_SCRATCH
    andi  F0_DECODE_SCRATCH, 0x0f
    subi  F0_DECODE_SCRATCH, -8
    mov   r26, F0_DECODE_SCRATCH
    mov   r27, ZERO

    mov   F0_DECODE_SCRATCH, \spec
    andi  F0_DECODE_SCRATCH, 0x0f
    subi  F0_DECODE_SCRATCH, -8
    mov   r30, F0_DECODE_SCRATCH
    mov   r31, ZERO
.endm

; Sign-extend a fetched byte in F0_OPERAND_LO into F0_OPERAND_HI.
.macro f0_sign_extend_operand
    clr   F0_OPERAND_HI
    sbrc  F0_OPERAND_LO, 7
    com   F0_OPERAND_HI
.endm

.section .text,"ax",@progbits
.org 0x0000
.global __vectors

; ATmega32U4 interrupt vector table.
; Each vector is one 32-bit JMP instruction. The table contains the reset
; vector followed by the device interrupt vectors, including reserved slots,
; in datasheet order.
__vectors:
    jmp reset_handler       ;  0 RESET
    jmp default_isr         ;  1 INT0
    jmp default_isr         ;  2 INT1
    jmp default_isr         ;  3 INT2
    jmp default_isr         ;  4 INT3
    jmp default_isr         ;  5 RESERVED
    jmp default_isr         ;  6 RESERVED
    jmp default_isr         ;  7 INT6
    jmp default_isr         ;  8 RESERVED
    jmp default_isr         ;  9 PCINT0
    jmp default_isr         ; 10 USB GENERAL
    jmp default_isr         ; 11 USB ENDPOINT
    jmp default_isr         ; 12 WDT
    jmp default_isr         ; 13 RESERVED
    jmp default_isr         ; 14 RESERVED
    jmp default_isr         ; 15 RESERVED
    jmp default_isr         ; 16 TIMER1 CAPTURE
    jmp timer1_compa_isr    ; 17 TIMER1 COMPA
    jmp default_isr         ; 18 TIMER1 COMPB
    jmp default_isr         ; 19 TIMER1 COMPC
    jmp default_isr         ; 20 TIMER1 OVERFLOW
    jmp timer0_compa_isr    ; 21 TIMER0 COMPA
    jmp default_isr         ; 22 TIMER0 COMPB
    jmp default_isr         ; 23 TIMER0 OVERFLOW
    jmp default_isr         ; 24 SPI
    jmp default_isr         ; 25 USART1 RX
    jmp default_isr         ; 26 USART1 UDRE
    jmp default_isr         ; 27 USART1 TX
    jmp default_isr         ; 28 ANALOG COMPARATOR
    jmp default_isr         ; 29 ADC
    jmp default_isr         ; 30 EEPROM READY
    jmp default_isr         ; 31 TIMER3 CAPTURE
    jmp default_isr         ; 32 TIMER3 COMPA
    jmp default_isr         ; 33 TIMER3 COMPB
    jmp default_isr         ; 34 TIMER3 COMPC
    jmp default_isr         ; 35 TIMER3 OVERFLOW
    jmp default_isr         ; 36 TWI
    jmp default_isr         ; 37 SPM READY
    jmp default_isr         ; 38 TIMER4 COMPA
    jmp default_isr         ; 39 TIMER4 COMPB
    jmp default_isr         ; 40 TIMER4 COMPD
    jmp default_isr         ; 41 TIMER4 OVERFLOW
    jmp default_isr         ; 42 TIMER4 FPF

.size __vectors, .-__vectors

default_isr:
    rjmp default_isr

reset_handler:
    jmp startup_func

; Sine/tangent tables and OLED boot commands fill the otherwise unused bytes
; before the fixed waveform page. The polynomials start with their degree,
; followed by a binary32 leading coefficient and five-byte extended entries.
sinf_coefficients:
    .byte 5
    .byte 0xa8,0x4c,0xcd,0xb2
    .byte 0xd4,0x4e,0xb9,0x38,0x36
    .byte 0xa9,0x02,0x0c,0x50,0xb9
    .byte 0x91,0x86,0x88,0x08,0x3c
    .byte 0xa6,0xaa,0xaa,0x2a,0xbe
    .byte 0x00,0x00,0x00,0x80,0x3f

tanf_coefficients:
    .byte 6
    .byte 0x64,0xec,0x1b,0x3c
    .byte 0x04,0xbc,0x16,0x3e,0x3b
    .byte 0xe5,0xb9,0x3c,0xc9,0x3c
    .byte 0x37,0xc2,0x9e,0x5a,0x3d
    .byte 0x66,0x04,0x98,0x08,0x3e
    .byte 0xea,0x69,0xaa,0xaa,0x3e
    .byte 0x00,0x00,0x00,0x80,0x3f

; Commands follow Arduboy2's lcdBootProgram for the corresponding SPI display.
oled_boot_program:
#if defined(AVM_DISPLAY_SH1106)
    .byte 0x8D, 0x14                 ; enable charge pump
    .byte 0xA1                       ; segment remap
    .byte 0xC8                       ; COM scan direction
    .byte 0x81, AVM_OLED_CONTRAST    ; contrast
    .byte 0xD9, 0xF1                 ; precharge
    .byte 0x02                       ; SH1106 visible column starts at 2
    .byte 0xAF                       ; display on
#else
    .byte 0xD5, 0xF0                 ; display clock divisor
#  if defined(AVM_DISPLAY_SSD1309)
    .byte 0xE3, 0xE3                 ; SSD1309 has no charge-pump command
#  else
    .byte 0x8D, 0x14                 ; SSD1306 charge pump on
#  endif
    .byte 0xA1                       ; segment remap
    .byte 0xC8                       ; COM scan direction
    .byte 0x81, AVM_OLED_CONTRAST    ; contrast
    .byte 0xD9, 0xF1                 ; precharge
    .byte 0xAF                       ; display on
    .byte 0x20, 0x00                 ; horizontal addressing mode
#endif
oled_boot_program_end:

; Canonical mixed-codec scales; residuals are +/-S and +/-3S.
.org 0x0100
audio_steps:
    .byte 1,2,3,4,5,6,8,10,12,15,18,22,26,31,36,42

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Primary dispatch machinery
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; The primary table has 256 fixed four-word slots. A completed short handler
; ends with RJMP to a shared cadence tail; a longer primary handler may use its
; fourth word to forward to an out-of-line continuation. All defined non-prefix
; primary opcodes through 0xEF are implemented below. The implemented secondary
; pages use the decoder and cadence infrastructure after the primary table;
; reserved encodings trap as invalid.

; Standard 18-cycle sequential dispatch. Advance the low PC byte before
; reading the completed opcode. IN and OUT preserve carry, so the middle and
; high-byte updates remain a valid 24-bit increment after the handoff. Moving
; this one instruction before OUT makes the selected primary slot begin on
; cycle 9 after OUT.
.macro dispatch
    add  VM_PCL, ONE
    in   PRIMARY_OPCODE, SPDR
    out  SPDR, ZERO
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    mul  PRIMARY_OPCODE, FOUR
    movw r30, r0
    subi r31, hi8(-(pm(primary_table)))
    ijmp
.endm

; Reverse-order 17-cycle sequential dispatch. Complete the entire 24-bit PC
; increment before the protected SPDR handoff. CLI, OUT, IN, and SEI preserve
; the arithmetic flags, including carry; the shorter post-OUT path makes the
; selected primary slot begin on cycle 9 after OUT, matching standard dispatch.
.macro dispatch_reverse
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    cli
    out  SPDR, ZERO
    in   PRIMARY_OPCODE, SPDR
    sei
    mul  PRIMARY_OPCODE, FOUR
    movw r30, r0
    subi r31, hi8(-(pm(primary_table)))
    ijmp
.endm

; A skeleton slot is exactly four AVR words. The three unreachable NOPs reserve
; the words that a future direct handler or setup sequence may occupy.
.macro emit_primary_stub label, target
\label:
    rjmp \target
    nop
    nop
    nop
.Lprimary_stub_end_\@:
    .if (.Lprimary_stub_end_\@ - \label) != PRIMARY_STRIDE_BYTES
        .error "primary dispatch slot is not exactly four words"
    .endif
.endm


; All direct primary-emission macros below produce exactly four AVR words.
; Padding after an unconditional RJMP is unreachable and exists only to retain
; the fixed primary-table stride.

.macro assert_primary_slot_width label
.Lprimary_slot_end_\@:
    .if (.Lprimary_slot_end_\@ - \label) != PRIMARY_STRIDE_BYTES
        .error "implemented primary dispatch slot is not exactly four words"
    .endif
.endm

; 3 handler cycles plus one landing-pad cycle -> 17-cycle cadence.
.macro emit_primary_mov label, dst, src
\label:
    movw \dst, \src
    rjmp cluster_tail_17_delay_1
    nop
    nop
    assert_primary_slot_width \label
.endm

; 4 handler cycles -> 17-cycle cadence.
.macro emit_primary_binary label, lowop, highop, dstl, dsth, srcl, srch
\label:
    \lowop  \dstl, \srcl
    \highop \dsth, \srch
    rjmp cluster_tail_17
    nop
    assert_primary_slot_width \label
.endm

; Capture native SREG in PRIMARY_OPCODE and commit it to architectural
; VM_FLAGS through a dedicated 18-cycle dispatch landing.
.macro emit_primary_cmp label, lhsl, lhsh, rhsl, rhsh
\label:
    cp   \lhsl, \rhsl
    cpc  \lhsh, \rhsh
    in   PRIMARY_OPCODE, SREG
    rjmp flags_commit_18_delay_1
    assert_primary_slot_width \label
.endm

; Capture the address in X before overwriting the destination. This preserves
; the specified alias behavior when rD == rA.
.macro emit_primary_ld8u label, dstl, dsth, addr
\label:
    movw r26, \addr
    ld   \dstl, X
    clr  \dsth
    rjmp cluster_tail_18_delay_1
    assert_primary_slot_width \label
.endm

.macro emit_primary_st8 label, addr, srcl
\label:
    movw r26, \addr
    st   X, \srcl
    rjmp cluster_tail_18_delay_2
    nop
    assert_primary_slot_width \label
.endm

.macro emit_primary_ld16 label, dstl, dsth, addr
\label:
    movw r26, \addr
    ld   \dstl, X+
    ld   \dsth, X
    rjmp cluster_tail_18
    assert_primary_slot_width \label
.endm

.macro emit_primary_st16 label, addr, srcl, srch
\label:
    movw r26, \addr
    st   X+, \srcl
    st   X,  \srch
    rjmp cluster_tail_18
    assert_primary_slot_width \label
.endm

; The VM stack grows downward. PUSH stores high then low so VM_SP points at
; the little-endian low byte; POP reverses the operation.
.macro emit_primary_push16 label, srcl, srch
\label:
    st   -Y, \srch
    st   -Y, \srcl
    rjmp push16_stack_check
    nop
    assert_primary_slot_width \label
.endm

.macro emit_primary_pop16 label, dstl, dsth
\label:
    ld   \dstl, Y+
    ld   \dsth, Y+
    rjmp cluster_tail_18_delay_1
    nop
    assert_primary_slot_width \label
.endm

; Multi-byte primary slots preload a destination-specific apply address in Z,
; then forward to a family-shared operand-fetch continuation. The fourth word
; is padding so every slot retains the fixed four-word primary stride.
.macro emit_primary_immediate label, apply, fetch
\label:
    ldi  r30, lo8(pm(\apply))
    ldi  r31, hi8(pm(\apply))
    nop
    rjmp \fetch
    assert_primary_slot_width \label
.endm

; Generic bounded-page prefix. The slot preloads the page bound and table base,
; then forwards either to a width stub or directly to a specialized decoder.
.macro emit_primary_bounded_page label, limit, table, width_stub
\label:
    ldi  SECONDARY_LIMIT, \limit
    ldi  r30, lo8(pm(\table))
    ldi  r31, hi8(pm(\table))
    rjmp \width_stub
    assert_primary_slot_width \label
.endm

; FB-FD each preload a one-bit architectural-condition mask and the shared
; two-word CMOV table address. The secondary byte is already in flight.
.macro emit_primary_cmov_page label, mask
\label:
    ldi  CMOV_MASK, \mask
    ldi  r30, lo8(pm(cmov_table))
    ldi  r31, hi8(pm(cmov_table))
    rjmp cmov_gate
    assert_primary_slot_width \label
.endm

.org PRIMARY_TABLE_ORG
.global primary_table
.global abvm_interp
primary_table:
abvm_interp:

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x00-0x0F: MOV rD,rS (rD,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_mov primary_00, VM_R4, VM_R4
emit_primary_mov primary_01, VM_R4, VM_R5
emit_primary_mov primary_02, VM_R4, VM_R6
emit_primary_mov primary_03, VM_R4, VM_R7
emit_primary_mov primary_04, VM_R5, VM_R4
emit_primary_mov primary_05, VM_R5, VM_R5
emit_primary_mov primary_06, VM_R5, VM_R6
emit_primary_mov primary_07, VM_R5, VM_R7
emit_primary_mov primary_08, VM_R6, VM_R4
emit_primary_mov primary_09, VM_R6, VM_R5
emit_primary_mov primary_0A, VM_R6, VM_R6
emit_primary_mov primary_0B, VM_R6, VM_R7
emit_primary_mov primary_0C, VM_R7, VM_R4
emit_primary_mov primary_0D, VM_R7, VM_R5
emit_primary_mov primary_0E, VM_R7, VM_R6
emit_primary_mov primary_0F, VM_R7, VM_R7

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x10-0x1F: ADD rD,rS (rD,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_binary primary_10, add, adc, VM_R4L, VM_R4H, VM_R4L, VM_R4H
emit_primary_binary primary_11, add, adc, VM_R4L, VM_R4H, VM_R5L, VM_R5H
emit_primary_binary primary_12, add, adc, VM_R4L, VM_R4H, VM_R6L, VM_R6H
emit_primary_binary primary_13, add, adc, VM_R4L, VM_R4H, VM_R7L, VM_R7H
emit_primary_binary primary_14, add, adc, VM_R5L, VM_R5H, VM_R4L, VM_R4H
emit_primary_binary primary_15, add, adc, VM_R5L, VM_R5H, VM_R5L, VM_R5H
emit_primary_binary primary_16, add, adc, VM_R5L, VM_R5H, VM_R6L, VM_R6H
emit_primary_binary primary_17, add, adc, VM_R5L, VM_R5H, VM_R7L, VM_R7H
emit_primary_binary primary_18, add, adc, VM_R6L, VM_R6H, VM_R4L, VM_R4H
emit_primary_binary primary_19, add, adc, VM_R6L, VM_R6H, VM_R5L, VM_R5H
emit_primary_binary primary_1A, add, adc, VM_R6L, VM_R6H, VM_R6L, VM_R6H
emit_primary_binary primary_1B, add, adc, VM_R6L, VM_R6H, VM_R7L, VM_R7H
emit_primary_binary primary_1C, add, adc, VM_R7L, VM_R7H, VM_R4L, VM_R4H
emit_primary_binary primary_1D, add, adc, VM_R7L, VM_R7H, VM_R5L, VM_R5H
emit_primary_binary primary_1E, add, adc, VM_R7L, VM_R7H, VM_R6L, VM_R6H
emit_primary_binary primary_1F, add, adc, VM_R7L, VM_R7H, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x20-0x2F: SUB rD,rS (rD,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_binary primary_20, sub, sbc, VM_R4L, VM_R4H, VM_R4L, VM_R4H
emit_primary_binary primary_21, sub, sbc, VM_R4L, VM_R4H, VM_R5L, VM_R5H
emit_primary_binary primary_22, sub, sbc, VM_R4L, VM_R4H, VM_R6L, VM_R6H
emit_primary_binary primary_23, sub, sbc, VM_R4L, VM_R4H, VM_R7L, VM_R7H
emit_primary_binary primary_24, sub, sbc, VM_R5L, VM_R5H, VM_R4L, VM_R4H
emit_primary_binary primary_25, sub, sbc, VM_R5L, VM_R5H, VM_R5L, VM_R5H
emit_primary_binary primary_26, sub, sbc, VM_R5L, VM_R5H, VM_R6L, VM_R6H
emit_primary_binary primary_27, sub, sbc, VM_R5L, VM_R5H, VM_R7L, VM_R7H
emit_primary_binary primary_28, sub, sbc, VM_R6L, VM_R6H, VM_R4L, VM_R4H
emit_primary_binary primary_29, sub, sbc, VM_R6L, VM_R6H, VM_R5L, VM_R5H
emit_primary_binary primary_2A, sub, sbc, VM_R6L, VM_R6H, VM_R6L, VM_R6H
emit_primary_binary primary_2B, sub, sbc, VM_R6L, VM_R6H, VM_R7L, VM_R7H
emit_primary_binary primary_2C, sub, sbc, VM_R7L, VM_R7H, VM_R4L, VM_R4H
emit_primary_binary primary_2D, sub, sbc, VM_R7L, VM_R7H, VM_R5L, VM_R5H
emit_primary_binary primary_2E, sub, sbc, VM_R7L, VM_R7H, VM_R6L, VM_R6H
emit_primary_binary primary_2F, sub, sbc, VM_R7L, VM_R7H, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x30-0x3F: CMP rL,rR (rL,rR in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_cmp primary_30, VM_R4L, VM_R4H, VM_R4L, VM_R4H
emit_primary_cmp primary_31, VM_R4L, VM_R4H, VM_R5L, VM_R5H
emit_primary_cmp primary_32, VM_R4L, VM_R4H, VM_R6L, VM_R6H
emit_primary_cmp primary_33, VM_R4L, VM_R4H, VM_R7L, VM_R7H
emit_primary_cmp primary_34, VM_R5L, VM_R5H, VM_R4L, VM_R4H
emit_primary_cmp primary_35, VM_R5L, VM_R5H, VM_R5L, VM_R5H
emit_primary_cmp primary_36, VM_R5L, VM_R5H, VM_R6L, VM_R6H
emit_primary_cmp primary_37, VM_R5L, VM_R5H, VM_R7L, VM_R7H
emit_primary_cmp primary_38, VM_R6L, VM_R6H, VM_R4L, VM_R4H
emit_primary_cmp primary_39, VM_R6L, VM_R6H, VM_R5L, VM_R5H
emit_primary_cmp primary_3A, VM_R6L, VM_R6H, VM_R6L, VM_R6H
emit_primary_cmp primary_3B, VM_R6L, VM_R6H, VM_R7L, VM_R7H
emit_primary_cmp primary_3C, VM_R7L, VM_R7H, VM_R4L, VM_R4H
emit_primary_cmp primary_3D, VM_R7L, VM_R7H, VM_R5L, VM_R5H
emit_primary_cmp primary_3E, VM_R7L, VM_R7H, VM_R6L, VM_R6H
emit_primary_cmp primary_3F, VM_R7L, VM_R7H, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x40-0x4F: LD8U rD,[rA] (rD,rA in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_ld8u primary_40, VM_R4L, VM_R4H, VM_R4
emit_primary_ld8u primary_41, VM_R4L, VM_R4H, VM_R5
emit_primary_ld8u primary_42, VM_R4L, VM_R4H, VM_R6
emit_primary_ld8u primary_43, VM_R4L, VM_R4H, VM_R7
emit_primary_ld8u primary_44, VM_R5L, VM_R5H, VM_R4
emit_primary_ld8u primary_45, VM_R5L, VM_R5H, VM_R5
emit_primary_ld8u primary_46, VM_R5L, VM_R5H, VM_R6
emit_primary_ld8u primary_47, VM_R5L, VM_R5H, VM_R7
emit_primary_ld8u primary_48, VM_R6L, VM_R6H, VM_R4
emit_primary_ld8u primary_49, VM_R6L, VM_R6H, VM_R5
emit_primary_ld8u primary_4A, VM_R6L, VM_R6H, VM_R6
emit_primary_ld8u primary_4B, VM_R6L, VM_R6H, VM_R7
emit_primary_ld8u primary_4C, VM_R7L, VM_R7H, VM_R4
emit_primary_ld8u primary_4D, VM_R7L, VM_R7H, VM_R5
emit_primary_ld8u primary_4E, VM_R7L, VM_R7H, VM_R6
emit_primary_ld8u primary_4F, VM_R7L, VM_R7H, VM_R7

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x50-0x5F: ST8 [rA],rS (rA,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_st8 primary_50, VM_R4, VM_R4L
emit_primary_st8 primary_51, VM_R4, VM_R5L
emit_primary_st8 primary_52, VM_R4, VM_R6L
emit_primary_st8 primary_53, VM_R4, VM_R7L
emit_primary_st8 primary_54, VM_R5, VM_R4L
emit_primary_st8 primary_55, VM_R5, VM_R5L
emit_primary_st8 primary_56, VM_R5, VM_R6L
emit_primary_st8 primary_57, VM_R5, VM_R7L
emit_primary_st8 primary_58, VM_R6, VM_R4L
emit_primary_st8 primary_59, VM_R6, VM_R5L
emit_primary_st8 primary_5A, VM_R6, VM_R6L
emit_primary_st8 primary_5B, VM_R6, VM_R7L
emit_primary_st8 primary_5C, VM_R7, VM_R4L
emit_primary_st8 primary_5D, VM_R7, VM_R5L
emit_primary_st8 primary_5E, VM_R7, VM_R6L
emit_primary_st8 primary_5F, VM_R7, VM_R7L

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x60-0x6F: LD16 rD,[rA] (rD,rA in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_ld16 primary_60, VM_R4L, VM_R4H, VM_R4
emit_primary_ld16 primary_61, VM_R4L, VM_R4H, VM_R5
emit_primary_ld16 primary_62, VM_R4L, VM_R4H, VM_R6
emit_primary_ld16 primary_63, VM_R4L, VM_R4H, VM_R7
emit_primary_ld16 primary_64, VM_R5L, VM_R5H, VM_R4
emit_primary_ld16 primary_65, VM_R5L, VM_R5H, VM_R5
emit_primary_ld16 primary_66, VM_R5L, VM_R5H, VM_R6
emit_primary_ld16 primary_67, VM_R5L, VM_R5H, VM_R7
emit_primary_ld16 primary_68, VM_R6L, VM_R6H, VM_R4
emit_primary_ld16 primary_69, VM_R6L, VM_R6H, VM_R5
emit_primary_ld16 primary_6A, VM_R6L, VM_R6H, VM_R6
emit_primary_ld16 primary_6B, VM_R6L, VM_R6H, VM_R7
emit_primary_ld16 primary_6C, VM_R7L, VM_R7H, VM_R4
emit_primary_ld16 primary_6D, VM_R7L, VM_R7H, VM_R5
emit_primary_ld16 primary_6E, VM_R7L, VM_R7H, VM_R6
emit_primary_ld16 primary_6F, VM_R7L, VM_R7H, VM_R7

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x70-0x7F: ST16 [rA],rS (rA,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_st16 primary_70, VM_R4, VM_R4L, VM_R4H
emit_primary_st16 primary_71, VM_R4, VM_R5L, VM_R5H
emit_primary_st16 primary_72, VM_R4, VM_R6L, VM_R6H
emit_primary_st16 primary_73, VM_R4, VM_R7L, VM_R7H
emit_primary_st16 primary_74, VM_R5, VM_R4L, VM_R4H
emit_primary_st16 primary_75, VM_R5, VM_R5L, VM_R5H
emit_primary_st16 primary_76, VM_R5, VM_R6L, VM_R6H
emit_primary_st16 primary_77, VM_R5, VM_R7L, VM_R7H
emit_primary_st16 primary_78, VM_R6, VM_R4L, VM_R4H
emit_primary_st16 primary_79, VM_R6, VM_R5L, VM_R5H
emit_primary_st16 primary_7A, VM_R6, VM_R6L, VM_R6H
emit_primary_st16 primary_7B, VM_R6, VM_R7L, VM_R7H
emit_primary_st16 primary_7C, VM_R7, VM_R4L, VM_R4H
emit_primary_st16 primary_7D, VM_R7, VM_R5L, VM_R5H
emit_primary_st16 primary_7E, VM_R7, VM_R6L, VM_R6H
emit_primary_st16 primary_7F, VM_R7, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x80-0x8F: AND rD,rS (rD,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_binary primary_80, and, and, VM_R4L, VM_R4H, VM_R4L, VM_R4H
emit_primary_binary primary_81, and, and, VM_R4L, VM_R4H, VM_R5L, VM_R5H
emit_primary_binary primary_82, and, and, VM_R4L, VM_R4H, VM_R6L, VM_R6H
emit_primary_binary primary_83, and, and, VM_R4L, VM_R4H, VM_R7L, VM_R7H
emit_primary_binary primary_84, and, and, VM_R5L, VM_R5H, VM_R4L, VM_R4H
emit_primary_binary primary_85, and, and, VM_R5L, VM_R5H, VM_R5L, VM_R5H
emit_primary_binary primary_86, and, and, VM_R5L, VM_R5H, VM_R6L, VM_R6H
emit_primary_binary primary_87, and, and, VM_R5L, VM_R5H, VM_R7L, VM_R7H
emit_primary_binary primary_88, and, and, VM_R6L, VM_R6H, VM_R4L, VM_R4H
emit_primary_binary primary_89, and, and, VM_R6L, VM_R6H, VM_R5L, VM_R5H
emit_primary_binary primary_8A, and, and, VM_R6L, VM_R6H, VM_R6L, VM_R6H
emit_primary_binary primary_8B, and, and, VM_R6L, VM_R6H, VM_R7L, VM_R7H
emit_primary_binary primary_8C, and, and, VM_R7L, VM_R7H, VM_R4L, VM_R4H
emit_primary_binary primary_8D, and, and, VM_R7L, VM_R7H, VM_R5L, VM_R5H
emit_primary_binary primary_8E, and, and, VM_R7L, VM_R7H, VM_R6L, VM_R6H
emit_primary_binary primary_8F, and, and, VM_R7L, VM_R7H, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0x90-0x9F: OR rD,rS (rD,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_binary primary_90, or, or, VM_R4L, VM_R4H, VM_R4L, VM_R4H
emit_primary_binary primary_91, or, or, VM_R4L, VM_R4H, VM_R5L, VM_R5H
emit_primary_binary primary_92, or, or, VM_R4L, VM_R4H, VM_R6L, VM_R6H
emit_primary_binary primary_93, or, or, VM_R4L, VM_R4H, VM_R7L, VM_R7H
emit_primary_binary primary_94, or, or, VM_R5L, VM_R5H, VM_R4L, VM_R4H
emit_primary_binary primary_95, or, or, VM_R5L, VM_R5H, VM_R5L, VM_R5H
emit_primary_binary primary_96, or, or, VM_R5L, VM_R5H, VM_R6L, VM_R6H
emit_primary_binary primary_97, or, or, VM_R5L, VM_R5H, VM_R7L, VM_R7H
emit_primary_binary primary_98, or, or, VM_R6L, VM_R6H, VM_R4L, VM_R4H
emit_primary_binary primary_99, or, or, VM_R6L, VM_R6H, VM_R5L, VM_R5H
emit_primary_binary primary_9A, or, or, VM_R6L, VM_R6H, VM_R6L, VM_R6H
emit_primary_binary primary_9B, or, or, VM_R6L, VM_R6H, VM_R7L, VM_R7H
emit_primary_binary primary_9C, or, or, VM_R7L, VM_R7H, VM_R4L, VM_R4H
emit_primary_binary primary_9D, or, or, VM_R7L, VM_R7H, VM_R5L, VM_R5H
emit_primary_binary primary_9E, or, or, VM_R7L, VM_R7H, VM_R6L, VM_R6H
emit_primary_binary primary_9F, or, or, VM_R7L, VM_R7H, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xA0-0xAF: XOR rD,rS (rD,rS in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_binary primary_A0, eor, eor, VM_R4L, VM_R4H, VM_R4L, VM_R4H
emit_primary_binary primary_A1, eor, eor, VM_R4L, VM_R4H, VM_R5L, VM_R5H
emit_primary_binary primary_A2, eor, eor, VM_R4L, VM_R4H, VM_R6L, VM_R6H
emit_primary_binary primary_A3, eor, eor, VM_R4L, VM_R4H, VM_R7L, VM_R7H
emit_primary_binary primary_A4, eor, eor, VM_R5L, VM_R5H, VM_R4L, VM_R4H
emit_primary_binary primary_A5, eor, eor, VM_R5L, VM_R5H, VM_R5L, VM_R5H
emit_primary_binary primary_A6, eor, eor, VM_R5L, VM_R5H, VM_R6L, VM_R6H
emit_primary_binary primary_A7, eor, eor, VM_R5L, VM_R5H, VM_R7L, VM_R7H
emit_primary_binary primary_A8, eor, eor, VM_R6L, VM_R6H, VM_R4L, VM_R4H
emit_primary_binary primary_A9, eor, eor, VM_R6L, VM_R6H, VM_R5L, VM_R5H
emit_primary_binary primary_AA, eor, eor, VM_R6L, VM_R6H, VM_R6L, VM_R6H
emit_primary_binary primary_AB, eor, eor, VM_R6L, VM_R6H, VM_R7L, VM_R7H
emit_primary_binary primary_AC, eor, eor, VM_R7L, VM_R7H, VM_R4L, VM_R4H
emit_primary_binary primary_AD, eor, eor, VM_R7L, VM_R7H, VM_R5L, VM_R5H
emit_primary_binary primary_AE, eor, eor, VM_R7L, VM_R7H, VM_R6L, VM_R6H
emit_primary_binary primary_AF, eor, eor, VM_R7L, VM_R7H, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xB0-0xB7: PUSH16 rN
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_push16 primary_B0_push16_r0, VM_R0L, VM_R0H
emit_primary_push16 primary_B1_push16_r1, VM_R1L, VM_R1H
emit_primary_push16 primary_B2_push16_r2, VM_R2L, VM_R2H
emit_primary_push16 primary_B3_push16_r3, VM_R3L, VM_R3H
emit_primary_push16 primary_B4_push16_r4, VM_R4L, VM_R4H
emit_primary_push16 primary_B5_push16_r5, VM_R5L, VM_R5H
emit_primary_push16 primary_B6_push16_r6, VM_R6L, VM_R6H
emit_primary_push16 primary_B7_push16_r7, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xB8-0xBF: POP16 rN
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_pop16 primary_B8_pop16_r0, VM_R0L, VM_R0H
emit_primary_pop16 primary_B9_pop16_r1, VM_R1L, VM_R1H
emit_primary_pop16 primary_BA_pop16_r2, VM_R2L, VM_R2H
emit_primary_pop16 primary_BB_pop16_r3, VM_R3L, VM_R3H
emit_primary_pop16 primary_BC_pop16_r4, VM_R4L, VM_R4H
emit_primary_pop16 primary_BD_pop16_r5, VM_R5L, VM_R5H
emit_primary_pop16 primary_BE_pop16_r6, VM_R6L, VM_R6H
emit_primary_pop16 primary_BF_pop16_r7, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xC0-0xC3: LDI8 rD,imm8 (rD in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_immediate primary_R4_ldi8_r4, ldi8_r4_apply, fetch_imm8_then_ijmp
emit_primary_immediate primary_R5_ldi8_r5, ldi8_r5_apply, fetch_imm8_then_ijmp
emit_primary_immediate primary_R6_ldi8_r6, ldi8_r6_apply, fetch_imm8_then_ijmp
emit_primary_immediate primary_R7_ldi8_r7, ldi8_r7_apply, fetch_imm8_then_ijmp

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xC4-0xC7: LDI16 rD,imm16 (rD in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_immediate primary_C4_ldi16_r4, ldi16_r4_apply, fetch_imm16_then_ijmp
emit_primary_immediate primary_C5_ldi16_r5, ldi16_r5_apply, fetch_imm16_then_ijmp
emit_primary_immediate primary_C6_ldi16_r6, ldi16_r6_apply, fetch_imm16_then_ijmp
emit_primary_immediate primary_C7_ldi16_r7, ldi16_r7_apply, fetch_imm16_then_ijmp

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xC8-0xCB: ADDI.S8 rD,simm8 (rD in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_immediate primary_C8_addi_s8_r4, addi_s8_r4_apply, fetch_simm8_then_ijmp
emit_primary_immediate primary_C9_addi_s8_r5, addi_s8_r5_apply, fetch_simm8_then_ijmp
emit_primary_immediate primary_CA_addi_s8_r6, addi_s8_r6_apply, fetch_simm8_then_ijmp
emit_primary_immediate primary_CB_addi_s8_r7, addi_s8_r7_apply, fetch_simm8_then_ijmp

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xCC-0xCF: CMPI.S8 rL,simm8 (rL in r4-r7)
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_immediate primary_CC_cmpi_s8_r4, cmpi_s8_r4_apply, fetch_simm8_then_ijmp
emit_primary_immediate primary_CD_cmpi_s8_r5, cmpi_s8_r5_apply, fetch_simm8_then_ijmp
emit_primary_immediate primary_CE_cmpi_s8_r6, cmpi_s8_r6_apply, fetch_simm8_then_ijmp
emit_primary_immediate primary_CF_cmpi_s8_r7, cmpi_s8_r7_apply, fetch_simm8_then_ijmp

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xD0-0xD3: conditional branches
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; All D0-D6 and D8-D9 instructions have one signed byte operand. The primary
; slot advances VM_PC from the opcode to that operand and forwards to an
; out-of-line continuation. This exactly fills the fixed four-word primary
; slot.

.macro emit_primary_rel8 label, target
\label:
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    rjmp \target
    assert_primary_slot_width \label
.endm

emit_primary_rel8 primary_D0_breq8_rel8,  breq8_rel8_decode_func
emit_primary_rel8 primary_D1_brne8_rel8,  brne8_rel8_decode_func
emit_primary_rel8 primary_D2_brult8_rel8, brult8_rel8_decode_func
emit_primary_rel8 primary_D3_brslt8_rel8, brslt8_rel8_decode_func

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xD4-0xD7: relative control, ADJSP, and SYS
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_rel8 primary_D4_jmp8_rel8,  jmp8_rel8_func
emit_primary_rel8 primary_D5_call8_rel8, call8_rel8_func
emit_primary_rel8 primary_D6_adjsp,     adjsp_simm8_func

; Account for the service byte in the 24-bit VM PC. The out-of-line decoder
; reads that byte from SPDR and immediately starts fetching the following
; primary opcode. This setup plus the final RJMP exactly fills the four-word
; primary slot.
primary_D7_sys:
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    rjmp sys_decode_func
primary_D7_sys_end:
.if (primary_D7_sys_end - primary_D7_sys) != PRIMARY_STRIDE_BYTES
    .error "SYS primary dispatch slot is not exactly four words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xD8-0xD9: inverted conditional branches
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

emit_primary_rel8 primary_D8_bruge8_rel8, bruge8_rel8_decode_func
emit_primary_rel8 primary_D9_brsge8_rel8, brsge8_rel8_decode_func

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xDA-0xDF: 16-bit conditional branches
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Each slot preloads the selected architectural-flag mask, advances VM_PC from
; the opcode to rel16[7:0], and forwards to the shared decoder. Opcode bit 0
; selects the inverted condition within each flag pair.

.macro emit_primary_branch16 label, mask
\label:
    ldi  r25, \mask
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    rjmp branch_rel16_decode_func
    assert_primary_slot_width \label
.endm

emit_primary_branch16 primary_DA_breq16_rel16,  (1 << SREG_Z)
emit_primary_branch16 primary_DB_brne16_rel16,  (1 << SREG_Z)
emit_primary_branch16 primary_DC_brult16_rel16, (1 << SREG_C)
emit_primary_branch16 primary_DD_bruge16_rel16, (1 << SREG_C)
emit_primary_branch16 primary_DE_brslt16_rel16, (1 << SREG_S)
emit_primary_branch16 primary_DF_brsge16_rel16, (1 << SREG_S)

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xE0-0xE3: direct near/far control
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; JMP16/CALL16 consume a little-endian signed 16-bit displacement relative to
; the address immediately following the three-byte instruction. Their primary
; slots advance VM_PC from the opcode to the low displacement byte.
;
; JMPF/CALLF consume a little-endian absolute 24-bit image-relative target.
; JMPF does not need the sequential VM_PC, so its slot spends the same three
; setup cycles as the other direct-control slots only to preserve the first-byte
; SPI read timing. CALLF advances directly from the opcode to nextPC with FOUR
; so the return address is ready to push while later target bytes are fetched.

.macro emit_primary_rel16 label, target
\label:
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    rjmp \target
    assert_primary_slot_width \label
.endm

emit_primary_rel16 primary_E0_jmp16,  jmp_call_rel16_func
emit_primary_rel16 primary_E1_call16, jmp_call_rel16_func

primary_E2_jmpf:
    nop
    nop
    nop
    rjmp jmp_call_far_func
    assert_primary_slot_width primary_E2_jmpf

primary_E3_callf:
    add  VM_PCL, FOUR
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    rjmp jmp_call_far_func
    assert_primary_slot_width primary_E3_callf

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xE4-0xE7: JMPP qN
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; A program pointer uses the first register of qN for bits 15:0 and the low
; byte of the second register for bits 23:16. The unused top byte of qN is
; ignored. Each primary slot installs that 24-bit address as the current VM PC
; and forwards to the shared stream-seek/primary-dispatch handler.

.macro emit_primary_jmpp label, ptr16, ptr23_16
\label:
    movw VM_PCL, \ptr16
    mov  VM_PCH, \ptr23_16
    delay_2
    rjmp jmpp_seek_and_dispatch_func
    assert_primary_slot_width \label
.endm

emit_primary_jmpp primary_E4_jmpp_q0, VM_R0, VM_R1L
emit_primary_jmpp primary_E5_jmpp_q1, VM_R2, VM_R3L
emit_primary_jmpp primary_E6_jmpp_q2, VM_R4, VM_R5L
emit_primary_jmpp primary_E7_jmpp_q3, VM_R6, VM_R7L

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xE8-0xEB: CALLP qN
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; VM_PC names the CALLP opcode at primary-slot entry. Preserve the selected
; 24-bit target in scratch, begin advancing VM_PC to the sequential return
; address in the otherwise-unused fourth slot word, then let the shared
; prologue finish the carry chain before pushing PC+1 and installing the target.

.macro emit_primary_callp label, ptr16, ptr23_16
\label:
    movw r24, \ptr16
    mov  r26, \ptr23_16
    add  VM_PCL, ONE
    rjmp push_pc_seek_and_dispatch_func
    assert_primary_slot_width \label
.endm

emit_primary_callp primary_E8_callp_q0, VM_R0, VM_R1L
emit_primary_callp primary_E9_callp_q1, VM_R2, VM_R3L
emit_primary_callp primary_EA_callp_q2, VM_R4, VM_R5L
emit_primary_callp primary_EB_callp_q3, VM_R6, VM_R7L

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xEC: source-preserving 16-bit division and remainder
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Encoding: EC oo ddd sss
;   bits 7:6  00=UDIV16, 01=UREM16, 10=SDIV16, 11=SREM16
;   bits 5:3  destination/dividend rD
;   bits 2:0  source/divisor rS
;
; The primary slot forwards to a table-free runtime decoder. The secondary
; byte is already in flight when the slot begins.

primary_EC_divrem16_page:
    rjmp  ec_divrem16_entry
    nop
    nop
    nop
    assert_primary_slot_width primary_EC_divrem16_page

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xED-0xEE: full-register biased-displacement data-space memory
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Encoding:
;   ED dddWaaa0 off8    LD8U/LD16 rD,[rA+disp]
;   EE dddWaaa0 off8    ST8/ST16 [rA+disp],rS
;
;   ddd   data register r0-r7
;   W     0=byte, 1=word
;   aaa   address register r0-r7
;   bit 0 reserved and required to be zero
;   disp  = unsigned(off8) - 32, giving -32..+223
;
; The primary opcode remains in r24 on entry to the out-of-line handler. Its
; bit 1 distinguishes ED (load, zero) from EE (store, one), and is copied to
; native SREG.T before r24 is reused. The primary slots advance VM_PC by two
; bytes from the primary opcode to the biased-offset byte and leave the
; high-byte carry update to the common entry.

primary_ED_displaced_load:
    ldi  DISPLACED_SPEC, 2
    add  VM_PCL, DISPLACED_SPEC
    adc  VM_PCM, ZERO
    rjmp displaced_memory_entry
    assert_primary_slot_width primary_ED_displaced_load

primary_EE_displaced_store:
    ldi  DISPLACED_SPEC, 2
    add  VM_PCL, DISPLACED_SPEC
    adc  VM_PCM, ZERO
    rjmp displaced_memory_entry
    assert_primary_slot_width primary_EE_displaced_store

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xEF: RET
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Return addresses are stored little-endian at VM_SP: low, middle, high. RET
; restores the complete 24-bit VM PC directly in its four-word primary slot and
; enters the common stream-restart handler. No forwarding body or delay is
; required; the three two-cycle loads already outlast the discarded speculative
; byte transfer before flash chip select is toggled.

primary_EF_ret:
    ld   VM_PCL, Y+
    ld   VM_PCM, Y+
    ld   VM_PCH, Y+
    rjmp seek_and_dispatch_func
    assert_primary_slot_width primary_EF_ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xF0-0xFE: secondary-page prefixes
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Each bounded page advertises its architectural upper bound and uses its
; final natural slot width. F1-F9, FA, FB-FD, and FE execute implemented
; entries. F0 uses one-word veneers; secondaries 00-6D are implemented.
; F0 bound 0x6E, one-word veneer slots.
emit_primary_bounded_page primary_F0_cold_veneer_page, 0x6E, f0_veneer_table, secondary_width_1_stub
; F1 bound 0x90, two-word slots.
emit_primary_bounded_page primary_F1_dense_2word_page, 0x90, f1_table, bounded_width_2_decode
; F2 bound 0x6C, three-word slots.
emit_primary_bounded_page primary_F2_dense_3word_page_a, 0x6C, f2_table, secondary_width_3_stub
; F3 bound 0x80, three-word slots.
emit_primary_bounded_page primary_F3_dense_3word_page_b, 0x80, f3_table, secondary_width_3_stub
; F4 bound 0xB8, three-word slots.
emit_primary_bounded_page primary_F4_dense_3word_page_c, 0xB8, f4_table, secondary_width_3_stub
; F5 bound 0x60, four-word slots.
emit_primary_bounded_page primary_F5_dense_4word_page_a, 0x60, f5_table, secondary_width_4_stub
; F6 bound 0x50, four-word slots.
emit_primary_bounded_page primary_F6_dense_4word_page_b, 0x50, f6_table, secondary_width_4_stub
; F7 bound 0x90, five-word slots.
emit_primary_bounded_page primary_F7_dense_5word_page_a, 0x90, f7_table, secondary_width_5_stub
; F8 uses a shared CSET decoder. Flag selection and the register-file pointer
; high byte fill the same three setup cycles as the former table preloads.
primary_F8_simple_condition_page:
    clr  r27
    in   r25, VM_FLAGS
    bst  r25, SREG_Z
    rjmp f8_cset_decode
    assert_primary_slot_width primary_F8_simple_condition_page

; F9 is a dedicated table-free runtime decoder. Primary slots now begin on
; cycle 9 after the preceding SPI OUT. The direct RJMP reaches the handler on
; cycle 11; two independent pointer-high clears then fill the remaining slack
; so the reverse OUT still lands exactly on cycle 17.
primary_F9_runtime_bitwise_page:
    rjmp  f9_bitop_entry
    nop
    nop
    nop
    assert_primary_slot_width primary_F9_runtime_bitwise_page

; FA 00-2F retains the original register-count shifts, FA 30-EF adds
; immediate-count shifts, and F0-FF is reserved. The slot preloads the complete
; register-forwarding-table address. The immediate path derives its own full
; 16-bit table address from that base, so the FA tables no longer require page
; alignment.
primary_FA_shift_page:
    nop
    ldi  r30, lo8(pm(fa_forward_table))
    ldi  r31, hi8(pm(fa_forward_table))
    rjmp fa_shift_decode
    assert_primary_slot_width primary_FA_shift_page

; FB-FD share one condition gate and one 64-entry operand table. Bit 6 of the
; secondary byte selects the inverse condition; bit 7 is reserved.
emit_primary_cmov_page primary_FB_cmov_eq_ne_page,  (1 << SREG_Z)
emit_primary_cmov_page primary_FC_cmov_ult_uge_page, (1 << SREG_C)
emit_primary_cmov_page primary_FD_cmov_slt_sge_page, (1 << SREG_S)
; FE bound 0x40, two-word forwarding slots.
emit_primary_bounded_page primary_FE_mul16_page, 0x40, fe_forward_table, bounded_width_2_decode

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; 0xFF: table-free floating-point page
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; The secondary byte is already in flight. The dedicated decoder consumes it,
; rejects reserved ranges, and fetches the trailing specifier for C0-C9.

primary_FF_floating_page:
    rjmp  ff_decode
    nop
    nop
    nop
    assert_primary_slot_width primary_FF_floating_page

primary_table_end:
.if (primary_table_end - primary_table) != (256 * PRIMARY_STRIDE_BYTES)
    .error "primary dispatch table is not exactly 256 four-word slots"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; ED-EE full-register biased-displacement data-space memory
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Entry state:
;   * VM_PC names the third-byte biased offset.
;   * The specifier byte is completing in SPDR.
;   * PRIMARY_OPCODE still contains ED or EE; bit 1 selects load/store.
;
; The primary slot reaches this entry on cycle 14 after the OUT that started
; the specifier transfer. The standard IN/OUT handoff consumes the specifier on
; cycle 17 and starts the biased offset byte on cycle 18. While that byte is in
; flight, the handler validates bit 0, captures the original base address,
; decodes the data-register pointer, and applies the constant -32 bias. CLI/OUT
; then lands exactly on cycle 35, seventeen cycles after the offset transfer
; began. The final offset add and memory operation execute while the following
; primary opcode is in flight.
;
; Capturing the base before destination writeback makes every ordinary load
; alias legal, including rD == rA. Stores read the original source only after
; the base is captured, so rS == rA is also legal. Architectural VM_FLAGS are
; preserved.

displaced_memory_start:
displaced_memory_entry:
    adc   VM_PCH, ZERO
    bst   PRIMARY_OPCODE, 1      ; ED=load (0), EE=store (1)
    clr   r27                    ; XH for register-file addressing
    in    DISPLACED_SPEC, SPDR
    out   SPDR, ZERO             ; begin biased-offset transfer

    ; Bit zero is reserved. Reject malformed specifiers before any architectural
    ; destination writeback or data-space memory access.
    sbrc  DISPLACED_SPEC, 0
    rjmp  invalid_secondary_instruction_func

    ; Decode aaa into X and load the complete original base directly into Z.
    ; aaa is already positioned as twice the architectural register index.
    mov   r26, DISPLACED_SPEC
    andi  r26, 0x0e
    subi  r26, -8
    ld    r30, X+
    ld    r31, X

    ; Decode ddd into X. Swapping places ddd in bits 3:1, already pre-scaled
    ; for the native register-file byte address.
    mov   r26, DISPLACED_SPEC
    swap  r26
    andi  r26, 0x0e
    subi  r26, -8

    ; Apply the fixed bias while the offset byte is still transferring. SBIW's
    ; immediate range includes 32, so this costs one word and two cycles.
    sbiw  r30, 32

    cli
    out   SPDR, ZERO             ; exact cycle 35: following-primary transfer
    in    DISPLACED_OFFSET, SPDR
    sei

    ; Complete effectiveAddress = originalBase + unsigned(off8) - 32.
    add   r30, DISPLACED_OFFSET
    adc   r31, ZERO

    ; T was set by the primary opcode and survives all intervening work.
    brts  displaced_memory_store

displaced_memory_load:
    ; Load through Z before touching the dynamically selected destination in X.
    ; Byte loads leave r1 cleared; word loads conditionally replace it.
    ld    r0, Z+
    clr   r1
    sbrc  DISPLACED_SPEC, 4
    ld    r1, Z
    st    X+, r0
    st    X,  r1
    rjmp  cluster_a_tail_18

displaced_memory_store:
    ; Capture the complete original source before writing memory. A byte store
    ; still reads the high byte, allowing one compact shared byte/word body.
    ld    r0, X+
    ld    r1, X
    st    Z+, r0
    sbrc  DISPLACED_SPEC, 4
    st    Z,  r1
    rjmp  cluster_a_tail_18

displaced_memory_end:
.if (displaced_memory_end - displaced_memory_start) != 74
    .error "ED-EE displaced-memory handler must occupy exactly 37 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; FF table-free floating-point decoder scaffolding
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Entry state:
;   * VM_PC names the FF primary opcode.
;   * The secondary byte is completing in SPDR.
;
; The primary slot reaches ff_decode on cycle 11 after the preceding SPI OUT.
; Five one-cycle instructions fill cycles 11-15, allowing the exact cycle-17
; reverse handoff. That handoff starts either the following primary-opcode
; transfer for a two-byte instruction or the trailing-specifier transfer for
; C0-C9.
;
; FADD, FSUB, FMUL, FDIV, FSQRT, and C0-C7 conversions use the shared
; embedded-libm bridge. FMIN, FMAX, FCMP, and the four integral-rounding
; operations execute in interpreter-native register code. FNEG and FABS modify
; the selected sign byte directly, while FCLASS classifies its binary32 source
; inline. Reserved secondary ranges and malformed operand specifiers enter the
; architectural invalid-secondary trap.

ff_decode:
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
    clr   r27
    ldi   r30, lo8(ff_binary_helper_targets)
    cli
    out   SPDR, ZERO
    in    FF_SECONDARY, SPDR
    sei

    ; 00-7B are defined two-byte operations. 7C-BF and CA-FF are reserved.
    ; C0-C9 consume one additional operand-specifier byte.
    cpi   FF_SECONDARY, 0x7C
    brlo  ff_defined_short
    cpi   FF_SECONDARY, 0xC0
    brsh  .Lff_check_extended
    rjmp  ff_invalid
.Lff_check_extended:
    cpi   FF_SECONDARY, 0xCA
    brlo  ff_extended
    rjmp  ff_invalid

ff_defined_short:
    ; FADD/FSUB/FMUL/FDIV/FMIN/FMAX occupy 00-5F. The high nibble selects a
    ; compact helper-target entry and the low nibble remains the ddss bridge
    ; descriptor. FNEG/FABS occupy 60-67; bit 2 selects FABS and bits 1:0
    ; select qD. The five unary-helper groups occupy 68-7B in four-opcode
    ; blocks: FSQRT, FTRUNC, FFLOOR, FCEIL, and FROUND.
    cpi   FF_SECONDARY, 0x60
    brlo  ff_binary_arithmetic
    cpi   FF_SECONDARY, 0x68
    brlo  ff_sign_operation
    rjmp  ff_unary_math

ff_sign_operation:

    ; Native register addresses for q0-q3 sign bytes are r11, r15, r19, r23.
    ; r27 was cleared before the reverse SPI handoff, so X addresses the native
    ; register file directly. Load before modifying to keep every qD legal.
    mov   r26, FF_SECONDARY
    andi  r26, 0x03
    lsl   r26
    lsl   r26
    subi  r26, -11
    ld    r25, X

    ; Subtracting 0x80 toggles only the sign bit. FABS instead clears it.
    sbrc  FF_SECONDARY, 2
    rjmp  ff_fabs_apply
    subi  r25, 0x80
    rjmp  ff_store_sign_byte

ff_fabs_apply:
    andi  r25, 0x7F

ff_store_sign_byte:
    st    X, r25

    ; The following opcode was launched at cycle 17 and is legally readable
    ; from cycle 34. FABS reaches the standard tail's IN at cycle 43; FNEG
    ; reaches it at cycle 44. The tail advances VM_PC from the secondary byte
    ; to that following opcode before entering its primary-table slot.
    rjmp  cluster_tail_18

ff_unary_math:
    ; 68-7B consists of five four-opcode groups. Group zero is FSQRT and still
    ; uses the heavy embedded-libm bridge. Groups one through four are the
    ; interpreter-native trunc/floor/ceil/round core; normalize them to modes
    ; 0-3 and retain qD in GPIOR1.
    mov   FF_BRIDGE_INDEX, FF_SECONDARY
    subi  FF_BRIDGE_INDEX, 0x68
    lsr   FF_BRIDGE_INDEX
    lsr   FF_BRIDGE_INDEX
    tst   FF_BRIDGE_INDEX
    brne  .Lff_direct_round_prepare

    ldi   r30, lo8(pm(sqrtf))
    ldi   r31, hi8(pm(sqrtf))
    jmp   ff_bridge_unary_q_to_q

.Lff_direct_round_prepare:
    dec   FF_BRIDGE_INDEX
    out   FF_DIRECT_CONTROL_IO, FF_BRIDGE_INDEX
    mov   FF_BRIDGE_META, FF_SECONDARY
    andi  FF_BRIDGE_META, 0x03
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META
    jmp   ff_direct_round_load_q

ff_binary_arithmetic:
    ; 00-3F use embedded-libm arithmetic helpers. 40-5F are direct FMIN/FMAX:
    ; preserve qD separately, encode ddss plus the max/min selector in GPIOR2,
    ; and load both operands without touching architectural registers.
    mov   FF_BRIDGE_INDEX, FF_SECONDARY
    swap  FF_BRIDGE_INDEX
    andi  FF_BRIDGE_INDEX, 0x07
    cpi   FF_BRIDGE_INDEX, 4
    brsh  .Lff_direct_minmax_prepare

    ; r30 was preloaded during the cadence-filling decoder setup.
    ldi   r31, hi8(ff_binary_helper_targets)
    rcall ff_load_helper_target
    jmp   ff_bridge_binary_q_to_q

.Lff_direct_minmax_prepare:
    mov   FF_BRIDGE_META, FF_SECONDARY
    andi  FF_BRIDGE_META, 0x0F
    sbrc  FF_SECONDARY, 4
    ori   FF_BRIDGE_META, 0x40     ; bit 6: FMAX rather than FMIN
    out   FF_DIRECT_CONTROL_IO, FF_BRIDGE_META

    mov   FF_BRIDGE_META, FF_SECONDARY
    lsr   FF_BRIDGE_META
    lsr   FF_BRIDGE_META
    andi  FF_BRIDGE_META, 0x03
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META
    jmp   ff_direct_load_left_q

ff_extended:
    ; The reverse handoff above started the trailing-specifier transfer on
    ; cycle 17. The range checks reach this path on cycle 28. Advance VM_PC to
    ; the specifier, retain a normalized operation index, and consume the
    ; specifier with the earliest legal standard IN/OUT handoff on cycles
    ; 34/35.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
    mov   FF_OPERATION, FF_SECONDARY
    subi  FF_OPERATION, 0xC0
    nop
    in    FF_SPEC, SPDR
    out   SPDR, ZERO

    ; Validate the finalized architectural specifier forms:
    ;   C0-C3, C9 RQSPEC:  0rrr00qq
    ;   C4-C7     QQSPEC:  0000ddss
    ;   C8       RQQSPEC:  0dddllrr
    mov   FF_VALIDATE, FF_SPEC
    cpi   FF_OPERATION, 4
    brlo  .Lff_validate_rqspec
    cpi   FF_OPERATION, 8
    brlo  .Lff_validate_qqspec
    cpi   FF_OPERATION, 9
    brlo  .Lff_validate_rqqspec

    ; C9 uses RQSPEC like C0-C3.
.Lff_validate_rqspec:
    andi  FF_VALIDATE, 0x8C
    rjmp  .Lff_validate_done
.Lff_validate_qqspec:
    andi  FF_VALIDATE, 0xF0
    rjmp  .Lff_validate_done
.Lff_validate_rqqspec:
    andi  FF_VALIDATE, 0x80
.Lff_validate_done:
    brne  ff_invalid

    ; C0-C7 are conversions. The low two operation bits select one of four
    ; libm helpers shared by the 16-bit and 32-bit forms:
    ;   0 __floatsisf, 1 __floatunsisf, 2 __fixsfsi, 3 __fixunssfsi.
    ; C8 uses the interpreter-native compare core. C9 classifies its binary32
    ; source inline without entering the embedded-libm bridge.
    cpi   FF_OPERATION, 8
    breq  ff_compare
    brsh  ff_classify
    mov   FF_BRIDGE_INDEX, FF_OPERATION
    andi  FF_BRIDGE_INDEX, 0x03
    ldi   r30, lo8(ff_conversion_helper_targets)
    ldi   r31, hi8(ff_conversion_helper_targets)
    rcall ff_load_helper_target

    ; C4-C7 use QQSPEC and all marshal qS to A, returning qD.
    cpi   FF_OPERATION, 4
    brsh  .Lff_conversion_q_to_q

    ; C0-C3 use RQSPEC. C0-C1 extend rS into A and return qD; C2-C3
    ; marshal qS into A and retain the low 16 result bits in rD.
    cpi   FF_OPERATION, 2
    brsh  .Lff_conversion_q_to_r16
    sbrc  FF_OPERATION, 0
    jmp   ff_bridge_r16_to_q_u
    jmp   ff_bridge_r16_to_q_s
.Lff_conversion_q_to_r16:
    jmp   ff_bridge_q_to_r16
.Lff_conversion_q_to_q:
    jmp   ff_bridge_q_to_q

ff_invalid:
    rjmp  invalid_secondary_instruction_func

ff_compare:
    ; RQQSPEC is 0dddllrr. Store rD in GPIOR1 and mark direct-control bit 7;
    ; bits 3:0 retain qL:qR for the shared two-operand loader.
    mov   FF_BRIDGE_META, FF_SPEC
    swap  FF_BRIDGE_META
    andi  FF_BRIDGE_META, 0x07
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META

    mov   FF_BRIDGE_META, FF_SPEC
    andi  FF_BRIDGE_META, 0x0F
    ori   FF_BRIDGE_META, 0x80
    out   FF_DIRECT_CONTROL_IO, FF_BRIDGE_META
    jmp   ff_direct_load_left_q

ff_classify:
    ; RQSPEC is 0ddd00ss. Retain rD in ZL, then capture all four source bytes
    ; before writing the result so every rD/qS overlap is well-defined. q0-q3
    ; begin at native register addresses r8, r12, r16, and r20.
    mov   r30, FF_SPEC
    swap  r30
    andi  r30, 0x07

    mov   r26, FF_SPEC
    andi  r26, 0x03
    lsl   r26
    lsl   r26
    subi  r26, -8
    clr   r27
    ld    r0, X+
    ld    r1, X+
    ld    r25, X+
    ld    r26, X

    ; r26 is sign/exponent[7:1], r25 is exponent[0]/fraction[22:16], and
    ; r1:r0 are fraction[15:0]. Reduce the complete fraction to zero/nonzero
    ; in r0, then assemble the eight-bit exponent in r24.
    mov   r24, r25
    andi  r24, 0x7F
    or    r0, r1
    or    r0, r24

    mov   r24, r26
    lsl   r24
    sbrc  r25, 7
    ori   r24, 1
    breq  .Lff_class_exp_zero
    cpi   r24, 0xFF
    breq  .Lff_class_exp_max

    ldi   r25, 8                 ; +normal
    rjmp  .Lff_class_numeric

.Lff_class_exp_zero:
    ldi   r25, 6                 ; +zero
    tst   r0
    breq  .Lff_class_numeric
    inc   r25                    ; +subnormal
    rjmp  .Lff_class_numeric

.Lff_class_exp_max:
    tst   r0
    brne  .Lff_class_nan
    ldi   r25, 9                 ; +infinity
    rjmp  .Lff_class_numeric

.Lff_class_nan:
    ; NaN classes ignore the sign. Fraction bit 22 distinguishes quiet from
    ; signaling NaNs and becomes the one-bit class index directly.
    bst   r25, 6
    clr   r25                    ; signaling NaN index 0
    bld   r25, 0                 ; quiet NaN index 1
    rjmp  .Lff_class_build_mask

.Lff_class_numeric:
    ; Positive numeric classes are indices 6-9. Their corresponding negative
    ; classes are 11-index: +Inf 9 -> -Inf 2 through +zero 6 -> -zero 5.
    sbrs  r26, 7
    rjmp  .Lff_class_build_mask
    neg   r25
    subi  r25, -11

    ; Convert class index 0-9 into the architectural one-hot mask. The loop
    ; executes at most nine shifts and is smaller than a 20-byte mask table.
.Lff_class_build_mask:
    ldi   r24, 1
    clr   r26
    inc   r25
.Lff_class_shift_loop:
    dec   r25
    breq  .Lff_class_store
    lsl   r24
    rol   r26
    rjmp  .Lff_class_shift_loop

.Lff_class_store:
    ; r30 still holds rD. Store only after classification, preserving every
    ; nondestination architectural register even when rD overlaps qS.
    lsl   r30
    subi  r30, -8
    clr   r31
    st    Z+, r24
    st    Z,  r26
    rjmp  cluster_a_tail_18

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; EC dedicated runtime-decoded 16-bit division/remainder page
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Encoding: EC oo ddd sss
;   oo=00  UDIV16 rD,rS
;   oo=01  UREM16 rD,rS
;   oo=10  SDIV16 rD,rS
;   oo=11  SREM16 rD,rS
;
; rD supplies the dividend and receives the selected result. rS is preserved,
; and rD == rS is legal because both complete operands are captured before
; writeback. Architectural VM_FLAGS are preserved.
;
; Two restoring cores compute quotient and remainder together. Magnitudes
; that fit in eight bits use a dedicated byte core; all others use the word
; core. Both cores perform two quotient-bit iterations per loop branch.
; r24:r25 is the shifting dividend/quotient, r26:r27 is the unsigned divisor
; magnitude, and r0:r1 is the partial remainder. r30 retains the destination
; register-file address; its otherwise-unused high bits carry operation
; metadata:
;
;   bit 7  signed operation
;   bit 6  select remainder rather than quotient
;   bit 5  negate the selected signed result
;
; Division by zero is deterministic: DIV returns 0xFFFF and REM returns the
; original dividend. Signed INT_MIN / -1 returns INT_MIN with remainder zero.
;
; Primary-slot entry occurs on cycle 9 after the secondary-byte OUT. The slot
; RJMP reaches this handler on cycle 11. Clearing XH and ZH fills cycles 14 and
; 15, allowing the speculative following-primary OUT to land exactly on cycle
; 17. The long arithmetic body then finishes through a late standard tail.

ec_divrem16_entry:
    ; Consume the secondary byte in the VM PC and start the speculative
    ; following-primary transfer at the exact reverse-handoff boundary.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
    mov   r27, ZERO
    mov   r31, ZERO
    cli
    out   SPDR, ZERO
    in    SECONDARY_OPCODE, SPDR
    sei

    ; Z = native register-file address of destination/dividend rD.
    mov   r30, SECONDARY_OPCODE
    lsr   r30
    lsr   r30
    andi  r30, 0x0e
    subi  r30, -8

    ; X = native register-file address of preserved source/divisor rS.
    mov   r26, SECONDARY_OPCODE
    lsl   r26
    andi  r26, 0x0e
    subi  r26, -8

    ; Capture the original dividend without advancing Z. This permits rD == rS.
    ld    r0, Z
    ldd   r1, Z+1

    ; Preserve oo in the unused high bits of the destination address.
    andi  SECONDARY_OPCODE, 0xc0
    or    r30, SECONDARY_OPCODE

    ; Capture the complete divisor before any destination writeback, then move
    ; both operands into the divider's working allocation.
    ld    r24, X+
    ld    r25, X
    movw  r26, r24
    movw  r24, r0

    ; Define division by zero without entering the 16-iteration loop.
    mov   r31, r26
    or    r31, r27
    breq  .Lec_divrem16_zero

    ; Signed forms convert both inputs to unsigned magnitudes. For quotient,
    ; the correction sign is dividend_sign XOR divisor_sign; for remainder it
    ; is the original dividend sign, matching C/LLVM truncation semantics.
    sbrs  r30, 7
    rjmp  .Lec_divrem16_magnitudes_ready

    mov   r31, r25
    sbrs  r30, 6
    eor   r31, r27
    sbrc  r31, 7
    ori   r30, 0x20

    sbrs  r25, 7
    rjmp  .Lec_divrem16_dividend_positive
    neg   r24
    adc   r25, ZERO
    neg   r25
.Lec_divrem16_dividend_positive:

    sbrs  r27, 7
    rjmp  .Lec_divrem16_magnitudes_ready
    neg   r26
    adc   r27, ZERO
    neg   r27

.Lec_divrem16_magnitudes_ready:
    clr   r0
    clr   r1

    ; Magnitudes with zero high bytes use the dedicated eight-bit core. The
    ; true 16-bit path pays only this three-cycle not-taken test.
    mov   r31, r25
    or    r31, r27
    breq  .Lec_divrem16_8bit

    ; Eight groups perform the sixteen word-wide quotient-bit iterations.
    ldi   r31, 8

.Lec_divrem16_loop16:
    ; First quotient bit in this group.
    lsl   r24
    rol   r25
    rol   r0
    rol   r1
    cp    r0, r26
    cpc   r1, r27
    brlo  .Lec_divrem16_no_subtract16_a
    sub   r0, r26
    sbc   r1, r27
    ori   r24, 1
.Lec_divrem16_no_subtract16_a:

    ; Second quotient bit in this group.
    lsl   r24
    rol   r25
    rol   r0
    rol   r1
    cp    r0, r26
    cpc   r1, r27
    brlo  .Lec_divrem16_no_subtract16_b
    sub   r0, r26
    sbc   r1, r27
    ori   r24, 1
.Lec_divrem16_no_subtract16_b:
    dec   r31
    brne  .Lec_divrem16_loop16

.Lec_divrem16_select_result:
    ; Select quotient or remainder in constant time.
    sbrc  r30, 6
    movw  r24, r0

    ; Correct the sign of the selected signed result when required.
    sbrs  r30, 5
    rjmp  .Lec_divrem16_store
    neg   r24
    adc   r25, ZERO
    neg   r25
    rjmp  .Lec_divrem16_store

.Lec_divrem16_zero:
    ; r24:r25 still contains the original dividend. REM keeps it; DIV returns
    ; all ones for both signed and unsigned forms.
    sbrc  r30, 6
    rjmp  .Lec_divrem16_store
    ser   r24
    ser   r25

.Lec_divrem16_store:
    andi  r30, 0x1f
    mov   r31, ZERO
    st    Z+, r24
    st    Z,  r25
    rjmp  cluster_a_tail_18

    ; Out-of-line byte-magnitude path. Four groups perform eight quotient-bit
    ; iterations. r25, r27, and r1 remain zero, so common 16-bit result
    ; selection and signed correction can be reused unchanged.
.Lec_divrem16_8bit:
    ldi   r31, 4

.Lec_divrem16_loop8:
    ; First quotient bit in this group.
    lsl   r24
    rol   r0
    cp    r0, r26
    brlo  .Lec_divrem16_no_subtract8_a
    sub   r0, r26
    ori   r24, 1
.Lec_divrem16_no_subtract8_a:

    ; Second quotient bit in this group.
    lsl   r24
    rol   r0
    cp    r0, r26
    brlo  .Lec_divrem16_no_subtract8_b
    sub   r0, r26
    ori   r24, 1
.Lec_divrem16_no_subtract8_b:
    dec   r31
    brne  .Lec_divrem16_loop8
    rjmp  .Lec_divrem16_select_result

ec_divrem16_end:
.if (ec_divrem16_end - ec_divrem16_entry) != 214
    .error "EC 16-bit division/remainder handler must occupy exactly 107 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; F9 dedicated runtime-decoded full-register bitwise page
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Encoding: F9 dddsssoo
;   bits 7:5  destination register r0-r7
;   bits 4:2  source register r0-r7
;   bits 1:0  00=AND, 01=OR, 10=XOR, 11=invalid
;
; Primary-slot execution begins on cycle 9 after the OUT that started the
; secondary byte. The slot RJMP reaches this handler on cycle 11. Clearing XH
; and ZH is independent of the secondary byte, so those two useful instructions
; fill cycles 14 and 15 before CLI/OUT on cycles 16/17. Both architectural
; operands are loaded before writeback, so destination/source aliasing is fully
; defined.

f9_bitop_entry:
    ; Consume the secondary byte in the VM PC and immediately start the
    ; speculative following-primary transfer. Pre-clear the register-file
    ; pointer high bytes while the secondary transfer is still in flight.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
    mov   r27, ZERO
    mov   r31, ZERO
    cli
    out   SPDR, ZERO
    in    SECONDARY_OPCODE, SPDR
    sei

    ; X = native register-file address of destination rD.
    mov   r26, SECONDARY_OPCODE
    swap  r26
    andi  r26, 0x0e
    subi  r26, -8

    ; Z = native register-file address of source rS.
    mov   r30, SECONDARY_OPCODE
    lsr   r30
    andi  r30, 0x0e
    subi  r30, -8

    ; Preserve operation bits without another scratch register:
    ; carry = original bit 0, SECONDARY_OPCODE bit 0 = original bit 1.
    lsr   SECONDARY_OPCODE

    ; Capture both complete original operands before modifying rD.
    ld    r0,  X+
    ld    r1,  X
    ld    r25, Z+
    ld    r31, Z                   ; Z is dead after this non-updating load

    ; SECONDARY_OPCODE bit 0 selects low (AND/OR) versus high
    ; (XOR/invalid) operation groups.
    sbrc  SECONDARY_OPCODE, 0
    rjmp  .Lf9_high_operation

    ; Low group: carry selects AND=0 or OR=1.
    brcc  .Lf9_and
    or    r0, r25
    or    r1, r31
    rjmp  .Lf9_store

.Lf9_and:
    and   r0, r25
    and   r1, r31

.Lf9_store:
    ; Source high lives in the now-dead ZH, leaving XH zero for writeback.
    st    X,  r1
    st    -X, r0
    rjmp  cluster_a_tail_18

.Lf9_high_operation:
    ; High group: carry selects XOR=0 or invalid=1.
    brcs  .Lf9_invalid
    eor   r0, r25
    eor   r1, r31
    rjmp  .Lf9_store

.Lf9_invalid:
    rjmp  invalid_secondary_instruction_func

f9_bitop_end:
.if (f9_bitop_end - f9_bitop_entry) != 76
    .error "dedicated F9 runtime bitwise handler must occupy exactly 38 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; FA combined immediate/register-count shift decoder
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Encoding:
;   FA 00-2F  original register-count encodings
;   FA 30-EF  immediate count; subtract 0x30, then bits 7:6 select the
;             operation, bits 5:4 the destination, and bits 3:0 the count
;   FA F0-FF  reserved
;
; The primary slot reaches this decoder on cycle 14. The following primary
; opcode is launched with the exact cycle-17 reverse handoff. Register-count
; forms enter their forwarding entry on cycle 29 and the shared shift body on
; cycle 32, preserving their previous latency. Immediate forms enter the shared
; body on cycle 34 because their full 16-bit table-address calculation adds two
; cycles.
;
; Z contains the complete word address of fa_forward_table. Register-count
; forms index that table with full carry propagation at the original latency.
; Immediate forms subtract sixteen words to obtain the pre-biased immediate
; base, then perform a full 16-bit add. This removes all table-alignment
; constraints at a two-cycle cost to immediate forms only.
fa_shift_decode_start:
fa_shift_decode:
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    cli
    out  SPDR, ZERO
    in   SECONDARY_OPCODE, SPDR
    sei
    adc  VM_PCH, ZERO

    cpi  SECONDARY_OPCODE, 0x30
    brlo .Lfa_register_count

    ; Immediate form. Preserve the complete secondary in r26; the shared body
    ; masks it to the low four-bit count. The high nibble directly selects one
    ; of twelve body jumps through a base pre-biased by three entries. A high
    ; nibble of 0xF selects the thirteenth, invalid entry.
    mov   r26, SECONDARY_OPCODE
    swap  SECONDARY_OPCODE
    andi  SECONDARY_OPCODE, 0x0f
    sbiw  r30, 16
    add   r30, SECONDARY_OPCODE
    adc   r31, ZERO
    ijmp

.Lfa_register_count:
    ; Original 00-2F encoding. Multiplying the two-word slot index by two and
    ; propagating carry through ZH takes the same three cycles as the previous
    ; pair of low-byte ADDs plus balancing NOP, so variable-shift latency is
    ; unchanged even when the forwarding table crosses a page boundary.
    lsl   SECONDARY_OPCODE
    add   r30, SECONDARY_OPCODE
    adc   r31, ZERO
    ijmp
fa_shift_decode_end:
.if (fa_shift_decode_end - fa_shift_decode_start) != 40
    .error "dedicated FA shift decoder must occupy exactly 20 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Generic bounded-secondary decoders
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; F1 and FE use two-word executable-table slots. Their primary prefix
; slots preload the entry limit and table base, then jump directly to the
; shared width-two decoder below. FA uses the dedicated combined shift decoder
; above. Bypassing a multiplier-loading stub leaves
; enough time to use the exact 17-cycle reverse SPI handoff.
;
; F0 and F2-F7 use the generic multiplier decoder. Their primary prefix slots
; preload the entry limit and word-address table base in Z, then one of the
; four remaining width stubs supplies the natural slot width.

bounded_width_2_decode_start:
bounded_width_2_decode:
    ; The primary slot reaches this path on cycle 14. Advance the low and
    ; middle PC bytes before CLI so the reverse OUT lands exactly on cycle 17;
    ; CLI/OUT/IN/SEI preserve carry into the high-byte ADC after the handoff.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    cli
    out  SPDR, ZERO
    in   SECONDARY_OPCODE, SPDR
    sei
    adc  VM_PCH, ZERO

    ; Both shared width-two pages have a contiguous valid range beginning at 0.
    cp   SECONDARY_OPCODE, SECONDARY_LIMIT
    brsh invalid_secondary

    ; Z += 2 * secondary in AVR word-address space. Two complete 16-bit
    ; additions are required because F1 includes entries 0x80-0x8F; a bare
    ; LSL would lose the ninth offset bit when the index crosses 0x7f.
    add  r30, SECONDARY_OPCODE
    adc  r31, ZERO
    add  r30, SECONDARY_OPCODE
    adc  r31, ZERO
    ijmp
bounded_width_2_decode_end:
.if (bounded_width_2_decode_end - bounded_width_2_decode_start) != 28
    .error "shared width-two bounded decoder must occupy 14 AVR words"
.endif

bounded_page_decoder_start:
secondary_width_1_stub:
    ldi  SECONDARY_MULTIPLIER, 1
    rjmp bounded_page_decode
secondary_width_1_stub_end:
.if (secondary_width_1_stub_end - secondary_width_1_stub) != 4
    .error "one-word secondary-width stub is not exactly two AVR words"
.endif

secondary_width_3_stub:
    ldi  SECONDARY_MULTIPLIER, 3
    rjmp bounded_page_decode
secondary_width_3_stub_end:
.if (secondary_width_3_stub_end - secondary_width_3_stub) != 4
    .error "three-word secondary-width stub is not exactly two AVR words"
.endif

secondary_width_4_stub:
    ldi  SECONDARY_MULTIPLIER, 4
    rjmp bounded_page_decode
secondary_width_4_stub_end:
.if (secondary_width_4_stub_end - secondary_width_4_stub) != 4
    .error "four-word secondary-width stub is not exactly two AVR words"
.endif

secondary_width_5_stub:
    ldi  SECONDARY_MULTIPLIER, 5
    rjmp bounded_page_decode
secondary_width_5_stub_end:
.if (secondary_width_5_stub_end - secondary_width_5_stub) != 4
    .error "five-word secondary-width stub is not exactly two AVR words"
.endif

bounded_page_decode:
    ; The setup/stub path reaches this IN at the first legal read cycle. Read
    ; the completed secondary byte, then immediately launch speculative fetch
    ; of the following primary opcode with the standard 18-cycle handoff.
    in   SECONDARY_OPCODE, SPDR
    out  SPDR, ZERO

    ; The PC currently names the prefix opcode. Advance it to the secondary
    ; byte after launching the next transfer so this work overlaps SPI.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO

    cp   SECONDARY_OPCODE, SECONDARY_LIMIT
    brsh invalid_secondary

bounded_page_valid:
    ; Z already contains the table's AVR word address. MUL produces a word
    ; offset because SECONDARY_MULTIPLIER is the slot width in AVR words.
    mul  SECONDARY_OPCODE, SECONDARY_MULTIPLIER
    add  r30, r0
    adc  r31, r1
    ijmp

invalid_secondary:
    rjmp invalid_secondary_instruction_func

bounded_page_decoder_end:
.if (bounded_page_decoder_end - bounded_page_decoder_start) != 40
    .error "generic bounded decoder and four width stubs must occupy 20 AVR words"
.endif

; F8 00-2F: CSET.EQ/NE/ULT/UGE/SLT/SGE r0-r7. The primary slot has
; captured VM_FLAGS in r25, selected Z in native T, and cleared XH.
; Low/middle PC updates occupy cycles 14/15, then the protected reverse
; handoff starts the next opcode at cycle 17 and reads the secondary at 18.
; Each SBRC/BST or SBRC/EOR pair takes two cycles for either bit value.
; All valid conditions and destinations therefore have the same latency.
f8_cset_decode:
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    cli
    out   SPDR, ZERO
    in    SECONDARY_OPCODE, SPDR
    sei
    adc   VM_PCH, ZERO

    cpi   SECONDARY_OPCODE, 0x30
    brsh  invalid_secondary
    sbrc  SECONDARY_OPCODE, 4
    bst   r25, SREG_C
    sbrc  SECONDARY_OPCODE, 5
    bst   r25, SREG_S
    clr   r25
    bld   r25, 0
    sbrc  SECONDARY_OPCODE, 3
    eor   r25, ONE

    mov   r26, SECONDARY_OPCODE
    andi  r26, 0x07
    lsl   r26
    subi  r26, -8
    st    X+, r25
    st    X, ZERO
    ; Spending sixteen bytes on a local dispatch removes a two-cycle RJMP
    ; from every CSET. This retains 416 bytes of savings over the old table.
    dispatch
f8_cset_decode_end:
.if (f8_cset_decode_end - f8_cset_decode) != 64
    .error "shared F8 decoder/dispatch must occupy exactly thirty-two AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; FB-FD shared conditional-move gate
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Entry state:
;   * CMOV_MASK identifies Z, C, or S for the selected prefix.
;   * Z contains the AVR word address of cmov_table.
;   * The secondary byte is completing in SPDR.
;
; The gate consumes that byte with the standard cycle-17/18 IN/OUT handoff,
; applies bit-6 inversion, and indexes the table only when the selected
; condition is true. Bit 7 is invalid. Architectural VM_FLAGS is read but never
; modified.
cmov_gate:
    ; The prefix slot reaches this gate on cycle 14. Complete the PC increment
    ; during cycles 14-16, then use the standard IN/OUT handoff on cycles 17/18.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
    in    CMOV_SECONDARY, SPDR
    out   SPDR, ZERO

    cpi   CMOV_SECONDARY, 0x80
    brsh  cmov_invalid

    in    CMOV_TEST, VM_FLAGS
    sbrc  CMOV_SECONDARY, 6
    com   CMOV_TEST
    and   CMOV_TEST, CMOV_MASK
    breq  cmov_no_move

    andi  CMOV_SECONDARY, 0x3F
    lsl   CMOV_SECONDARY
    add   r30, CMOV_SECONDARY
    adc   r31, ZERO
    ijmp

cmov_no_move:
    rjmp  cluster_a_tail

cmov_invalid:
    rjmp  invalid_secondary

cmov_gate_end:
.if (cmov_gate_end - cmov_gate) != 38
    .error "FB-FD shared condition gate must occupy exactly 19 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Post-table migration scaffolding
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; All defined non-prefix primary opcodes 00-EC and EF are complete. The generic
; bounded-page decoder, secondary cadence clusters, and every specified
; executable secondary table are present. The fixed-width self-contained F1-F7
; pages, the dedicated EC division, F8 CSET and F9 bitwise decoders, the FA immediate/variable
; shift page, the FB-FD shared conditional-move gate/table, and the FE MUL16
; page are implemented. FF has a table-free floating-point decoder with direct
; operations and typed libm bridges. F0 has shared operand-fetch/register-decode
; infrastructure and all valid secondaries 00-6D are implemented, including
; program-space loads, cold 32-bit forms, and general-pointer data-space forms.

; Direct 00-BF handlers use these exact cadence landings. Later secondary
; pages may add local copies when required by layout or RJMP reach.

; CMP captures native SREG in PRIMARY_OPCODE (r24). The one-cycle landing pad
; plus OUT and the standard dispatch body produce an exact 18-cycle cadence.
flags_commit_18_delay_1:
    nop
flags_commit_18:
    out  VM_FLAGS, PRIMARY_OPCODE
    dispatch

; CMPI.S8 captures native SREG in PRIMARY_OPCODE, commits it here, then
; uses the one-cycle landing below to reach an exact reverse-order handoff.
cmpi_s8_flags_commit_17:
    out  VM_FLAGS, PRIMARY_OPCODE
cluster_tail_17_delay_1:
    nop
cluster_tail_17:
    dispatch_reverse

cluster_tail_18_delay_3:
    nop
cluster_tail_18_delay_2:
    rjmp cluster_tail_18

; Fatal post-write PUSH16 lower-bound check. The first overflowing push may
; write into the framebuffer; no following guest instruction may execute.
; No VM_FLAGS/GPIOR0 write or guest/native stack use is needed here.
stack_overflow_func:
    rjmp stack_overflow_func
; Full-range validator for arbitrary SETSP and either sign of ADJSP. Compare
; against exclusive upper bound 0x0A01, then fall through to PUSH16's existing
; lower-page check. Six valid-path check cycles plus standard dispatch replace
; ADJSP's four padding cycles and slower reverse tail, retaining 35 cycles.
; r25 is interpreter scratch; guest registers and GPIOR0 are untouched.
stack_bounds_check:
    ldi  r25, hi8(VM_SP_INITIAL_VALUE)
    cpi  VM_SPL, lo8(VM_SP_INITIAL_VALUE+1)
    cpc  VM_SPH, r25
    brsh stack_overflow_func
push16_stack_check:
    cpi  VM_SPH, hi8(data_stack)
    brlo stack_overflow_func
; Normal schedule relative to the preceding SPI OUT: primary entry at 9,
; ST high at 9-10, ST low at 11-12, RJMP at 13-14, CPI at 15, BRLO (not
; taken) at 16. Fall through to standard ADD/IN/OUT at 17/18/19; the next
; primary entry is at 28. Entry-to-entry latency is exactly 28 - 9 = 19.
; The old one-cycle landing is aliased to Cluster A below, keeping all other
; callers' timing unchanged without duplicating a dispatch body.
cluster_tail_18:
    dispatch

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; C0-CF upper-register immediate instructions
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; At entry to each fetch continuation, the first immediate byte was started by
; the dispatch that selected the primary slot. Z contains the word address of
; the destination-specialized apply stub. PRIMARY_OPCODE (r24) carries imm8 or
; the low byte of imm16; r25 carries the sign extension or imm16 high byte.
;
; The fetch paths leave VM PC naming the final immediate byte. Their final OUT
; starts the following primary opcode. The apply stubs use the available slack
; to reach an exact reverse-order 17-cycle handoff for that opcode.

; Consume one unsigned immediate byte and start the following primary opcode.
; From primary-slot entry to the OUT is eight cycles; including the preceding
; dispatch, this preserves the normal 17/18-cycle SPI byte cadence.
fetch_imm8_then_ijmp:
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    in   PRIMARY_OPCODE, SPDR
    out  SPDR, ZERO
    ijmp

; Consume one signed immediate byte, start the following primary opcode, and
; form its 16-bit sign extension in r25 before entering the selected apply stub.
fetch_simm8_then_ijmp:
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    in   PRIMARY_OPCODE, SPDR
    out  SPDR, ZERO
    clr  r25
    sbrc PRIMARY_OPCODE, 7
    com  r25
    ijmp

; Consume a little-endian 16-bit immediate. The low-byte handoff uses the
; standard 18-cycle IN/OUT schedule. While the high byte transfers, complete
; the second PC increment, use a callable delay for the remaining slack, and
; perform an exact reverse-order 17-cycle handoff for the following opcode.
fetch_imm16_then_ijmp:
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    in   PRIMARY_OPCODE, SPDR
    out  SPDR, ZERO

    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    rcall interp_delay_12
    cli
    out  SPDR, ZERO
    in   r25, SPDR
    sei
    ijmp

; The apply paths have enough slack to use the reverse-order dispatch. These
; shared entries contribute exactly six, four, or three cycles before entering
; cluster_tail_17, whose PC update and protected OUT place the next transfer at
; the exact 17-cycle boundary.
immediate_result_tail_reverse_delay_6:
    delay_2
immediate_result_tail_reverse_delay_4:
    nop
immediate_result_tail_reverse_delay_3:
    nop
    rjmp cluster_tail_17

.macro emit_ldi8_apply label, dstl, dsth
\label:
    mov  \dstl, PRIMARY_OPCODE
    clr  \dsth
    rjmp immediate_result_tail_reverse_delay_6
.endm

.macro emit_ldi16_apply label, dstl, dsth
\label:
    mov  \dstl, PRIMARY_OPCODE
    mov  \dsth, r25
    rjmp immediate_result_tail_reverse_delay_4
.endm

.macro emit_addi_s8_apply label, dstl, dsth
\label:
    add  \dstl, PRIMARY_OPCODE
    adc  \dsth, r25
    rjmp immediate_result_tail_reverse_delay_3
.endm

.macro emit_cmpi_s8_apply label, lhsl, lhsh
\label:
    cp   \lhsl, PRIMARY_OPCODE
    cpc  \lhsh, r25
    in   PRIMARY_OPCODE, SREG
    rjmp cmpi_s8_flags_commit_17
.endm

emit_ldi8_apply ldi8_r4_apply, VM_R4L, VM_R4H
emit_ldi8_apply ldi8_r5_apply, VM_R5L, VM_R5H
emit_ldi8_apply ldi8_r6_apply, VM_R6L, VM_R6H
emit_ldi8_apply ldi8_r7_apply, VM_R7L, VM_R7H

emit_ldi16_apply ldi16_r4_apply, VM_R4L, VM_R4H
emit_ldi16_apply ldi16_r5_apply, VM_R5L, VM_R5H
emit_ldi16_apply ldi16_r6_apply, VM_R6L, VM_R6H
emit_ldi16_apply ldi16_r7_apply, VM_R7L, VM_R7H

emit_addi_s8_apply addi_s8_r4_apply, VM_R4L, VM_R4H
emit_addi_s8_apply addi_s8_r5_apply, VM_R5L, VM_R5H
emit_addi_s8_apply addi_s8_r6_apply, VM_R6L, VM_R6H
emit_addi_s8_apply addi_s8_r7_apply, VM_R7L, VM_R7H

emit_cmpi_s8_apply cmpi_s8_r4_apply, VM_R4L, VM_R4H
emit_cmpi_s8_apply cmpi_s8_r5_apply, VM_R5L, VM_R5H
emit_cmpi_s8_apply cmpi_s8_r6_apply, VM_R6L, VM_R6H
emit_cmpi_s8_apply cmpi_s8_r7_apply, VM_R7L, VM_R7H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; D0-D6 relative control and stack adjustment
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; At entry to each continuation, VM_PC points at the signed operand byte and
; SPDR contains that byte. Conditional branches immediately start a speculative
; fetch of the fallthrough opcode. A not-taken branch preserves that stream;
; a taken branch discards it and restarts at nextPC + sign_extend(rel8).

.macro emit_branch_rel8_decode label, skipop, flag
\label:
    ; The primary slot now reaches this continuation on cycle 14 after the
    ; operand-starting OUT. A two-cycle landing followed by the protected
    ; reverse handoff places the speculative fallthrough OUT exactly on 17.
    delay_2
    cli
    out  SPDR, ZERO
    in   PRIMARY_OPCODE, SPDR
    sei

    ; A satisfied condition skips the not-taken jump. SBIS implements a
    ; branch-on-set condition; SBIC implements a branch-on-clear condition.
    \skipop VM_FLAGS, \flag
    rjmp branch_rel8_not_taken_func
    rjmp branch_rel8_taken_func
.endm

emit_branch_rel8_decode breq8_rel8_decode_func,  sbis, SREG_Z
emit_branch_rel8_decode brne8_rel8_decode_func,  sbic, SREG_Z
emit_branch_rel8_decode brult8_rel8_decode_func, sbis, SREG_C
emit_branch_rel8_decode brslt8_rel8_decode_func, sbis, SREG_S
emit_branch_rel8_decode bruge8_rel8_decode_func, sbic, SREG_C
emit_branch_rel8_decode brsge8_rel8_decode_func, sbic, SREG_S

branch_rel8_not_taken_func:
    ; PRIMARY_OPCODE contains the ignored displacement and VM_PC still names
    ; that byte. Six inline cycles of padding route through the reverse-order
    ; dispatch body, with the next OUT occurring 18 cycles after the speculative
    ; fallthrough OUT.
    delay_4
    delay_2
    rjmp cluster_tail_17

branch_rel8_taken_func:
    ; Form the signed high extension only on the taken path. Both sign cases
    ; take two cycles, which also lets the speculative fallthrough transfer
    ; finish before seek_and_dispatch_func toggles flash chip select.
    clr  r25
    sbrc PRIMARY_OPCODE, 7
    com  r25

    ; Convert the operand address to nextPC, then add the signed displacement
    ; in the full modulo-2^24 program address space.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    add  VM_PCL, PRIMARY_OPCODE
    adc  VM_PCM, r25
    adc  VM_PCH, r25
    rjmp seek_and_dispatch_func

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; DA-DF 16-bit conditional branches
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Primary-slot entry begins on cycle 9 after the OUT that started rel16[7:0].
; The slot and common prologue place a reverse handoff on cycle 17, launching
; rel16[15:8]. The condition is resolved while that byte transfers.
;
; A false condition launches the fallthrough opcode at the next cycle-17
; boundary and reuses the rel8 not-taken continuation. A true condition advances
; VM_PC to nextPC and enters the existing signed-rel16 target-add suffix, so its
; seek timing matches JMP16/CALL16.
branch_rel16_decode_func:
    ; Complete the carry chain started in the primary slot, capture the saved
    ; architectural flags, and launch rel16[15:8] exactly on cycle 17.
    adc  VM_PCH, ZERO
    in   r27, VM_FLAGS
    cli
    out  SPDR, ZERO
    in   r26, SPDR
    sei

    ; VM_PC named rel16[7:0] on entry. Advance it to rel16[15:8] while the high
    ; byte transfers. Opcode bit 0 requests the inverse condition; complementing
    ; the flag byte before masking makes all six conditions share one test.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    sbrc PRIMARY_OPCODE, 0
    com  r27
    and  r27, r25
    brne branch_rel16_taken_func

branch_rel16_not_taken_func:
    ; The false path begins on cycle 27. Six cycles of delay place a reverse
    ; handoff on cycle 34, launching the fallthrough primary opcode. VM_PC still
    ; names the high displacement byte, matching branch_rel8_not_taken_func's
    ; expected final-operand state.
    delay_4
    delay_2
    cli
    out  SPDR, ZERO
    in   PRIMARY_OPCODE, SPDR
    sei
    rjmp branch_rel8_not_taken_func

branch_rel16_taken_func:
    ; The taken path begins on cycle 28. Advance from the high displacement byte
    ; to nextPC, then arrive at rel16_read_high with CLR on cycle 33 and IN on
    ; cycle 34, exactly matching the JMP16/CALL16 high-byte schedule.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    rjmp rel16_read_high

branch_rel16_block_end:
.if (branch_rel16_block_end - branch_rel16_decode_func) != (25 * 2)
    .error "16-bit conditional branch subsystem must occupy exactly 50 bytes"
.endif

; D4 and D5 use fully specialized continuations. Duplicating the operand
; fetch, sign extension, next-PC calculation, and target addition removes the
; shared opcode test and avoids RCALL/RET overhead on CALL8.
jmp8_rel8_func:
    ; The operand transfer was started by the preceding primary dispatch. The
    ; continuation now begins one cycle earlier, so a three-cycle delay places
    ; this read at the first legal SPI byte boundary.
    delay_3
    in   r26, SPDR

    clr  r25
    sbrc r26, 7
    com  r25

    ; VM_PC currently names the displacement byte. Advance to nextPC, apply
    ; the signed displacement in modulo-2^24 arithmetic, and restart the stream.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    add  VM_PCL, r26
    adc  VM_PCM, r25
    adc  VM_PCH, r25
    rjmp seek_and_dispatch_func

call8_rel8_func:
    ; Advance to nextPC and push that 24-bit return address in the canonical
    ; little-endian stack layout: [SP+0]=PCL, [SP+1]=PCM, [SP+2]=PCH.
    ; Do this while rel8 transfers, replacing the old three-cycle wait. Entry
    ; is cycle 14: ADD/ADC/ADC 14-16, stores 17-22, CPI/BRLO 23-24. IN at 25
    ; is safely after completion; the checked call saves one exposed cycle.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    st   -Y, VM_PCH
    st   -Y, VM_PCM
    st   -Y, VM_PCL
    cpi  VM_SPH, hi8(data_stack)
    brlo stack_overflow_control

    in   r26, SPDR
    clr  r25
    sbrc r26, 7
    com  r25

    ; Form the branch target only after preserving nextPC, then restart the
    ; external-flash stream at that target.
    add  VM_PCL, r26
    adc  VM_PCM, r25
    adc  VM_PCH, r25
    rjmp seek_and_dispatch_func

adjsp_simm8_func:
    ; Read simm8 while starting the following primary opcode. VM_PC remains on
    ; the operand byte so the final standard dispatch advances it once afterward.
    ; The continuation begins on cycle 14, so the two-cycle landing makes the
    ; reverse OUT occur exactly 17 cycles after the operand-starting OUT.
    delay_2
    cli
    out  SPDR, ZERO
    in   PRIMARY_OPCODE, SPDR
    sei

    clr  r25
    sbrc PRIMARY_OPCODE, 7
    com  r25
    add  VM_SPL, PRIMARY_OPCODE
    adc  VM_SPH, r25

    ; Check the complete interval after arithmetic, without memory writes.
    ; Arithmetic 23-24, RJMP 25-26, six check cycles 27-32, standard ADD/IN/OUT
    ; 33/34/35, next primary entry 44: exactly 44 - 9 = 35 cycles. Replacing
    ; four padding cycles and the reverse tail hides both bound checks.
    rjmp stack_bounds_check

; Nearby fail-stop forwarding landing for CALL8, CALL16, and CALLF. Ordinary
; execution jumps around it; all checks finish before another guest executes.
stack_overflow_control:
    rjmp stack_overflow_func

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; E0-E3 direct near/far control
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; The first operand byte was started by the primary dispatch. Each paired
; JMP/CALL continuation reaches the exact 17-cycle boundary with useful work,
; then uses CLI/OUT/IN/SEI to launch the next operand byte. Opcode bit 0 selects
; the call path. CALL16's shorter one-word skip hides one check cycle; the other
; exposes one cycle. CALLF replaces padding and retains JMPF's latency.
; Remaining idle intervals use the shared callable delay ladder.

jmp_call_rel16_func:
    ; Fetch rel16[7:0] and launch rel16[15:8] with the exact reverse-order
    ; 17-cycle handoff. VM_PC initially names rel16[7:0].
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    cli
    out  SPDR, ZERO
    in   r26, SPDR
    sei
    adc  VM_PCH, ZERO

    ; Advance through rel16[15:8] to nextPC. Opcode bit 0 distinguishes CALL16
    ; from JMP16. A one-word RJMP makes the call's skip two cycles instead of
    ; three. CALL16 stores at 26-31 and checks at 32-33, then CLR/IN at 34/35.
    ; JMP16's wait grows by one cycle to preserve its original CLR/IN at 33/34;
    ; taken conditional branches still enter rel16_read_high directly.
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    sbrs PRIMARY_OPCODE, 0
    rjmp jmp_rel16_wait

    ; CALL16: preserve nextPC before applying the signed displacement.
    st   -Y, VM_PCH
    st   -Y, VM_PCM
    st   -Y, VM_PCL
    cpi  VM_SPH, hi8(data_stack)
    brlo stack_overflow_control

rel16_read_high:
    ; CLR is independent of the high displacement byte and fills the final
    ; cycle before that byte becomes readable.
    clr  r25
    in   r27, SPDR

    ; Add sign_extend(rel16) to nextPC in modulo-2^24 arithmetic.
    sbrc r27, 7
    com  r25
    add  VM_PCL, r26
    adc  VM_PCM, r27
    adc  VM_PCH, r25
    rjmp seek_and_dispatch_func

jmp_rel16_wait:
    delay_4
    rjmp rel16_read_high

jmp_call_far_func:
    ; Preserve opcode bit 0 before target[7:0] replaces PRIMARY_OPCODE. The MOV
    ; occupies the same one-cycle landing used by the specialized handlers, so
    ; target[15:8] still launches at the exact first 17-cycle boundary.
    mov  r27, PRIMARY_OPCODE
    nop
    cli
    out  SPDR, ZERO
    in   r24, SPDR
    sei

    ; E3 CALLF has already advanced VM_PC to nextPC in its primary slot. The
    ; CALL path uses the middle-byte transfer slack to push it. The E2 JMPF
    ; path uses an equal-time wait, so both launch target[23:16] at cycle 17.
    sbrs r27, 0
    jmp  jmp_far_wait
    st   -Y, VM_PCH
    st   -Y, VM_PCM
    st   -Y, VM_PCL
    ; CPI/BRLO plus two delay cycles replace the former four-cycle delay.
    ; The check follows all stores and precedes the target installation.
    cpi  VM_SPH, hi8(data_stack)
    brlo stack_overflow_control
    delay_2

far_launch_high:
    cli
    out  SPDR, ZERO
    in   r25, SPDR
    sei

    ; No further byte must be launched. Read target[23:16] at its earliest
    ; legal cycle, then install the complete absolute image-relative target.
    rcall interp_delay_14
    in   r26, SPDR
    mov  VM_PCL, r24
    mov  VM_PCM, r25
    mov  VM_PCH, r26
    rjmp seek_and_dispatch_func

jmp_far_wait:
    rcall interp_delay_7
    rjmp far_launch_high

; Keep the unknown-service trap within conditional-branch reach of the guard.
invalid_syscall_func:
    rjmp invalid_syscall_func

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; SYS service dispatch
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Entry state:
;   * VM PC points at the following primary opcode.
;   * SPDR contains the completed service byte.
;   * The byte following the service has not yet been started.
;
; The protected SPDR handoff starts fetching the following primary opcode and
; captures the service ID. Each service returns through a cadence-appropriate
; cluster tail, which consumes that opcode, starts its following byte, advances
; the PC, and enters its four-word primary slot.
sys_decode_func:
    ; The D7 primary slot reaches this continuation on cycle 14. Preloading the
    ; dispatch-table base fills cycles 14 and 15, then the reverse OUT lands on
    ; cycle 17 without a pure delay.
    ldi  r30, lo8(pm(sys_dispatch_table))
    ldi  r31, hi8(pm(sys_dispatch_table))
    cli
    out  SPDR, ZERO
    in   PRIMARY_OPCODE, SPDR
    sei

sys_dispatch_func:
    cpi  PRIMARY_OPCODE, SYS_GET_SYSTEM_DISPLAY_TYPE+1
    brsh invalid_syscall_func
    add  r30, PRIMARY_OPCODE
    adc  r31, ZERO
    ijmp

.macro sys_entries count, target
    .rept \count
        rjmp \target
    .endr
.endm

.if (SYS_DEBUG_PUTC != 0x00)
    .error "SYS_DEBUG_PUTC must occupy dispatch-table entry 0"
.endif
.if (SYS_DEBUG_BREAK != 0x01)
    .error "SYS_DEBUG_BREAK must occupy dispatch-table entry 1"
.endif
.if (SYS_MILLIS != 0x02)
    .error "SYS_MILLIS must occupy dispatch-table entry 2"
.endif
.if (SYS_MILLIS32 != 0x03)
    .error "SYS_MILLIS32 must occupy dispatch-table entry 3"
.endif
.if (SYS_SINF != 0x04) || (SYS_COSF != 0x05) || (SYS_ATAN2F != 0x06) || \
    (SYS_TANF != 0x07) || (SYS_EXPF != 0x08) || (SYS_LOGF != 0x09) || \
    (SYS_LOG2F != 0x0A) || (SYS_LOG10F != 0x0B) || (SYS_POWF != 0x0C) || \
    (SYS_HYPOTF != 0x0D) || (SYS_FMODF != 0x0E)
    .error "libm SYS services must occupy contiguous entries 0x04-0x0E"
.endif
.if (SYS_MEMCPY != 0x0F) || (SYS_MEMCPY_P != 0x10) || \
    (SYS_MEMSET != 0x11) || (SYS_MEMMOVE != 0x12) || \
    (SYS_MEMCMP_P != 0x13) || (SYS_STRCMP_P != 0x14) || \
    (SYS_STRLEN_P != 0x15) || (SYS_STRNCPY_P != 0x16) || \
    (SYS_STRNCAT_P != 0x17) || (SYS_MEMCMP != 0x18) || \
    (SYS_STRCMP != 0x19) || (SYS_STRLEN != 0x1A) || \
    (SYS_STRNCPY != 0x1B) || (SYS_STRNCAT != 0x1C)
    .error "memory SYS services must occupy contiguous entries 0x0F-0x1C"
.endif
.if (SYS_DISPLAY != 0x1D)
    .error "SYS_DISPLAY must occupy dispatch-table entry 0x1D"
.endif
.if (SYS_DRAW_SPRITE_OVERWRITE != 0x1E) || \
    (SYS_DRAW_SPRITE_PLUS_MASK != 0x1F) || \
    (SYS_DRAW_SPRITE_SELF_MASKED != 0x20) || \
    (SYS_DRAW_SPRITE_ERASE != 0x21)
    .error "explicit-pointer sprite SYS services must occupy contiguous entries 0x1E-0x21"
.endif
.if (SYS_SET_SPRITE != 0x22)
    .error "SYS_SET_SPRITE must occupy dispatch-table entry 0x22"
.endif
.if (SYS_DRAW_OVERWRITE != 0x23) || \
    (SYS_DRAW_PLUS_MASK != 0x24) || \
    (SYS_DRAW_SELF_MASKED != 0x25) || \
    (SYS_DRAW_ERASE != 0x26)
    .error "cached-pointer sprite SYS services must occupy contiguous entries 0x23-0x26"
.endif
.if (SYS_DRAW_FILLED_RECT_WHITE != 0x27) || \
    (SYS_DRAW_FILLED_RECT_BLACK != 0x28)
    .error "filled-rectangle SYS services must occupy contiguous entries 0x27-0x28"
.endif
.if (SYS_BUTTONS != 0x29) || (SYS_IDLE != 0x2A) || \
    (SYS_GENERATE_RANDOM_SEED != 0x2B) || (SYS_SAVE != 0x2C) || \
    (SYS_LOAD != 0x2D) || (SYS_SAVE_EXISTS != 0x2E)
    .error "platform/persistence SYS services must occupy contiguous entries 0x29-0x2E"
.endif
.if (SYS_VSNPRINTF != 0x2F) || (SYS_VSNPRINTF_P != 0x30)
    .error "formatting SYS services must occupy contiguous entries 0x2F-0x30"
.endif
.if (SYS_SET_TEXT_FONT != 0x31) || (SYS_SET_TEXT_MODE != 0x32) || \
    (SYS_DRAW_TEXT != 0x33) || (SYS_DRAW_TEXT_P != 0x34) || \
    (SYS_DRAW_TEXTFV != 0x35) || (SYS_DRAW_TEXTFV_P != 0x36)
    .error "text SYS services must occupy contiguous entries 0x31-0x36"
.endif
.if (SYS_DEBUG_PRINTFV_P != 0x37)
    .error "SYS_DEBUG_PRINTFV_P must occupy dispatch-table entry 0x37"
.endif
.if (SYS_AUDIO != 0x38)
    .error "SYS_AUDIO must occupy dispatch-table entry 0x38"
.endif
.if (SYS_SEND_DISPLAY_COMMAND != 0x39) || (SYS_GET_SYSTEM_WIDTH != 0x3A) || \
    (SYS_GET_SYSTEM_HEIGHT != 0x3B) || (SYS_GET_SYSTEM_DISPLAY_TYPE != 0x3C)
    .error "display command and system queries must occupy entries 0x39-0x3C"
.endif

; One AVR word per service number. The service byte therefore indexes this
; table directly in program-memory word-address space.
sys_dispatch_table:
    sys_entries 1,   sys_debug_putc_func
    sys_entries 1,   sys_debug_break_func
    sys_entries 1,   sys_millis_func
    sys_entries 1,   sys_millis32_func
    sys_entries 11,  sys_libm_func
    sys_entries 1,   sys_memcpy_func
    sys_entries 1,   sys_memcpy_p_func
    sys_entries 1,   sys_memset_func
    sys_entries 1,   sys_memmove_func
    sys_entries 1,   sys_memcmp_p_impl
    sys_entries 1,   sys_strcmp_p_impl
    sys_entries 1,   sys_strlen_p_impl
    sys_entries 1,   sys_strncpy_p_impl
    sys_entries 1,   sys_strncat_p_impl
    sys_entries 1,   sys_memcmp_impl
    sys_entries 1,   sys_strcmp_impl
    sys_entries 1,   sys_strlen_impl
    sys_entries 1,   sys_strncpy_impl
    sys_entries 1,   sys_strncat_impl
    sys_entries 1,   sys_display_impl
    sys_entries 4,   sys_draw_sprite_func
    sys_entries 1,   sys_set_sprite_func
    sys_entries 4,   sys_draw_func
    sys_entries 2,   sys_draw_filled_rect_func
    sys_entries 6,   sys_platform_func
    sys_entries 2,   sys_format_func
    sys_entries 1,   sys_set_text_font_func
    sys_entries 1,   sys_set_text_mode_func
    sys_entries 1,   sys_draw_text_func
    sys_entries 1,   sys_draw_text_p_func
    sys_entries 1,   sys_draw_textfv_func
    sys_entries 1,   sys_draw_textfv_p_func
    sys_entries 1,   sys_debug_printfv_p_func
    sys_entries 1,   sys_audio_func
    sys_entries 1,   sys_send_display_command_func
    sys_entries 3,   sys_system_info_func
sys_dispatch_table_end:

.if (sys_dispatch_table_end - sys_dispatch_table) != ((SYS_GET_SYSTEM_DISPLAY_TYPE+1) * 2)
    .error "SYS dispatch table must contain exactly the defined service entries"
.endif

; Keep the one-word SYS table within RJMP reach while placing the larger memory
; implementations after the existing interpreter body. Absolute veneers limit
; movement of the carefully range-constrained code below to eight AVR words.
sys_memcpy_func:
    jmp   sys_memcpy_impl
sys_audio_func:
    jmp   sys_audio_impl
sys_send_display_command_func:
    jmp   sys_send_display_command_impl
sys_system_info_func:
    jmp   sys_system_info_impl
sys_memcpy_p_func:
    jmp   sys_memcpy_p_impl
sys_memset_func:
    jmp   sys_memset_impl
sys_memmove_func:
    jmp   sys_memmove_impl

; The four contiguous sprite service IDs normalize directly to mode 0-3. A
; single four-word absolute veneer keeps movement of the range-constrained code
; below within the existing eight-word placement allowance.
sys_draw_sprite_func:
    subi  PRIMARY_OPCODE, SYS_DRAW_SPRITE_OVERWRITE
    mov   r27, PRIMARY_OPCODE
    jmp   sys_draw_sprite_header_impl

; SET_SPRITE and the four cached-pointer draw services live beside the sprite
; implementation. Absolute veneers keep the one-word SYS table within RJMP
; reach while limiting movement of the range-constrained code below.
sys_set_sprite_func:
    jmp   sys_set_sprite_impl

sys_draw_func:
    subi  PRIMARY_OPCODE, SYS_DRAW_OVERWRITE
    mov   r27, PRIMARY_OPCODE
    jmp   sys_draw_cached_impl

; The two fixed-color rectangle entries share a far implementation. The raw
; service number remains in PRIMARY_OPCODE so bit zero can select white/black.
sys_draw_filled_rect_func:
    jmp   sys_draw_filled_rect_impl

; The six contiguous platform/persistence services share one far dispatcher,
; minimizing movement of the range-constrained interpreter core.
sys_platform_func:
    jmp   sys_platform_dispatch_impl

; The two contiguous formatting services normalize to source mode 0=RAM or
; 1=program memory before entering their shared implementation.
sys_format_func:
    subi  PRIMARY_OPCODE, SYS_VSNPRINTF
    jmp   sys_format_impl

; Text services use dedicated near veneers. This avoids the former far
; six-way compare dispatcher and installs the source/sink status before the
; speculative following-opcode byte replaces PRIMARY_OPCODE.
sys_set_text_font_func:
    jmp   sys_set_text_font_impl
sys_set_text_mode_func:
    jmp   sys_set_text_mode_impl
sys_draw_text_func:
    ldi   PRIMARY_OPCODE, (1 << FORMAT_STATUS_SINK_TEXT)
    jmp   sys_text_raw_impl
sys_draw_text_p_func:
    ldi   PRIMARY_OPCODE, ((1 << FORMAT_STATUS_SINK_TEXT) | \
                           (1 << FORMAT_STATUS_SOURCE_PROGRAM))
    jmp   sys_text_raw_impl
sys_draw_textfv_func:
    ldi   PRIMARY_OPCODE, (1 << FORMAT_STATUS_SINK_TEXT)
    jmp   sys_format_impl
sys_draw_textfv_p_func:
    ldi   PRIMARY_OPCODE, ((1 << FORMAT_STATUS_SINK_TEXT) | \
                           (1 << FORMAT_STATUS_SOURCE_PROGRAM))
    jmp   sys_format_impl
sys_debug_printfv_p_func:
    ldi   PRIMARY_OPCODE, ((1 << FORMAT_STATUS_SINK_DEBUG) | \
                           (1 << FORMAT_STATUS_SOURCE_PROGRAM))
    jmp   sys_format_impl

sys_debug_putc_func:
    ; DEBUG_PUTC writes low8(r4) to the emulator/debug USB endpoint register.
    ; The bounds check adds two cycles. A padded standard tail consumes the
    ; following opcode on cycle 17 and launches its following byte on cycle 18.
    sts  UEDATX, VM_R4L
    rjmp cluster_tail_18_delay_1

sys_debug_break_func:
    ; BREAK is one cycle shorter than DEBUG_PUTC's STS. Use the existing
    ; extra-cycle standard landing to retain the same cycle-18 OUT as PUTC.
    break
    rjmp cluster_tail_18_delay_2

; Return a coherent low 16-bit snapshot of the millisecond counter in r4.
sys_millis_func:
    cli
    lds  VM_R4L, data_millis+0
    lds  VM_R4H, data_millis+1
    sei
    rjmp cluster_tail_18

; Return a coherent 32-bit snapshot with the low half in r4 and high half in
; r5. Timer0 cannot update the counter during the four-byte snapshot.
sys_millis32_func:
    cli
    lds  VM_R4L, data_millis+0
    lds  VM_R4H, data_millis+1
    lds  VM_R5L, data_millis+2
    lds  VM_R5H, data_millis+3
    sei
    rjmp cluster_tail_18

; Shared avr-libc/libm SYS ABI:
;   unary argument / result: q2 (native r16-r19)
;   binary second argument:  q3 (native r20-r23)
;
; Every listed service uses the same bridge. Unary routines simply ignore the
; B argument copied from q3. The standard AVR ABI preserves native r2-r17 and
; Y. q2 is replaced by the result, while the bridge explicitly preserves q3
; across the helper call.
sys_libm_func:
    subi PRIMARY_OPCODE, SYS_SINF
    lsl  PRIMARY_OPCODE
    ldi  r30, lo8(sys_libm_target_table)
    ldi  r31, hi8(sys_libm_target_table)
    add  r30, PRIMARY_OPCODE
    adc  r31, ZERO
    lpm  r0, Z+
    lpm  r31, Z
    mov  r30, r0

    push r20
    push r21
    push r22
    push r23

    ; Marshal q2 into avr-libc argument A (r22-r25) and q3 into argument B
    ; (r18-r21). The order avoids destroying q2 high or q3 high while the
    ; native register ranges overlap.
    movw r24, VM_R5       ; q2 high half
    movw r18, VM_R6       ; q3 low half
    movw r20, VM_R7       ; q3 high half
    movw r22, VM_R4       ; q2 low half
    icall

    movw VM_R4, r22
    movw VM_R5, r24

    pop  r23
    pop  r22
    pop  r21
    pop  r20
    rjmp cluster_tail_18

; Program-memory word addresses consumed by ICALL. Keep this order identical
; to SYS_SINF through SYS_FMODF above.
sys_libm_target_table:
    .word pm(sinf)
    .word pm(cosf)
    .word pm(atan2f)
    .word pm(tanf)
    .word pm(expf)
    .word pm(logf)
    .word pm(log2f)
    .word pm(log10f)
    .word pm(powf)
    .word pm(hypotf)
    .word pm(fmodf)

; JMPP reaches this one-word forwarding landing on cycle 15; its RJMP enters
; the seek handler on cycle 17, after the discarded speculative byte completes.
jmpp_seek_and_dispatch_func:
    rjmp seek_and_dispatch_func

stack_overflow_indirect:
    rjmp stack_overflow_func

; CALLP shared prologue. The primary slot preserved the selected target in
; r26:r25:r24 and performed the low-byte increment from the CALLP opcode to its
; sequential return address. Finish the 24-bit carry chain, push PC+1 in
; canonical little-endian stack layout, install the target, and fall through
; directly into the common seek handler.
push_pc_seek_and_dispatch_func:
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    st   -Y, VM_PCH
    st   -Y, VM_PCM
    st   -Y, VM_PCL
    ; Shared by all four specialized CALLP slots. Both useful check cycles
    ; are exposed (+2); JMPP and the common seek timing are unchanged.
    cpi  VM_SPH, hi8(data_stack)
    brlo stack_overflow_indirect
    movw VM_PCL, r24
    mov  VM_PCH, r26

; Shared continuation for JMPP, CALLP, RET, and taken control-flow instructions.
; On entry, VM_PCH:VM_PCM:VM_PCL is the new image-relative program counter.
; Seek the external-flash stream to VM_PC, consume the target primary opcode,
; start its following-byte fetch, and dispatch directly to that primary slot.
seek_and_dispatch_func:
    fx_disable
seek_and_dispatch_func_disabled:
    lds  r30, data_audio_ticks_pending
    tst  r30
    brne audio_service_and_seek
seek_and_dispatch_no_audio:
    ldi  r30, SFC_READ
    fx_enable
    out  SPDR, r30

    lds  r26, data_page_data+0
    add  r26, VM_PCM
    lds  r27, data_page_data+1
    adc  r27, VM_PCH

    ; SFC_READ and each address byte are meaningful transmitted data, so
    ; command-to-address-high also requires the 18-cycle OUT-to-OUT cadence.
    rcall interp_delay_11
    out  SPDR, r27
    rcall interp_delay_17
    out  SPDR, r26
    rcall interp_delay_17
    out  SPDR, VM_PCL
    rcall interp_delay_16
    out  SPDR, ZERO
    rcall interp_delay_15
    cli
    out  SPDR, ZERO
    in   PRIMARY_OPCODE, SPDR
    sei
    mul  PRIMARY_OPCODE, FOUR
    movw r30, r0
    subi r31, hi8(-(pm(primary_table)))
    ijmp

audio_service_and_seek:
    call audio_service_func
    rjmp seek_and_dispatch_no_audio

; Local fixed-delay ladder for pre-table interpreter paths. The large dense
; secondary tables place the original fx_seek_delay_* ladder outside RCALL's
; signed 12-bit word displacement. Each entry retains the same total delay,
; measured from the calling RCALL through the returning RET.
interp_delay_17:
    nop
interp_delay_16:
    nop
interp_delay_15:
    nop
interp_delay_14:
    nop
interp_delay_13:
    nop
interp_delay_12:
    nop
interp_delay_11:
    nop
interp_delay_10:
    nop
interp_delay_9:
    delay_2
interp_delay_7:
    ret

; Reserved primary encodings stop here.
invalid_primary_instruction_func:
    rjmp invalid_primary_instruction_func

; Reserved secondary encodings use this shared trap.
invalid_secondary_instruction_func:
    rjmp invalid_secondary_instruction_func

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Fixed-width secondary tables and F0 veneer scaffolding
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; F1-F8 use their exact operand-specialized native sequences. Every valid F0
; veneer forwards to an implemented cold body. FA traps reserved values through
; its immediate body-jump table.

.macro emit_secondary_trap_table label, end_label, count, width, trap
\label:
    .rept \count
        rjmp \trap
        .rept (\width - 1)
            nop
        .endr
    .endr
\end_label:
    .if (\end_label - \label) != (2 * \count * \width)
        .error "secondary trap table has incorrect size"
    .endif
.endm


; Exact fixed-width slot emitters for F1-F8. Each macro expands to the native
; sequence specified by the ISA implementation plan and asserts its natural
; AVR word count. No slot contains padding except reserved postincrement-load
; aliases, which remain same-width invalid-instruction entries.

.macro emit_f1_mov dst, src
.Lf1_mov_start_\@:
    movw  \dst, \src
    rjmp  cluster_a_tail_17_delay_1
.Lf1_mov_end_\@:
    .if (.Lf1_mov_end_\@ - .Lf1_mov_start_\@) != 4
        .error "F1 MOV slot is not exactly two words"
    .endif
.endm

.macro emit_f1_stsp8 src, q
.Lf1_stsp8_start_\@:
    std   Y+\q, \src
    rjmp  cluster_a_tail_17
.Lf1_stsp8_end_\@:
    .if (.Lf1_stsp8_end_\@ - .Lf1_stsp8_start_\@) != 4
        .error "F1 STSP8 slot is not exactly two words"
    .endif
.endm

.macro emit_f1_zext8 dsth
.Lf1_zext8_start_\@:
    clr   \dsth
    rjmp  cluster_a_tail_17_delay_1
.Lf1_zext8_end_\@:
    .if (.Lf1_zext8_end_\@ - .Lf1_zext8_start_\@) != 4
        .error "F1 ZEXT8 slot is not exactly two words"
    .endif
.endm

.macro emit_f1_swap8 dstl
.Lf1_swap8_start_\@:
    swap  \dstl
    rjmp  cluster_a_tail_17_delay_1
.Lf1_swap8_end_\@:
    .if (.Lf1_swap8_end_\@ - .Lf1_swap8_start_\@) != 4
        .error "F1 SWAP8 slot is not exactly two words"
    .endif
.endm

.macro emit_f1_getsp dst
.Lf1_getsp_start_\@:
    movw  \dst, VM_SP
    rjmp  cluster_a_tail_17_delay_1
.Lf1_getsp_end_\@:
    .if (.Lf1_getsp_end_\@ - .Lf1_getsp_start_\@) != 4
        .error "F1 GETSP slot is not exactly two words"
    .endif
.endm

.macro emit_f1_setsp src
.Lf1_setsp_start_\@:
    ; Assign without memory access, then share ADJSP's full-range validator.
    ; Two-word table geometry and source-register specialization are retained.
    movw  VM_SP, \src
    rjmp  stack_bounds_check
.Lf1_setsp_end_\@:
    .if (.Lf1_setsp_end_\@ - .Lf1_setsp_start_\@) != 4
        .error "F1 SETSP slot is not exactly two words"
    .endif
.endm

.macro emit_f2_add dstl, dsth, srcl, srch
.Lf2_add_start_\@:
    add   \dstl, \srcl
    adc   \dsth, \srch
    rjmp  cluster_a_tail_17
.Lf2_add_end_\@:
    .if (.Lf2_add_end_\@ - .Lf2_add_start_\@) != 6
        .error "F2 ADD slot is not exactly three words"
    .endif
.endm

.macro emit_f2_sub dstl, dsth, srcl, srch
.Lf2_sub_start_\@:
    sub   \dstl, \srcl
    sbc   \dsth, \srch
    rjmp  cluster_a_tail_17
.Lf2_sub_end_\@:
    .if (.Lf2_sub_end_\@ - .Lf2_sub_start_\@) != 6
        .error "F2 SUB slot is not exactly three words"
    .endif
.endm

.macro emit_f2_mov32 dst0, dst2, src0, src2
.Lf2_mov32_start_\@:
    movw  \dst0, \src0
    movw  \dst2, \src2
    rjmp  cluster_a_tail_17
.Lf2_mov32_end_\@:
    .if (.Lf2_mov32_end_\@ - .Lf2_mov32_start_\@) != 6
        .error "F2 MOV32 slot is not exactly three words"
    .endif
.endm

.macro emit_f3_st8 addr, srcl
.Lf3_st8_start_\@:
    movw  r26, \addr
    st    X, \srcl
    rjmp  cluster_a_tail_18_delay_1
.Lf3_st8_end_\@:
    .if (.Lf3_st8_end_\@ - .Lf3_st8_start_\@) != 6
        .error "F3 ST8 slot is not exactly three words"
    .endif
.endm

.macro emit_f3_mul op, dstl, srcl
.Lf3_mul_start_\@:
    \op   \dstl, \srcl
    movw  \dstl, r0
    rjmp  cluster_a_tail_18_delay_1
.Lf3_mul_end_\@:
    .if (.Lf3_mul_end_\@ - .Lf3_mul_start_\@) != 6
        .error "F3 widening multiply slot is not exactly three words"
    .endif
.endm

.macro emit_f3_ldsp8u dstl, dsth, q
.Lf3_ldsp8u_start_\@:
    ldd   \dstl, Y+\q
    clr   \dsth
    rjmp  cluster_a_tail_18_delay_1
.Lf3_ldsp8u_end_\@:
    .if (.Lf3_ldsp8u_end_\@ - .Lf3_ldsp8u_start_\@) != 6
        .error "F3 LDSP8U slot is not exactly three words"
    .endif
.endm

.macro emit_f4_ldsp16 dstl, dsth, q0, q1
.Lf4_ldsp16_start_\@:
    ldd   \dstl, Y+\q0
    ldd   \dsth, Y+\q1
    rjmp  cluster_b_tail_18
.Lf4_ldsp16_end_\@:
    .if (.Lf4_ldsp16_end_\@ - .Lf4_ldsp16_start_\@) != 6
        .error "F4 LDSP16 slot is not exactly three words"
    .endif
.endm

.macro emit_f4_stsp16 srcl, srch, q0, q1
.Lf4_stsp16_start_\@:
    std   Y+\q0, \srcl
    std   Y+\q1, \srch
    rjmp  cluster_b_tail_18
.Lf4_stsp16_end_\@:
    .if (.Lf4_stsp16_end_\@ - .Lf4_stsp16_start_\@) != 6
        .error "F4 STSP16 slot is not exactly three words"
    .endif
.endm

.macro emit_f4_shift op_hi, op_lo, dstl, dsth
.Lf4_shift_start_\@:
    \op_hi \dsth
    \op_lo \dstl
    rjmp  cluster_b_tail_17
.Lf4_shift_end_\@:
    .if (.Lf4_shift_end_\@ - .Lf4_shift_start_\@) != 6
        .error "F4 shift slot is not exactly three words"
    .endif
.endm

.macro emit_f4_lsl16 dstl, dsth
.Lf4_lsl16_start_\@:
    lsl   \dstl
    rol   \dsth
    rjmp  cluster_b_tail_17
.Lf4_lsl16_end_\@:
    .if (.Lf4_lsl16_end_\@ - .Lf4_lsl16_start_\@) != 6
        .error "F4 LSL16 slot is not exactly three words"
    .endif
.endm

.macro emit_f4_not16 dstl, dsth
.Lf4_not16_start_\@:
    com   \dstl
    com   \dsth
    rjmp  cluster_b_tail_17
.Lf4_not16_end_\@:
    .if (.Lf4_not16_end_\@ - .Lf4_not16_start_\@) != 6
        .error "F4 NOT16 slot is not exactly three words"
    .endif
.endm

.macro emit_f4_tst8 dstl
.Lf4_tst8_start_\@:
    cp    \dstl, ZERO
    in    SECONDARY_OPCODE, SREG
    rjmp  flags_commit_b_18_delay_1
.Lf4_tst8_end_\@:
    .if (.Lf4_tst8_end_\@ - .Lf4_tst8_start_\@) != 6
        .error "F4 TST8 slot is not exactly three words"
    .endif
.endm

.macro emit_f4_inc16 dstl, dsth
.Lf4_inc16_start_\@:
    add   \dstl, ONE
    adc   \dsth, ZERO
    rjmp  cluster_b_tail_17
.Lf4_inc16_end_\@:
    .if (.Lf4_inc16_end_\@ - .Lf4_inc16_start_\@) != 6
        .error "F4 INC16 slot is not exactly three words"
    .endif
.endm

.macro emit_f4_dec16 dstl, dsth
.Lf4_dec16_start_\@:
    sub   \dstl, ONE
    sbc   \dsth, ZERO
    rjmp  cluster_b_tail_17
.Lf4_dec16_end_\@:
    .if (.Lf4_dec16_end_\@ - .Lf4_dec16_start_\@) != 6
        .error "F4 DEC16 slot is not exactly three words"
    .endif
.endm

.macro emit_f5_cmp lhsl, lhsh, rhsl, rhsh
.Lf5_cmp_start_\@:
    cp    \lhsl, \rhsl
    cpc   \lhsh, \rhsh
    in    SECONDARY_OPCODE, SREG
    rjmp  flags_commit_b_18_delay_1
.Lf5_cmp_end_\@:
    .if (.Lf5_cmp_end_\@ - .Lf5_cmp_start_\@) != 8
        .error "F5 CMP slot is not exactly four words"
    .endif
.endm

.macro emit_f5_ld8u dstl, dsth, addr
.Lf5_ld8u_start_\@:
    movw  r26, \addr
    ld    \dstl, X
    clr   \dsth
    rjmp  cluster_b_tail_18
.Lf5_ld8u_end_\@:
    .if (.Lf5_ld8u_end_\@ - .Lf5_ld8u_start_\@) != 8
        .error "F5 LD8U slot is not exactly four words"
    .endif
.endm

.macro emit_f5_ld16 dstl, dsth, addr
.Lf5_ld16_start_\@:
    movw  r26, \addr
    ld    \dstl, X+
    ld    \dsth, X
    rjmp  cluster_b_tail_18
.Lf5_ld16_end_\@:
    .if (.Lf5_ld16_end_\@ - .Lf5_ld16_start_\@) != 8
        .error "F5 LD16 slot is not exactly four words"
    .endif
.endm

.macro emit_f5_st16 addr, srcl, srch
.Lf5_st16_start_\@:
    movw  r26, \addr
    st    X+, \srcl
    st    X, \srch
    rjmp  cluster_b_tail_18
.Lf5_st16_end_\@:
    .if (.Lf5_st16_end_\@ - .Lf5_st16_start_\@) != 8
        .error "F5 ST16 slot is not exactly four words"
    .endif
.endm

.macro emit_f6_st8_post addr, srcl
.Lf6_st8_post_start_\@:
    movw  r26, \addr
    st    X+, \srcl
    movw  \addr, r26
    rjmp  cluster_b_tail_18
.Lf6_st8_post_end_\@:
    .if (.Lf6_st8_post_end_\@ - .Lf6_st8_post_start_\@) != 8
        .error "F6 ST8 postincrement slot is not exactly four words"
    .endif
.endm

.macro emit_f6_bswap16 dstl, dsth
.Lf6_bswap16_start_\@:
    mov   SECONDARY_OPCODE, \dstl
    mov   \dstl, \dsth
    mov   \dsth, SECONDARY_OPCODE
    rjmp  cluster_b_tail_18_delay_1
.Lf6_bswap16_end_\@:
    .if (.Lf6_bswap16_end_\@ - .Lf6_bswap16_start_\@) != 8
        .error "F6 BSWAP16 slot is not exactly four words"
    .endif
.endm

.macro emit_f6_tst16 dstl, dsth
.Lf6_tst16_start_\@:
    cp    \dstl, ZERO
    cpc   \dsth, ZERO
    in    SECONDARY_OPCODE, SREG
    rjmp  flags_commit_b_18_delay_1
.Lf6_tst16_end_\@:
    .if (.Lf6_tst16_end_\@ - .Lf6_tst16_start_\@) != 8
        .error "F6 TST16 slot is not exactly four words"
    .endif
.endm

.macro emit_f6_mul8 dstl, dsth, srcl
.Lf6_mul8_start_\@:
    mul   \dstl, \srcl
    mov   \dstl, r0
    clr   \dsth
    rjmp  cluster_b_tail_18
.Lf6_mul8_end_\@:
    .if (.Lf6_mul8_end_\@ - .Lf6_mul8_start_\@) != 8
        .error "F6 MUL8 slot is not exactly four words"
    .endif
.endm

.macro emit_f6_sext8 dstl, dsth
.Lf6_sext8_start_\@:
    clr   \dsth
    sbrc  \dstl, 7
    dec   \dsth
    rjmp  cluster_b_tail_18_delay_1
.Lf6_sext8_end_\@:
    .if (.Lf6_sext8_end_\@ - .Lf6_sext8_start_\@) != 8
        .error "F6 SEXT8 slot is not exactly four words"
    .endif
.endm

.macro emit_f6_neg16 dstl, dsth
.Lf6_neg16_start_\@:
    neg   \dstl
    adc   \dsth, ZERO
    neg   \dsth
    rjmp  cluster_b_tail_18_delay_1
.Lf6_neg16_end_\@:
    .if (.Lf6_neg16_end_\@ - .Lf6_neg16_start_\@) != 8
        .error "F6 NEG16 slot is not exactly four words"
    .endif
.endm

.macro emit_f7_ld8u_post dstl, dsth, addr
.Lf7_ld8u_post_start_\@:
    movw  r26, \addr
    ld    \dstl, X+
    movw  \addr, r26
    clr   \dsth
    rjmp  cluster_c_tail_18
.Lf7_ld8u_post_end_\@:
    .if (.Lf7_ld8u_post_end_\@ - .Lf7_ld8u_post_start_\@) != 10
        .error "F7 LD8U postincrement slot is not exactly five words"
    .endif
.endm

.macro emit_f7_ld16_post dstl, dsth, addr
.Lf7_ld16_post_start_\@:
    movw  r26, \addr
    ld    \dstl, X+
    ld    \dsth, X+
    movw  \addr, r26
    rjmp  cluster_c_tail_18
.Lf7_ld16_post_end_\@:
    .if (.Lf7_ld16_post_end_\@ - .Lf7_ld16_post_start_\@) != 10
        .error "F7 LD16 postincrement slot is not exactly five words"
    .endif
.endm

.macro emit_f7_st16_post addr, srcl, srch
.Lf7_st16_post_start_\@:
    movw  r26, \addr
    st    X+, \srcl
    st    X+, \srch
    movw  \addr, r26
    rjmp  cluster_c_tail_18
.Lf7_st16_post_end_\@:
    .if (.Lf7_st16_post_end_\@ - .Lf7_st16_post_start_\@) != 10
        .error "F7 ST16 postincrement slot is not exactly five words"
    .endif
.endm

.macro emit_f7_add32 d0, d1, d2, d3, s0, s1, s2, s3
.Lf7_add32_start_\@:
    add   \d0, \s0
    adc   \d1, \s1
    adc   \d2, \s2
    adc   \d3, \s3
    rjmp  cluster_c_tail_18
.Lf7_add32_end_\@:
    .if (.Lf7_add32_end_\@ - .Lf7_add32_start_\@) != 10
        .error "F7 ADD32 slot is not exactly five words"
    .endif
.endm

.macro emit_f7_sub32 d0, d1, d2, d3, s0, s1, s2, s3
.Lf7_sub32_start_\@:
    sub   \d0, \s0
    sbc   \d1, \s1
    sbc   \d2, \s2
    sbc   \d3, \s3
    rjmp  cluster_c_tail_18
.Lf7_sub32_end_\@:
    .if (.Lf7_sub32_end_\@ - .Lf7_sub32_start_\@) != 10
        .error "F7 SUB32 slot is not exactly five words"
    .endif
.endm

.macro emit_f7_lsr32 d0, d1, d2, d3
.Lf7_lsr32_start_\@:
    lsr   \d3
    ror   \d2
    ror   \d1
    ror   \d0
    rjmp  cluster_c_tail_18
.Lf7_lsr32_end_\@:
    .if (.Lf7_lsr32_end_\@ - .Lf7_lsr32_start_\@) != 10
        .error "F7 LSR32 slot is not exactly five words"
    .endif
.endm

.macro emit_f7_asr32 d0, d1, d2, d3
.Lf7_asr32_start_\@:
    asr   \d3
    ror   \d2
    ror   \d1
    ror   \d0
    rjmp  cluster_c_tail_18
.Lf7_asr32_end_\@:
    .if (.Lf7_asr32_end_\@ - .Lf7_asr32_start_\@) != 10
        .error "F7 ASR32 slot is not exactly five words"
    .endif
.endm

.macro emit_f7_bool dstl, dsth
.Lf7_bool_start_\@:
    or    \dstl, \dsth
    clr   \dsth
    cpse  \dstl, ZERO
    mov   \dstl, ONE
    rjmp  cluster_c_tail_18
.Lf7_bool_end_\@:
    .if (.Lf7_bool_end_\@ - .Lf7_bool_start_\@) != 10
        .error "F7 BOOL slot is not exactly five words"
    .endif
.endm

.macro emit_f7_invalid trap
.Lf7_invalid_start_\@:
    rjmp  \trap
    nop
    nop
    nop
    nop
.Lf7_invalid_end_\@:
    .if (.Lf7_invalid_end_\@ - .Lf7_invalid_start_\@) != 10
        .error "F7 reserved slot is not exactly five words"
    .endif
.endm

.macro emit_cmov_entry dst, src
.Lcmov_start_\@:
    movw  \dst, \src
    rjmp  cmov_tail
.Lcmov_end_\@:
    .if (.Lcmov_end_\@ - .Lcmov_start_\@) != 4
        .error "FB-FD CMOV entry is not exactly two AVR words"
    .endif
.endm

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Secondary-page cadence clusters and table insertion anchors
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; These copies are intentionally separate from the one-byte primary tails.
; Future secondary tables are inserted at the marked anchors so every slot's
; final RJMP remains comfortably within range without changing these sequences.

; Cluster A also supplies the unchanged one-cycle primary landing for
; LD8U/POP16 and the cold F0 callers formerly beside cluster_tail_18.
; Cluster A serves F0/F1/F2/F3, the dedicated F9 decoder, cold F0 bodies,
; and the FB-FD condition gate/table. FA and FE shared bodies use Cluster C.
; The CMOV false path reaches this landing twelve cycles after launching the
; following-primary transfer. NOP plus the two-cycle RJMP supply exactly three
; cycles, so the reverse tail's OUT lands on cycle 17. The two-cycle F1 landing
; shares the RJMP. Keep both entries outside the measured 24-word cluster.
cluster_a_tail:
    nop
cluster_a_tail_17_delay_2:
    rjmp cluster_a_tail_17
cluster_a_start:
cluster_a_tail_17_delay_1:
    nop
cluster_a_tail_17:
    dispatch_reverse

cluster_a_tail_18_delay_2:
    rjmp cluster_a_tail_18
flags_commit_a_18_delay_1:
    out  VM_FLAGS, SECONDARY_OPCODE
cluster_a_tail_18_delay_1:
cluster_tail_18_delay_1:
    nop
cluster_a_tail_18:
    dispatch
cluster_a_end:
.if (cluster_a_end - cluster_a_start) != 48
    .error "secondary cadence Cluster A must occupy 24 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Shared FF helper target lookup
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Compact target tables and the nearby LPM loader remain beside Cluster A so
; FF decoding can use RCALL without disturbing fixed-layout secondary tables.
; The expanded typed bridges and interpreter-native FP cores are placed near
; the embedded-libm routines and entered with explicit far JMP instructions.

ff_binary_helper_targets:
    .word pm(__addsf3)
    .word pm(__subsf3)
    .word pm(__mulsf3)
    .word pm(__divsf3)

; C0/C4, C1/C5, C2/C6, and C3/C7 share these helpers respectively.
ff_conversion_helper_targets:
    .word pm(__floatsisf)
    .word pm(__floatunsisf)
    .word pm(__fixsfsi)
    .word pm(__fixunssfsi)

ff_load_helper_target:
    lsl   FF_BRIDGE_INDEX
    add   r30, FF_BRIDGE_INDEX
    adc   r31, ZERO
    lpm   r0, Z+
    lpm   FF_BRIDGE_INDEX, Z
    mov   r30, r0
    mov   r31, FF_BRIDGE_INDEX
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Shared F0 trailing-operand fetch helpers
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; The generic F0 decoder reads the secondary at cycle 17 and launches the first
; trailing operand at cycle 18. Decoder completion, IJMP, and a one-word veneer
; place an operation-specific body at cycle 32. When RCALL is the body's first
; instruction, these helpers begin at cycle 35, the first legal IN cycle for
; that transfer. A body may perform setup before RCALL; that only delays the
; standard IN/OUT handoff and remains safe.
;
; Both helpers return with VM_PC naming the final consumed operand and with the
; following primary opcode already in flight. The operation body must finish by
; entering an appropriate cadence tail, which advances VM_PC from the final
; operand to the following opcode.

f0_fetch_u8_start:
f0_fetch_spec:
f0_fetch_s8:
f0_fetch_u8:
    in   F0_OPERAND_LO, SPDR
    out  SPDR, ZERO
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    ret
f0_fetch_u8_end:
.if (f0_fetch_u8_end - f0_fetch_u8_start) != 12
    .error "shared F0 one-byte fetch helper must occupy exactly six AVR words"
.endif

; Fetch a stack displacement while preserving the F0 secondary long enough
; to decode its low three bits into an architectural-register pointer in X.
; Z receives SP+u8 without modifying SP. The following primary opcode is
; launched before both address calculations, so all useful decode work overlaps
; its SPI transfer.
f0_fetch_stack_u8_decode_r_to_xz_start:
f0_fetch_stack_u8_decode_r_to_xz:
    mov  r26, SECONDARY_OPCODE
    in   F0_OPERAND_LO, SPDR
    out  SPDR, ZERO
    add  VM_PCL, ONE
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    andi r26, 0x07
    lsl  r26
    subi r26, -8
    mov  r27, ZERO
    movw r30, VM_SP
    add  r30, F0_OPERAND_LO
    adc  r31, ZERO
    ret
f0_fetch_stack_u8_decode_r_to_xz_end:
.if (f0_fetch_stack_u8_decode_r_to_xz_end - f0_fetch_stack_u8_decode_r_to_xz_start) != 28
    .error "shared F0 stack fetch/decode helper must occupy exactly fourteen AVR words"
.endif

; Fetch a little-endian 16-bit operand. The low byte is read at cycle 35 and
; the high-byte transfer starts at cycle 36. Advancing VM_PC by two consumes
; both operand bytes; three four-cycle delays place the high-byte IN at cycle
; 53 and the speculative following-primary OUT at cycle 54.
f0_fetch_u16_start:
f0_fetch_addr16:
f0_fetch_imm16:
f0_fetch_u16:
    in   F0_OPERAND_LO, SPDR
    out  SPDR, ZERO
    ldi  F0_OPERAND_HI, 2
    add  VM_PCL, F0_OPERAND_HI
    adc  VM_PCM, ZERO
    adc  VM_PCH, ZERO
    delay_4
    delay_4
    delay_4
    in   F0_OPERAND_HI, SPDR
    out  SPDR, ZERO
    ret
f0_fetch_u16_end:
.if (f0_fetch_u16_end - f0_fetch_u16_start) != 30
    .error "shared F0 two-byte fetch helper must occupy exactly fifteen AVR words"
.endif

; Fetch a little-endian absolute data-space address and decode the F0
; secondary's low three bits into an architectural-register pointer in X.
; The width-one decoder leaves secondary*1 in r0, so the helper can read the
; low address byte at the earliest legal cycle without first preserving r24.
; Register decoding and the remaining delay execute while the high address
; byte transfers. On return, Z is addr16, X selects rN, VM_PC names addr16[15:8],
; and the following primary opcode is already in flight.
f0_fetch_addr16_decode_r_to_xz_start:
f0_fetch_addr16_decode_r_to_xz:
    in    r30, SPDR
    out   SPDR, ZERO
    ldi   F0_OPERAND_HI, 2
    add   VM_PCL, F0_OPERAND_HI
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    mov   r26, r0
    andi  r26, 0x07
    lsl   r26
    subi  r26, -8
    mov   r27, ZERO

    delay_4
    delay_3
    in    r31, SPDR
    out   SPDR, ZERO
    ret
f0_fetch_addr16_decode_r_to_xz_end:
.if (f0_fetch_addr16_decode_r_to_xz_end - f0_fetch_addr16_decode_r_to_xz_start) != 34
    .error "shared F0 absolute-address fetch/decode helper must occupy exactly seventeen AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; F0 00-0F: lower-register immediate instructions
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Each one-word F0 veneer RJMPs directly to a destination-specialized body. The
; body's first instruction is RCALL to one of the shared trailing-operand fetch
; helpers above. One-byte forms fetch imm8 at cycle 35 and launch the following
; primary opcode at cycle 36; two-byte forms read imm16[15:8] at cycle 53 and
; launch the following primary opcode at cycle 54. The apply stubs then use the
; same reverse or standard cadence tails as the upper-register primary immediates.

.macro emit_f0_ldi8_body label, dstl, dsth
\label:
    rcall f0_fetch_u8
    mov   \dstl, F0_OPERAND_LO
    clr   \dsth
    rjmp  cluster_tail_17_delay_1
.endm

.macro emit_f0_ldi16_body label, dstl, dsth
\label:
    rcall f0_fetch_u16
    mov   \dstl, F0_OPERAND_LO
    mov   \dsth, F0_OPERAND_HI
    rjmp  immediate_result_tail_reverse_delay_4
.endm

.macro emit_f0_addi_s8_body label, dstl, dsth
\label:
    rcall f0_fetch_s8
    clr   F0_OPERAND_HI
    sbrc  F0_OPERAND_LO, 7
    com   F0_OPERAND_HI
    add   \dstl, F0_OPERAND_LO
    adc   \dsth, F0_OPERAND_HI
    rjmp  cluster_tail_18_delay_1
.endm

.macro emit_f0_cmpi_s8_body label, lhsl, lhsh
\label:
    rcall f0_fetch_s8
    clr   F0_OPERAND_HI
    sbrc  F0_OPERAND_LO, 7
    com   F0_OPERAND_HI
    cp    \lhsl, F0_OPERAND_LO
    cpc   \lhsh, F0_OPERAND_HI
    in    PRIMARY_OPCODE, SREG
    rjmp  flags_commit_18
.endm

emit_f0_ldi8_body    f0_ldi8_r0_body,    VM_R0L, VM_R0H
emit_f0_ldi8_body    f0_ldi8_r1_body,    VM_R1L, VM_R1H
emit_f0_ldi8_body    f0_ldi8_r2_body,    VM_R2L, VM_R2H
emit_f0_ldi8_body    f0_ldi8_r3_body,    VM_R3L, VM_R3H

emit_f0_ldi16_body   f0_ldi16_r0_body,   VM_R0L, VM_R0H
emit_f0_ldi16_body   f0_ldi16_r1_body,   VM_R1L, VM_R1H
emit_f0_ldi16_body   f0_ldi16_r2_body,   VM_R2L, VM_R2H
emit_f0_ldi16_body   f0_ldi16_r3_body,   VM_R3L, VM_R3H

emit_f0_addi_s8_body f0_addi_s8_r0_body, VM_R0L, VM_R0H
emit_f0_addi_s8_body f0_addi_s8_r1_body, VM_R1L, VM_R1H
emit_f0_addi_s8_body f0_addi_s8_r2_body, VM_R2L, VM_R2H
emit_f0_addi_s8_body f0_addi_s8_r3_body, VM_R3L, VM_R3H

emit_f0_cmpi_s8_body f0_cmpi_s8_r0_body, VM_R0L, VM_R0H
emit_f0_cmpi_s8_body f0_cmpi_s8_r1_body, VM_R1L, VM_R1H
emit_f0_cmpi_s8_body f0_cmpi_s8_r2_body, VM_R2L, VM_R2H
emit_f0_cmpi_s8_body f0_cmpi_s8_r3_body, VM_R3L, VM_R3H

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; F0 10-3F: stack-relative forms
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; All six families share the stack fetch/decode helper. On return, X addresses
; the selected architectural register, Z is SP+u8, VM_PC names the displacement,
; and the following primary opcode is already in flight. SP itself is unchanged.

f0_leasp_r_body:
    rcall f0_fetch_stack_u8_decode_r_to_xz
    st    X+, r30
    st    X,  r31
    rjmp  cluster_tail_18

f0_ldsp8u_r_body:
    rcall f0_fetch_stack_u8_decode_r_to_xz
    ld    r0, Z
    st    X+, r0
    st    X,  ZERO
    rjmp  cluster_tail_18

f0_ldsp8s_r_body:
    rcall f0_fetch_stack_u8_decode_r_to_xz
    ld    r0, Z
    st    X+, r0
    lsl   r0
    sbc   r0, r0
    st    X, r0
    rjmp  cluster_tail_18

f0_stsp8_r_body:
    rcall f0_fetch_stack_u8_decode_r_to_xz
    ld    r0, X
    st    Z, r0
    rjmp  cluster_tail_18

f0_ldsp16_r_body:
    rcall f0_fetch_stack_u8_decode_r_to_xz
    ld    r0, Z+
    ld    r1, Z
    st    X+, r0
    st    X,  r1
    rjmp  cluster_tail_18

f0_stsp16_r_body:
    rcall f0_fetch_stack_u8_decode_r_to_xz
    ld    r0, X+
    ld    r1, X
    st    Z+, r0
    st    Z,  r1
    rjmp  cluster_tail_18

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; F0 40-5F: absolute data-space forms
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; All four families share the absolute-address fetch/decode helper. The helper
; launches the following primary opcode before returning. The selected tail
; padding makes the subsequent SPDR read occur exactly seventeen cycles later
; for every byte and word operation.

; STM8 has the shortest operation body and therefore needs five cycles of
; landing delay before the standard dispatch body.
f0_absolute_bodies_start:
f0_absolute_tail_18_delay_5:
    delay_2
    rjmp  cluster_tail_18_delay_1

f0_ldm8u_r_body:
    rcall f0_fetch_addr16_decode_r_to_xz
    ld    r0, Z
    st    X+, r0
    st    X,  ZERO
    rjmp  cluster_tail_18_delay_3

f0_stm8_r_body:
    rcall f0_fetch_addr16_decode_r_to_xz
    ld    r0, X
    st    Z, r0
    rjmp  f0_absolute_tail_18_delay_5

f0_ldm16_r_body:
    rcall f0_fetch_addr16_decode_r_to_xz
    ld    r0, Z+
    ld    r1, Z
    st    X+, r0
    st    X,  r1
    rjmp  cluster_tail_18_delay_1

f0_stm16_r_body:
    rcall f0_fetch_addr16_decode_r_to_xz
    ld    r0, X+
    ld    r1, X
    st    Z+, r0
    st    Z,  r1
    rjmp  cluster_tail_18_delay_1
f0_absolute_bodies_end:
.if (f0_absolute_bodies_end - f0_absolute_bodies_start) != 46
    .error "F0 absolute data-space bodies must occupy exactly twenty-three AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; F0 60-68: program-space loads
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Each instruction is followed by PSPEC. Scalar forms require an even high
; nibble; pair forms require a four-byte-aligned high nibble. The low nibble
; always selects a four-byte-aligned qA pair. Any other PSPEC is invalid.
;
; Every operation-specific body uses f0_fetch_spec, which consumes PSPEC at
; the earliest legal cycle, launches a speculative following-primary fetch,
; and leaves VM_PC naming PSPEC. f0_program_prepare_func validates and decodes
; PSPEC, advances VM_PC to the following primary, captures the logical
; low 24 bits of qA before any destination write, performs any
; postincrement, and tail-jumps directly to fx_read_program_bytes_func with:
;
;   r24:r25:r26  original image-relative program pointer
;   Z            destination register-file address
;   r0:r1        nonzero byte count
;
; Native H selects scalar (clear) versus pair (set) destination validation.
; Native T selects ordinary (clear) versus postincrement (set) semantics.
; Both bits are set after PSPEC fetch. H is consumed before arithmetic can
; clobber it; T survives the prepare sequence. Ordinary forms permit complete
; destination/source overlap. Postincrement scalar forms reject either
; component register of qA as rD; pair forms reject qD == qA.

f0_program_loads_start:

; F0 60 PSPEC: LDP8U rD,[qA]
f0_ldp8u_body:
    rcall f0_fetch_spec
    mov   r0, ONE
    clh
    clt
    rcall f0_program_prepare_func
    std   Z+1, ZERO
    rjmp  seek_and_dispatch_func

; F0 61 PSPEC: LDP8S rD,[qA]
f0_ldp8s_body:
    rcall f0_fetch_spec
    mov   r0, ONE
    clh
    clt
    rcall f0_program_prepare_func
    lsl   r27
    sbc   r27, r27
    std   Z+1, r27
    rjmp  seek_and_dispatch_func

; F0 62 PSPEC: LDP16 rD,[qA]
f0_ldp16_body:
    rcall f0_fetch_spec
    mov   r0, ONE
    lsl   r0
    clh
    clt
    rcall f0_program_prepare_func
    rjmp  seek_and_dispatch_func

; F0 63 PSPEC: LDP24 qD,[qA]
f0_ldp24_body:
    rcall f0_fetch_spec
    mov   r0, FOUR
    dec   r0
    seh
    clt
    rcall f0_program_prepare_func
    std   Z+1, ZERO
    rjmp  seek_and_dispatch_func

; F0 64 PSPEC: LDP32 qD,[qA]
f0_ldp32_body:
    rcall f0_fetch_spec
    mov   r0, FOUR
    seh
    clt
    rcall f0_program_prepare_func
    rjmp  seek_and_dispatch_func

; F0 65 PSPEC: LDP8U rD,[qA+]
f0_ldp8u_post_body:
    rcall f0_fetch_spec
    mov   r0, ONE
    clh
    set
    rcall f0_program_prepare_func
    std   Z+1, ZERO
    rjmp  seek_and_dispatch_func

; F0 66 PSPEC: LDP16 rD,[qA+]
f0_ldp16_post_body:
    rcall f0_fetch_spec
    mov   r0, ONE
    lsl   r0
    clh
    set
    rcall f0_program_prepare_func
    rjmp  seek_and_dispatch_func

; F0 67 PSPEC: LDP24 qD,[qA+]
f0_ldp24_post_body:
    rcall f0_fetch_spec
    mov   r0, FOUR
    dec   r0
    seh
    set
    rcall f0_program_prepare_func
    std   Z+1, ZERO
    rjmp  seek_and_dispatch_func

; F0 68 PSPEC: LDP32 qD,[qA+]
f0_ldp32_post_body:
    rcall f0_fetch_spec
    mov   r0, FOUR
    seh
    set
    rcall f0_program_prepare_func
    rjmp  seek_and_dispatch_func

; Inputs:
;   F0_SPEC  trailing PSPEC
;   r0       byte count 1-4; native r1 is zero on entry
;   H        0=scalar destination, 1=pair destination
;   T        0=ordinary, 1=postincrement
;
; On success, tail-jumps to fx_read_program_bytes_func using the ABI described
; above. The reader's RET returns directly to the operation-specific body through
; the return address established by that body's RCALL to this helper. The
; destination register-file byte address temporarily occupies r1 while qA is
; captured and, for postincrement forms, updated in place.
f0_program_prepare_func:
    ; Common validity requires qA alignment and high-code bit zero. Pair
    ; destinations additionally require high-code bit one to be zero.
    mov   r25, F0_SPEC
    brhc  .Lf0_program_scalar_spec
    andi  r25, 0x33
    rjmp  .Lf0_program_spec_checked
.Lf0_program_scalar_spec:
    andi  r25, 0x13
.Lf0_program_spec_checked:
    brne  f0_program_invalid

    ; f0_fetch_spec left VM_PC naming PSPEC. The stream will be restarted at
    ; the following primary after the independent program-data transaction.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; Save the destination register-file byte address in native r1.
    mov   r25, F0_SPEC
    swap  r25
    andi  r25, 0x0f
    subi  r25, -8
    mov   r1, r25

    ; Z = native register-file byte address of qA.
    mov   r30, F0_SPEC
    andi  r30, 0x0f
    subi  r30, -8
    mov   r31, ZERO

    ; Postincrement destinations may not overlap either 16-bit component of
    ; qA. For pair destinations the second comparison can never match because
    ; qD is four-byte aligned, so this uniform check implements both rules.
    brtc  .Lf0_program_alias_valid
    cp    r1, r30
    breq  f0_program_invalid
    mov   r25, r30
    subi  r25, -2
    cp    r1, r25
    breq  f0_program_invalid
.Lf0_program_alias_valid:

    ; Capture the logical low 24 bits of qA before the reader writes its
    ; destination. qA[31:24] is nonsemantic padding and is not inspected.
    ld    r24, Z+
    ld    r25, Z+
    ld    r26, Z+

    ; For postincrement, update qA by count while retaining the original source
    ; in r24:r25:r26. MOV and ST preserve carry between the three byte updates.
    brtc  .Lf0_program_no_update
    subi  r30, 3
    mov   r27, r24
    add   r27, r0
    st    Z+, r27
    mov   r27, r25
    adc   r27, ZERO
    st    Z+, r27
    mov   r27, r26
    adc   r27, ZERO
    st    Z,  r27
.Lf0_program_no_update:

    ; Restore destination Z and the zero high byte of the reader count.
    mov   r30, r1
    mov   r31, ZERO
    mov   r1, ZERO
    rjmp  fx_read_program_bytes_func

f0_program_invalid:
    rjmp  invalid_secondary_instruction_func

f0_program_loads_end:
.if (f0_program_loads_end - f0_program_loads_start) != 218
    .error "F0 program-space load subsystem must occupy exactly 109 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Shared image-relative program-space byte reader
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Inputs:
;   r24:r25:r26  image-relative source address, low:middle:high
;   r30:r31      destination SRAM address (native Z)
;   r0:r1        nonzero byte count, little-endian
;
; The physical W25Q128 address is (data_page_data << 8) + source, modulo
; 24 bits. The routine opens an independent SFC_READ transaction, copies the
; requested bytes, disables FX chip select, and returns. It deliberately does
; not handle count == 0.
;
; Outputs/clobbers:
;   r0:r1        zero
;   r24          original source low byte, preserved
;   r25:r26      physical middle/high address bytes
;   r27          scratch and final byte read
;   Z            points at the final destination byte (not one past it)
;   native SREG  clobbered; architectural VM_FLAGS is untouched
;
; Meaningful command/address transmit bytes use an 18-cycle OUT-to-OUT
; cadence. Dummy transfers use the 17-cycle minimum. For every nonfinal data
; byte, CLI/OUT/IN/SEI performs the exact reverse-order handoff: the next dummy
; transfer starts as soon as the previous receive byte is ready.
; The final byte is read without launching an unnecessary following transfer.
; All delay entries below avoid LPM/delay_3 because native r0 holds count.

fx_read_program_bytes_start:
fx_read_program_bytes_func:
    ; Keep the fixed-count entry's command launch in-line. The shared address
    ; phase begins through RCALL while the command is already transferring, so
    ; factoring it adds no cycles to F0 program loads or SYS memcpy_P.
    fx_disable
    ldi   r27, SFC_READ
    fx_enable
    out   SPDR, r27
    rcall fx_read_program_start_after_command_func

    ; The shared start returns five cycles after launching the first data-byte
    ; transfer. Predecrement the guaranteed-nonzero count. A multi-byte read
    ; takes the branch into the seven-cycle loop landing; count==1 jumps to the
    ; short final landing. Both paths consume the first byte on cycle 17.
    sub   r0, ONE
    sbc   r1, ZERO
    brne  .Lfx_read_program_loop
    rjmp  .Lfx_read_program_final_short

.Lfx_read_program_loop:
    ; Seven-cycle call plus CLI places OUT at the minimum legal boundary.
    rcall fx_read_program_delay_7
    cli
    out   SPDR, ZERO             ; begin the next data-byte transfer
    in    r27, SPDR              ; consume the completed previous byte
    sei
    st    Z+, r27

    sub   r0, ONE
    sbc   r1, ZERO
    brne  .Lfx_read_program_loop

    ; A loop exit occurs one cycle earlier than the count==1 jump reaches the
    ; short landing. This two-cycle delay aligns both paths at the shared
    ; seven-cycle final wait without changing existing reader latency.
    delay_2
.Lfx_read_program_final_short:
    rcall fx_read_program_delay_7
    in    r27, SPDR
    st    Z, r27
    fx_disable
    ret

; Alternate entry used only by the new program-memory SYS services. Their
; caller has already established a return address, so this path launches the
; command and tail-jumps into the shared address phase. The one-cycle landing
; aligns it with the fixed reader's RCALL entry without delaying either path.
fx_start_program_read_func:
    fx_disable
    ldi   r27, SFC_READ
    fx_enable
    out   SPDR, r27
    rjmp  fx_read_program_start_tail_entry

fx_read_program_start_tail_entry:
    nop
fx_read_program_start_after_command_func:
    ; Entry is cycle 4 after the command OUT on both paths. Convert the
    ; image-relative source into a physical flash address while the command is
    ; in flight. The source low byte is unchanged.
    lds   r27, data_page_data+0
    add   r25, r27
    lds   r27, data_page_data+1
    adc   r26, r27

    ; The seven-cycle delay and one NOP put the high-address OUT at cycle 18.
    ; Remaining meaningful bytes retain the 18-cycle cadence; the first dummy
    ; transfer uses the minimum 17-cycle cadence.
    rcall fx_read_program_delay_7
    nop
    out   SPDR, r26
    rcall fx_read_program_delay_17
    out   SPDR, r25
    rcall fx_read_program_delay_17
    out   SPDR, r24
    rcall fx_read_program_delay_16
    out   SPDR, ZERO             ; begin first data-byte transfer
    ret

; Local fixed-delay ladder. Each label is the complete cycle count from the
; calling RCALL through the returning RET. It uses only NOP and RJMP .+0.
fx_read_program_delay_17:
    nop
fx_read_program_delay_16:
    delay_4
    nop
fx_read_program_delay_11:
    delay_2
fx_read_program_delay_9:
    delay_2
fx_read_program_delay_7:
    ret

fx_read_program_bytes_end:
.if (fx_read_program_bytes_end - fx_read_program_bytes_start) != 106
    .error "shared program-space readers must occupy exactly fifty-three AVR words"
.endif


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Program-memory string and comparison SYS services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Common ABI:
;   q3[23:0] = image-relative program pointer; q3[31:24] is ignored/preserved
;   r4 = RAM operand/destination, except strlen_P where r4 is result only
;   r5 = uint16_t bound for memcmp_P, strncpy_P, and strncat_P
;
; Results:
;   memcmp_P / strcmp_P return -1, 0, or +1 in r4
;   strlen_P returns the uint16_t length in r4
;   strncpy_P / strncat_P preserve the original destination in r4
;
; Each service opens one independent SFC_READ transaction and restarts the VM
; instruction stream afterward. Their streaming loops launch every successive
; dummy transfer exactly seventeen cycles after the preceding OUT. The current
; fixed-count reader is not routed through these loops, preserving existing F0
; and memcpy_P performance.

sys_progmem_services_start:

; Consume the service byte in VM_PC, copy only q3[23:0] into native source
; scratch, and tail-enter the alternate shared transaction start. q3[31:24]
; is neither inspected nor modified. The three NOPs preserve the established
; transaction-start timing and code layout of the former canonicality check.
; Called with RCALL; the transaction start's RET returns directly to the service
; body five cycles after the first data-byte OUT. Z and r0:r1 are preserved;
; r24:r27 are clobbered.
sys_progmem_prepare_func:
    nop
    nop
    nop
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
    movw  r24, VM_R6
    mov   r26, VM_R7L
    rjmp  fx_start_program_read_func

; Shared comparison results. CP is always RAM byte minus program byte, so C
; means the RAM operand is lexicographically smaller.
.Lsys_progmem_compare_mismatch:
    brlo  .Lsys_progmem_compare_less
    mov   VM_R4L, ONE
    mov   VM_R4H, ZERO
    rjmp  .Lsys_progmem_finish
.Lsys_progmem_compare_less:
    ser   VM_R4L
    ser   VM_R4H
    rjmp  .Lsys_progmem_finish
.Lsys_progmem_compare_equal:
    clr   VM_R4L
    clr   VM_R4H
.Lsys_progmem_finish:
    fx_disable
    rjmp  seek_and_dispatch_func

; int memcmp_P(void const *lhs, progptr/uint24_t rhs, uint16_t n)
;   r4 = RAM lhs/result, q3 = program rhs, r5 = n
sys_memcmp_p_impl:
    movw  r0, VM_R5
    mov   r27, r0
    or    r27, r1
    breq  .Lsys_memcmp_p_zero

    movw  r30, VM_R4             ; Z = RAM lhs
    rcall sys_progmem_prepare_func

    ; The start returns at cycle 5. Preload the first RAM byte, then use the
    ; seven-cycle delay and RJMP to reach the first exact cycle-17 handoff.
    ld    r24, Z+
    rcall fx_read_program_delay_7
    rjmp  .Lsys_memcmp_p_loop

.Lsys_memcmp_p_loop:
    cli
    out   SPDR, ZERO
    in    r27, SPDR
    sei

    cp    r24, r27
    brne  .Lsys_progmem_compare_mismatch
    sub   r0, ONE
    sbc   r1, ZERO
    breq  .Lsys_progmem_compare_equal
    ld    r24, Z+
    delay_4
    rjmp  .Lsys_memcmp_p_loop

.Lsys_memcmp_p_zero:
    clr   VM_R4L
    clr   VM_R4H
    rjmp  cluster_tail_18

; int strcmp_P(char const *lhs, progptr/uint24_t rhs)
;   r4 = RAM lhs/result, q3 = program rhs
sys_strcmp_p_impl:
    movw  r30, VM_R4             ; Z = RAM lhs
    rcall sys_progmem_prepare_func

    ld    r0, Z+
    rcall fx_read_program_delay_7
    rjmp  .Lsys_strcmp_p_loop

.Lsys_strcmp_p_loop:
    cli
    out   SPDR, ZERO
    in    r27, SPDR
    sei

    cp    r0, r27
    brne  .Lsys_progmem_compare_mismatch
    tst   r27
    breq  .Lsys_progmem_compare_equal
    ld    r0, Z+
    delay_4
    nop
    rjmp  .Lsys_strcmp_p_loop

; uint16_t strlen_P(progptr/uint24_t src)
;   q3 = program src, r4 = result
sys_strlen_p_impl:
    clr   VM_R4L
    clr   VM_R4H
    rcall sys_progmem_prepare_func

    rcall fx_read_program_delay_9
    rjmp  .Lsys_strlen_p_loop

.Lsys_strlen_p_loop:
    cli
    out   SPDR, ZERO
    in    r27, SPDR
    sei

    tst   r27
    breq  .Lsys_strlen_p_finish_wait
    add   VM_R4L, ONE
    adc   VM_R4H, ZERO
    rcall fx_read_program_delay_7
    rjmp  .Lsys_strlen_p_loop

; The NUL path is two cycles shorter than the other program-memory terminal
; paths. This one-word landing delays the stream restart until the preceding
; dummy transfer has completed at the required seventeen-cycle SPI boundary.
.Lsys_strlen_p_finish_wait:
    rjmp  .Lsys_progmem_finish

; Shared bounded copy-until-NUL engine for strncpy_P and strncat_P.
; Inputs: Z=destination, r0:r1=nonzero maximum count, q3=source.
; Output: Z one past copied bytes, r0:r1 remaining count, T=1 iff a NUL was
; copied. The transaction is disabled before RET. The nonterminal path from
; one data OUT to the next is exactly seventeen cycles.
fx_copy_program_string_n_func:
    clt
    rcall sys_progmem_prepare_func
    rcall fx_read_program_delay_9
    rjmp  .Lfx_copy_program_string_n_loop

.Lfx_copy_program_string_n_loop:
    cli
    out   SPDR, ZERO
    in    r27, SPDR
    sei

    st    Z+, r27
    sub   r0, ONE
    sbc   r1, ZERO

    ; CPSE does not disturb the count's Z flag. For a nonzero byte, the RJMP
    ; reaches the count test; for NUL, skip it, set T, and finish.
    cpse  r27, ZERO
    rjmp  .Lfx_copy_program_string_n_nonzero
    set
    rjmp  .Lfx_copy_program_string_n_done

.Lfx_copy_program_string_n_nonzero:
    breq  .Lfx_copy_program_string_n_done
    delay_2
    nop
    rjmp  .Lfx_copy_program_string_n_loop

.Lfx_copy_program_string_n_done:
    fx_disable
    ret

; char *strncpy_P(char *dst, progptr/uint24_t src, uint16_t n)
;   r4 = dst/result, q3 = src, r5 = n
sys_strncpy_p_impl:
    movw  r0, VM_R5
    mov   r27, r0
    or    r27, r1
    breq  .Lsys_strncpy_p_zero

    movw  r30, VM_R4
    rcall fx_copy_program_string_n_func

    ; A nonzero remainder exists only when the source NUL was copied. Pad all
    ; remaining destination bytes as required by strncpy.
    mov   r24, r0
    or    r24, r1
    breq  .Lsys_strncpy_p_done
.Lsys_strncpy_p_pad:
    st    Z+, ZERO
    sub   r0, ONE
    sbc   r1, ZERO
    brne  .Lsys_strncpy_p_pad
.Lsys_strncpy_p_done:
    rjmp  seek_and_dispatch_func
.Lsys_strncpy_p_zero:
    rjmp  cluster_tail_18

; char *strncat_P(char *dst, progptr/uint24_t src, uint16_t n)
;   r4 = dst/result, q3 = src, r5 = n
sys_strncat_p_impl:
    movw  r0, VM_R5
    mov   r27, r0
    or    r27, r1
    breq  .Lsys_strncat_p_zero

    ; Find the existing RAM terminator. Z is left one past it, then moved back
    ; so the program string overwrites that terminator.
    movw  r30, VM_R4
.Lsys_strncat_p_scan:
    ld    r24, Z+
    tst   r24
    brne  .Lsys_strncat_p_scan
    sbiw  r30, 1

    rcall fx_copy_program_string_n_func
    brts  .Lsys_strncat_p_done
    st    Z, ZERO                ; count exhausted before source NUL
.Lsys_strncat_p_done:
    rjmp  seek_and_dispatch_func
.Lsys_strncat_p_zero:
    rjmp  cluster_tail_18

sys_progmem_services_end:
.if (sys_progmem_services_end - sys_progmem_services_start) != 258
    .error "program-memory SYS subsystem must occupy exactly 129 AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Data-memory string and comparison SYS services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Calling conventions:
;   memcmp:   r4=lhs/result, r5=rhs, r6=n
;   strcmp:   r4=lhs/result, r5=rhs
;   strlen:   r4=string/result
;   strncpy:  r4=dst/result, r5=src, r6=n
;   strncat:  r4=dst/result, r5=src, r6=n
;
; Comparison services return the exact signed unsigned-byte difference.
; strncpy and strncat retain the original destination in r4. The bounded copy
; engine is shared by both string-copy services and returns NUL status in T.
; All services preserve VM_FLAGS and every nondestination architectural input.

sys_ram_string_services_start:

; Shared exact comparison result. The byte loops use SUB lhs,rhs. Its low
; byte and carry are the complete signed 16-bit difference of two unsigned
; chars: clear the high byte without disturbing carry, then borrow into it.
.Lsys_ram_compare_store_difference:
    mov   VM_R4L, r0
    clr   VM_R4H
    sbc   VM_R4H, ZERO
    rjmp  cluster_tail_18
.Lsys_ram_compare_zero:
    sub   r0, r0                 ; zero r0 and clear carry
    rjmp  .Lsys_ram_compare_store_difference

; int memcmp(void const *lhs, void const *rhs, uint16_t n)
;   r4 = lhs/result, r5 = rhs, r6 = n
sys_memcmp_impl:
    movw  r26, VM_R4             ; X = lhs
    movw  r30, VM_R5             ; Z = rhs
    movw  r24, VM_R6             ; remaining count
    sbiw  r24, 0
    breq  .Lsys_ram_compare_zero
.Lsys_memcmp_loop:
    ld    r0, X+
    ld    r1, Z+
    sub   r0, r1
    brne  .Lsys_ram_compare_store_difference
    sbiw  r24, 1
    brne  .Lsys_memcmp_loop
    rjmp  .Lsys_ram_compare_store_difference

; int strcmp(char const *lhs, char const *rhs)
;   r4 = lhs/result, r5 = rhs
sys_strcmp_impl:
    movw  r26, VM_R4             ; X = lhs
    movw  r30, VM_R5             ; Z = rhs
.Lsys_strcmp_loop:
    ld    r0, X+
    ld    r1, Z+
    sub   r0, r1
    brne  .Lsys_ram_compare_store_difference
    tst   r1
    brne  .Lsys_strcmp_loop
    rjmp  .Lsys_ram_compare_store_difference

; uint16_t strlen(char const *src)
;   r4 = src/result
sys_strlen_impl:
    movw  r26, VM_R4             ; X = source
.Lsys_strlen_loop:
    ld    r0, X+
    tst   r0
    brne  .Lsys_strlen_loop
.Lsys_strlen_done:
    ; X points one byte past NUL. Subtract the original source address and
    ; the terminator in modulo-16-bit arithmetic instead of counting per byte.
    movw  r24, r26
    sub   r24, VM_R4L
    sbc   r25, VM_R4H
    sbiw  r24, 1
    movw  VM_R4, r24
    rjmp  cluster_tail_18

; Shared bounded RAM copy-until-NUL engine for strncpy and strncat.
; Inputs: X=source, Z=destination, r24:r25=nonzero maximum count.
; Outputs: X/Z one past copied bytes, r24:r25 unused count, T=1 iff a NUL
; was copied. CPSE preserves the native Z flag produced by SBIW.
sys_copy_string_n_func:
    clt
.Lsys_copy_string_n_loop:
    ld    r0, X+
    st    Z+, r0
    sbiw  r24, 1
    cpse  r0, ZERO
    rjmp  .Lsys_copy_string_n_nonzero
    set
    ret
.Lsys_copy_string_n_nonzero:
    brne  .Lsys_copy_string_n_loop
    ret

; char *strncpy(char *dst, char const *src, uint16_t n)
;   r4 = dst/result, r5 = src, r6 = n
sys_strncpy_impl:
    movw  r24, VM_R6
    sbiw  r24, 0
    breq  .Lsys_ram_string_done
    movw  r26, VM_R5
    movw  r30, VM_R4
    rcall sys_copy_string_n_func

    ; The helper returns with native Z still reflecting the remaining count.
    ; A nonzero remainder exists only when a source NUL was copied.
    breq  .Lsys_ram_string_done
.Lsys_strncpy_pad:
    st    Z+, ZERO
    sbiw  r24, 1
    brne  .Lsys_strncpy_pad
    rjmp  .Lsys_ram_string_done

; char *strncat(char *dst, char const *src, uint16_t n)
;   r4 = dst/result, r5 = src, r6 = n
sys_strncat_impl:
    movw  r24, VM_R6
    sbiw  r24, 0
    breq  .Lsys_ram_string_done

    ; Find and overwrite the existing destination terminator.
    movw  r30, VM_R4
.Lsys_strncat_scan:
    ld    r0, Z+
    tst   r0
    brne  .Lsys_strncat_scan
    sbiw  r30, 1

    movw  r26, VM_R5
    rcall sys_copy_string_n_func
    brts  .Lsys_ram_string_done
    st    Z, ZERO                ; count exhausted before source NUL
.Lsys_ram_string_done:
    rjmp  cluster_tail_18

sys_ram_string_services_end:
.if (sys_ram_string_services_end - sys_ram_string_services_start) != 142
    .error "data-memory string SYS subsystem must occupy exactly 71 AVR words"
.endif


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; OLED framebuffer display function and SYS service
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Shared native function:
;   display_update_func
;   input:  r16 / VM_R4L = clear (zero leaves framebuffer bytes unchanged;
;                                nonzero clears each byte after transfer)
;   precondition: FX flash is deselected and no SPI transfer is active
;   output: OLED and FX flash deselected; transfer fully complete
;   clobbers: r0, r24:r26, Z, native SREG
;   preserves: r16 and all other architectural registers
;
; SYS ABI:
;   void display(bool clear)
;   r4 low byte / native r16 = clear
;
; The SYS wrapper advances VM_PC, drains the speculative FX transfer, calls the
; shared function, and restarts the instruction stream. Startup calls the same
; function directly after zeroing the framebuffer.

sys_display_service_start:
sys_display_impl:
    ; VM_PC names the service byte. Advance to the following primary now so the
    ; common seek path can restart the instruction stream after the OLED owns
    ; the shared SPI bus.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; SYS decode launched the speculative read nine cycles before this entry.
    ; PC advancement uses three cycles; six more place status/data reads at
    ; cycles 18/19. SPIF may still describe an older timed transfer, so it is
    ; not a reliable indication that this speculative byte has completed.
    delay_3
    delay_3
sys_display_acknowledge:
    in    r24, SPSR
    in    r24, SPDR
    fx_disable

    rcall display_update_func
    rjmp  seek_and_dispatch_func

; Transfer the complete framebuffer to the configured OLED controller. This is
; a normal native AVR function so startup and SYS display share one body.
display_update_func:
    ldi   r30, lo8(data_display)
    ldi   r31, hi8(data_display)

#if defined(AVM_DISPLAY_SH1106)
    ; Arduboy2-derived SH1106 page-mode transfer. Every command and data OUT is
    ; separated by at least the 18 cycles required at f_CPU/2. The visible
    ; 128-column window begins at column two; startup set the low column command
    ; to 0x02, and each page resets only page and high-column state here.
    display_command_mode
    display_enable
    ldi   r25, 0xB0               ; page 0 command

.Ldisplay_sh1106_page:
    ldi   r24, 0x10               ; high column address = 0
    ldi   r26, 6
    display_command_mode

    out   SPDR, r25
.Ldisplay_sh1106_command_wait:
    dec   r26
    brne  .Ldisplay_sh1106_command_wait
    out   SPDR, r24

    ldi   r24, 128
    inc   r24                     ; 129: predecrement loop entry
    rjmp  .Ldisplay_sh1106_data_entry

.Ldisplay_sh1106_data_loop:
    lpm   r26, Z                  ; timing-only internal-flash read
    ld    r26, Z
    display_data_mode
    out   SPDR, r26
    cpse  VM_R4L, ZERO
    mov   r26, ZERO
    st    Z+, r26

.Ldisplay_sh1106_data_entry:
    lpm   r26, Z                  ; timing-only internal-flash read
    dec   r24
    brne  .Ldisplay_sh1106_data_loop

    inc   r25
    cpi   r25, 0xB8              ; eight 128-byte pages
    brne  .Ldisplay_sh1106_page

    ; Match the reference final-transfer delay before releasing chip select.
    lpm   r26, Z
#else
    ; Arduboy2-derived SSD1306/SSD1309 data-only transfer. A doubled count makes
    ; the SBIW/parity delay loop execute twice per framebuffer byte, yielding
    ; an exact 18-cycle OUT-to-OUT cadence while also providing constant-time
    ; optional clearing.
    display_data_mode
    display_enable
    ldi   r24, lo8(2048)
    ldi   r25, hi8(2048)

.Ldisplay_ssd_loop:
    ld    r0, Z
    out   SPDR, r0
    cpse  VM_R4L, ZERO
    mov   r0, ZERO
.Ldisplay_ssd_delay:
    sbiw  r24, 1
    sbrc  r24, 0
    rjmp  .Ldisplay_ssd_delay
    st    Z+, r0
    brne  .Ldisplay_ssd_loop
    nop                         ; match SH1106's final cycle-16 exit
#endif

    ; Complete and acknowledge the final transfer before releasing chip select.
    ; Both final loop exits reach this point at cycle 16. Fresh SPIF is not
    ; visible until cycle 18, even though received data is ready at 16.
    ; Wait so SPSR sees the completed final byte's SPIF, then
    ; access SPDR to clear it; an early read can leave a fresh SPIF afterward.
    delay_2
display_acknowledge:
    in    r24, SPSR
    in    r24, SPDR
    display_disable
    fx_disable
    ret

sys_display_service_end:
#if defined(AVM_DISPLAY_SH1106)
.if (sys_display_service_end - sys_display_service_start) != 90
    .error "SH1106 display SYS wrapper/function must occupy exactly 45 AVR words"
.endif
#else
.if (sys_display_service_end - sys_display_service_start) != 64
    .error "SSD1306/SSD1309 display SYS wrapper/function must occupy exactly 32 AVR words"
.endif
#endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; F0 69-6B: shared cold 32-bit forms
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; RRSPEC contains two pre-scaled native register-file offsets:
;   bits 7:4  high operand: qL / qD / qS
;   bits 3:0  low operand:  qR / rA
;
; Valid q offsets are 0,4,8,12 and valid r offsets are 0,2,...,14. Common
; validation rejects a non-q high operand or an odd low operand; CMP32 also
; rejects a low operand that is not q-aligned. X addresses the high operand
; and Z addresses the low operand.
;
; The generic width-one F0 decoder launches RRSPEC at cycle 9 after F0-slot
; entry and reaches this one-word veneer body at cycle 23. The one required
; cadence slot normalizes secondary 69-6B to operation indices 0-2. The ADD,
; CLI, and OUT then launch the following primary at cycle 26, exactly 17 cycles
; after RRSPEC. This current-decoder adaptation is one word smaller than the
; guide's three-cycle landing while preserving the same shared organization.
;
; Memory forms capture the complete 16-bit effective address before touching
; the selected q pair, so LD32 and ST32 permit q/address-register overlap.
; CMP32 captures the complete left operand before reusing XL as scratch, so
; qL == qR is fully defined.

f0_cold32_start:
f0_cold32_delay_1:
    subi  SECONDARY_OPCODE, 0x69  ; 0=CMP32, 1=LD32, 2=ST32
f0_cold32:
    add   VM_PCL, ONE
    cli
    out   SPDR, ZERO
    in    F0_COLD32_SPEC, SPDR
    sei
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; Common validity: high operand must be q-aligned and low operand r-aligned.
    mov   r26, F0_COLD32_SPEC
    andi  r26, 0x31
    brne  f0_cold32_invalid

    ; X = native register-file pointer for the high operand.
    mov   r26, F0_COLD32_SPEC
    swap  r26
    andi  r26, 0x0f
    subi  r26, -8
    mov   r27, ZERO

    ; Z = native register-file pointer for the low operand.
    mov   r30, F0_COLD32_SPEC
    andi  r30, 0x0f
    subi  r30, -8
    mov   r31, ZERO

    ; Operation index zero selects CMP32; memory forms share address capture.
    tst   SECONDARY_OPCODE
    breq  f0_cold32_cmp32

    ; Capture the effective data-space address before reading/writing a
    ; potentially overlapping q operand.
    ld    r0, Z+
    ld    r1, Z
    movw  Z, r0

    ; Operation index one is LD32; index two falls through to ST32.
    cpi   SECONDARY_OPCODE, 1
    breq  f0_cold32_ld32

f0_cold32_st32:
    ld    r24, X+
    st    Z+, r24
    ld    r24, X+
    st    Z+, r24
    ld    r24, X+
    st    Z+, r24
    ld    r24, X
    st    Z,  r24
    rjmp  cluster_a_tail_18

f0_cold32_ld32:
    ld    r24, Z+
    st    X+, r24
    ld    r24, Z+
    st    X+, r24
    ld    r24, Z+
    st    X+, r24
    ld    r24, Z
    st    X,  r24
    rjmp  cluster_a_tail_18

f0_cold32_cmp32:
    ; CMP32 additionally requires the low operand to be q-aligned.
    sbrc  F0_COLD32_SPEC, 1
    rjmp  f0_cold32_invalid

    ; Preserve all four left bytes before XL is reused as right-byte scratch.
    ld    r0,  X+
    ld    r1,  X+
    ld    r24, X+
    ld    r25, X

    ld    r26, Z+
    cp    r0,  r26
    ld    r26, Z+
    cpc   r1,  r26
    ld    r26, Z+
    cpc   r24, r26
    ld    r26, Z
    cpc   r25, r26

    in    r24, SREG
    out   VM_FLAGS, r24
    rjmp  cluster_a_tail_18

f0_cold32_invalid:
    rjmp  invalid_secondary_instruction_func

f0_cold32_end:
.if (f0_cold32_end - f0_cold32_start) != 126
    .error "F0 cold-32 subsystem must occupy exactly sixty-three AVR words"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; F0 6C-6D: general-pointer data-space forms
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; RRSPEC is dddWaaaP:
;   bits 7:5  data register rD/rS
;   bit  4    width: 0=byte, 1=word
;   bits 3:1  pointer register rA
;   bit  0    update: 0=ordinary, 1=postincrement
;
; Section 9.5 uses an independent reverse-order RRSPEC consume/restart entry.
; In this interpreter the generic width-one F0 decoder reaches its veneer two
; cycles later than the guide's original layout. One cycle is still required
; before the exact handoff, so BST uses that cadence slot to preserve secondary
; bit 0 in native T: the decoder launches RRSPEC at cycle 9 after F0-slot
; entry, and this entry launches the following primary at cycle 26, exactly 17
; cycles later. r0 still contains secondary*1 at the BST.
;
; Ordinary loads capture the effective address before writing rD. Stores
; capture the complete selected source before reading rA. These orderings make
; ordinary load overlap and every store overlap legal. Postincrement load
; aliases with rD == rA remain architecturally reserved as specified by the
; ISA; valid encodings follow the reference Section 9.5 paths below.

f0_coldmem_start:
f0_coldmem_delay_1:
    bst   r0, 0                 ; T=0 for F0 6C load, T=1 for F0 6D store
f0_coldmem:
    add   VM_PCL, ONE
    cli
    out   SPDR, ZERO
    in    F0_COLDMEM_SPEC, SPDR
    sei
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; X = data-register file pointer; Z = pointer-register file pointer.
    f0_decode_general_pointer_spec F0_COLDMEM_SPEC

    ; The cadence-slot BST preserved secondary bit 0 in native T. Branching
    ; to the store body now costs one word and saves one cycle on both families.
    brts  f0_coldmem_store

f0_coldmem_load:
    ; Preserve the architectural pointer's register-file address.
    mov   r0, r30

    ; Capture the effective data-space address before writing rD.
    ld    r24, Z+
    ld    r25, Z
    movw  Z, r24

    ; Load one byte, zero-extend, and conditionally load the high byte.
    ld    r24, Z+
    clr   r25
    sbrc  F0_COLDMEM_SPEC, 4
    ld    r25, Z+

    ; Write the selected byte or word result.
    st    X+, r24
    st    X,  r25

    ; P=0 discards native Z advancement. P=1 writes it back to rA.
    sbrs  F0_COLDMEM_SPEC, 0
    rjmp  cluster_a_tail_18
    mov   r26, r0
    ; XH is still zero on the load path; fall through.

f0_coldmem_post_writeback:
    st    X+, r30
    st    X,  r31
    rjmp  cluster_a_tail_18

f0_coldmem_store:
    ; Capture both source bytes before reading rA, preserving every
    ; source/pointer overlap case. Byte stores simply leave r25 unused.
    ld    r0, X+
    ld    r25, X

    ; Z still addresses architectural rA. Load its effective data-space address
    ; directly into X; after the first load, Z points at rA's high byte.
    ld    r26, Z+
    ld    r27, Z

    ; Store through X, leaving X advanced by the selected width.
    st    X+, r0
    sbrc  F0_COLDMEM_SPEC, 4
    st    X+, r25

    ; P=0 discards the advanced X value. For P=1, Z still points at rA's high
    ; byte, so write back high then predecrement and write low.
    sbrs  F0_COLDMEM_SPEC, 0
    rjmp  cluster_a_tail_18
    st    Z,  r27
    st    -Z, r26
    rjmp  cluster_a_tail_18

f0_coldmem_end:
.if (f0_coldmem_end - f0_coldmem_start) != 92
    .error "F0 general-pointer subsystem must occupy exactly forty-six AVR words"
.endif

; F0 retains one-word veneers for every cold form. All valid secondaries
; 00-6D are implemented above.
secondary_tables_before_cluster_b:

f0_veneer_table:
    rjmp  f0_ldi8_r0_body
    rjmp  f0_ldi8_r1_body
    rjmp  f0_ldi8_r2_body
    rjmp  f0_ldi8_r3_body

    rjmp  f0_ldi16_r0_body
    rjmp  f0_ldi16_r1_body
    rjmp  f0_ldi16_r2_body
    rjmp  f0_ldi16_r3_body

    rjmp  f0_addi_s8_r0_body
    rjmp  f0_addi_s8_r1_body
    rjmp  f0_addi_s8_r2_body
    rjmp  f0_addi_s8_r3_body

    rjmp  f0_cmpi_s8_r0_body
    rjmp  f0_cmpi_s8_r1_body
    rjmp  f0_cmpi_s8_r2_body
    rjmp  f0_cmpi_s8_r3_body

    ; 10-17: LEASP r0-r7,u8
    .rept 8
        rjmp f0_leasp_r_body
    .endr

    ; 18-1F: LDSP8U r0-r7,[SP+u8]
    .rept 8
        rjmp f0_ldsp8u_r_body
    .endr

    ; 20-27: LDSP8S r0-r7,[SP+u8]
    .rept 8
        rjmp f0_ldsp8s_r_body
    .endr

    ; 28-2F: STSP8 [SP+u8],r0-r7
    .rept 8
        rjmp f0_stsp8_r_body
    .endr

    ; 30-37: LDSP16 r0-r7,[SP+u8]
    .rept 8
        rjmp f0_ldsp16_r_body
    .endr

    ; 38-3F: STSP16 [SP+u8],r0-r7
    .rept 8
        rjmp f0_stsp16_r_body
    .endr

    ; 40-47: LDM8U r0-r7,addr16
    .rept 8
        rjmp f0_ldm8u_r_body
    .endr

    ; 48-4F: STM8 addr16,r0-r7
    .rept 8
        rjmp f0_stm8_r_body
    .endr

    ; 50-57: LDM16 r0-r7,addr16
    .rept 8
        rjmp f0_ldm16_r_body
    .endr

    ; 58-5F: STM16 addr16,r0-r7
    .rept 8
        rjmp f0_stm16_r_body
    .endr

    ; 60-68: program-space loads; trailing byte is PSPEC.
    rjmp  f0_ldp8u_body
    rjmp  f0_ldp8s_body
    rjmp  f0_ldp16_body
    rjmp  f0_ldp24_body
    rjmp  f0_ldp32_body
    rjmp  f0_ldp8u_post_body
    rjmp  f0_ldp16_post_body
    rjmp  f0_ldp24_post_body
    rjmp  f0_ldp32_post_body

    ; 69-6B: CMP32 / LD32 / ST32; trailing byte is pre-scaled RRSPEC.
    rjmp  f0_cold32_delay_1
    rjmp  f0_cold32_delay_1
    rjmp  f0_cold32_delay_1

    ; 6C-6D: general-pointer load/store; trailing byte is dddWaaaP.
    rjmp  f0_coldmem_delay_1
    rjmp  f0_coldmem_delay_1
f0_veneer_table_end:
.if (f0_veneer_table_end - f0_veneer_table) != (2 * 0x6E)
    .error "F0 veneer table has incorrect size"
.endif

f1_table:
    ; F1: bounded two-word dense table
    emit_f1_mov r8, r8
    emit_f1_mov r8, r10
    emit_f1_mov r8, r12
    emit_f1_mov r8, r14
    emit_f1_mov r8, r16
    emit_f1_mov r8, r18
    emit_f1_mov r8, r20
    emit_f1_mov r8, r22
    emit_f1_mov r10, r8
    emit_f1_mov r10, r10
    emit_f1_mov r10, r12
    emit_f1_mov r10, r14
    emit_f1_mov r10, r16
    emit_f1_mov r10, r18
    emit_f1_mov r10, r20
    emit_f1_mov r10, r22
    emit_f1_mov r12, r8
    emit_f1_mov r12, r10
    emit_f1_mov r12, r12
    emit_f1_mov r12, r14
    emit_f1_mov r12, r16
    emit_f1_mov r12, r18
    emit_f1_mov r12, r20
    emit_f1_mov r12, r22
    emit_f1_mov r14, r8
    emit_f1_mov r14, r10
    emit_f1_mov r14, r12
    emit_f1_mov r14, r14
    emit_f1_mov r14, r16
    emit_f1_mov r14, r18
    emit_f1_mov r14, r20
    emit_f1_mov r14, r22
    emit_f1_mov r16, r8
    emit_f1_mov r16, r10
    emit_f1_mov r16, r12
    emit_f1_mov r16, r14
    emit_f1_mov r18, r8
    emit_f1_mov r18, r10
    emit_f1_mov r18, r12
    emit_f1_mov r18, r14
    emit_f1_mov r20, r8
    emit_f1_mov r20, r10
    emit_f1_mov r20, r12
    emit_f1_mov r20, r14
    emit_f1_mov r22, r8
    emit_f1_mov r22, r10
    emit_f1_mov r22, r12
    emit_f1_mov r22, r14
    emit_f1_stsp8 r16, 0
    emit_f1_stsp8 r18, 0
    emit_f1_stsp8 r20, 0
    emit_f1_stsp8 r22, 0
    emit_f1_stsp8 r16, 1
    emit_f1_stsp8 r18, 1
    emit_f1_stsp8 r20, 1
    emit_f1_stsp8 r22, 1
    emit_f1_stsp8 r16, 2
    emit_f1_stsp8 r18, 2
    emit_f1_stsp8 r20, 2
    emit_f1_stsp8 r22, 2
    emit_f1_stsp8 r16, 3
    emit_f1_stsp8 r18, 3
    emit_f1_stsp8 r20, 3
    emit_f1_stsp8 r22, 3
    emit_f1_stsp8 r16, 4
    emit_f1_stsp8 r18, 4
    emit_f1_stsp8 r20, 4
    emit_f1_stsp8 r22, 4
    emit_f1_stsp8 r16, 5
    emit_f1_stsp8 r18, 5
    emit_f1_stsp8 r20, 5
    emit_f1_stsp8 r22, 5
    emit_f1_stsp8 r16, 6
    emit_f1_stsp8 r18, 6
    emit_f1_stsp8 r20, 6
    emit_f1_stsp8 r22, 6
    emit_f1_stsp8 r16, 7
    emit_f1_stsp8 r18, 7
    emit_f1_stsp8 r20, 7
    emit_f1_stsp8 r22, 7
    emit_f1_stsp8 r16, 8
    emit_f1_stsp8 r18, 8
    emit_f1_stsp8 r20, 8
    emit_f1_stsp8 r22, 8
    emit_f1_stsp8 r16, 9
    emit_f1_stsp8 r18, 9
    emit_f1_stsp8 r20, 9
    emit_f1_stsp8 r22, 9
    emit_f1_stsp8 r16, 10
    emit_f1_stsp8 r18, 10
    emit_f1_stsp8 r20, 10
    emit_f1_stsp8 r22, 10
    emit_f1_stsp8 r16, 11
    emit_f1_stsp8 r18, 11
    emit_f1_stsp8 r20, 11
    emit_f1_stsp8 r22, 11
    emit_f1_stsp8 r16, 12
    emit_f1_stsp8 r18, 12
    emit_f1_stsp8 r20, 12
    emit_f1_stsp8 r22, 12
    emit_f1_stsp8 r16, 13
    emit_f1_stsp8 r18, 13
    emit_f1_stsp8 r20, 13
    emit_f1_stsp8 r22, 13
    emit_f1_stsp8 r16, 14
    emit_f1_stsp8 r18, 14
    emit_f1_stsp8 r20, 14
    emit_f1_stsp8 r22, 14
    emit_f1_stsp8 r16, 15
    emit_f1_stsp8 r18, 15
    emit_f1_stsp8 r20, 15
    emit_f1_stsp8 r22, 15
    emit_f1_zext8 r9
    emit_f1_zext8 r11
    emit_f1_zext8 r13
    emit_f1_zext8 r15
    emit_f1_zext8 r17
    emit_f1_zext8 r19
    emit_f1_zext8 r21
    emit_f1_zext8 r23
    emit_f1_swap8 r8
    emit_f1_swap8 r10
    emit_f1_swap8 r12
    emit_f1_swap8 r14
    emit_f1_swap8 r16
    emit_f1_swap8 r18
    emit_f1_swap8 r20
    emit_f1_swap8 r22
    emit_f1_getsp r8
    emit_f1_getsp r10
    emit_f1_getsp r12
    emit_f1_getsp r14
    emit_f1_getsp r16
    emit_f1_getsp r18
    emit_f1_getsp r20
    emit_f1_getsp r22
    emit_f1_setsp r8
    emit_f1_setsp r10
    emit_f1_setsp r12
    emit_f1_setsp r14
    emit_f1_setsp r16
    emit_f1_setsp r18
    emit_f1_setsp r20
    emit_f1_setsp r22
f1_table_end:
.if (f1_table_end - f1_table) != (2 * 0x90 * 2)
    .error "f1_table has incorrect size"
.endif

f2_table:
    ; F2: bounded three-word ADD/SUB/MOV32 table
    emit_f2_add r8, r9, r8, r9
    emit_f2_add r8, r9, r10, r11
    emit_f2_add r8, r9, r12, r13
    emit_f2_add r8, r9, r14, r15
    emit_f2_add r8, r9, r16, r17
    emit_f2_add r8, r9, r18, r19
    emit_f2_add r8, r9, r20, r21
    emit_f2_add r8, r9, r22, r23
    emit_f2_add r10, r11, r8, r9
    emit_f2_add r10, r11, r10, r11
    emit_f2_add r10, r11, r12, r13
    emit_f2_add r10, r11, r14, r15
    emit_f2_add r10, r11, r16, r17
    emit_f2_add r10, r11, r18, r19
    emit_f2_add r10, r11, r20, r21
    emit_f2_add r10, r11, r22, r23
    emit_f2_add r12, r13, r8, r9
    emit_f2_add r12, r13, r10, r11
    emit_f2_add r12, r13, r12, r13
    emit_f2_add r12, r13, r14, r15
    emit_f2_add r12, r13, r16, r17
    emit_f2_add r12, r13, r18, r19
    emit_f2_add r12, r13, r20, r21
    emit_f2_add r12, r13, r22, r23
    emit_f2_add r14, r15, r8, r9
    emit_f2_add r14, r15, r10, r11
    emit_f2_add r14, r15, r12, r13
    emit_f2_add r14, r15, r14, r15
    emit_f2_add r14, r15, r16, r17
    emit_f2_add r14, r15, r18, r19
    emit_f2_add r14, r15, r20, r21
    emit_f2_add r14, r15, r22, r23
    emit_f2_add r16, r17, r8, r9
    emit_f2_add r16, r17, r10, r11
    emit_f2_add r16, r17, r12, r13
    emit_f2_add r16, r17, r14, r15
    emit_f2_add r18, r19, r8, r9
    emit_f2_add r18, r19, r10, r11
    emit_f2_add r18, r19, r12, r13
    emit_f2_add r18, r19, r14, r15
    emit_f2_add r20, r21, r8, r9
    emit_f2_add r20, r21, r10, r11
    emit_f2_add r20, r21, r12, r13
    emit_f2_add r20, r21, r14, r15
    emit_f2_add r22, r23, r8, r9
    emit_f2_add r22, r23, r10, r11
    emit_f2_add r22, r23, r12, r13
    emit_f2_add r22, r23, r14, r15
    emit_f2_sub r8, r9, r8, r9
    emit_f2_sub r8, r9, r10, r11
    emit_f2_sub r8, r9, r12, r13
    emit_f2_sub r8, r9, r14, r15
    emit_f2_sub r8, r9, r16, r17
    emit_f2_sub r8, r9, r18, r19
    emit_f2_sub r8, r9, r20, r21
    emit_f2_sub r8, r9, r22, r23
    emit_f2_sub r10, r11, r8, r9
    emit_f2_sub r10, r11, r10, r11
    emit_f2_sub r10, r11, r12, r13
    emit_f2_sub r10, r11, r14, r15
    emit_f2_sub r10, r11, r16, r17
    emit_f2_sub r10, r11, r18, r19
    emit_f2_sub r10, r11, r20, r21
    emit_f2_sub r10, r11, r22, r23
    emit_f2_sub r12, r13, r8, r9
    emit_f2_sub r12, r13, r10, r11
    emit_f2_sub r12, r13, r12, r13
    emit_f2_sub r12, r13, r14, r15
    emit_f2_sub r12, r13, r16, r17
    emit_f2_sub r12, r13, r18, r19
    emit_f2_sub r12, r13, r20, r21
    emit_f2_sub r12, r13, r22, r23
    emit_f2_sub r14, r15, r8, r9
    emit_f2_sub r14, r15, r10, r11
    emit_f2_sub r14, r15, r12, r13
    emit_f2_sub r14, r15, r14, r15
    emit_f2_sub r14, r15, r16, r17
    emit_f2_sub r14, r15, r18, r19
    emit_f2_sub r14, r15, r20, r21
    emit_f2_sub r14, r15, r22, r23
    emit_f2_sub r16, r17, r8, r9
    emit_f2_sub r16, r17, r10, r11
    emit_f2_sub r16, r17, r12, r13
    emit_f2_sub r16, r17, r14, r15
    emit_f2_sub r18, r19, r8, r9
    emit_f2_sub r18, r19, r10, r11
    emit_f2_sub r18, r19, r12, r13
    emit_f2_sub r18, r19, r14, r15
    emit_f2_sub r20, r21, r8, r9
    emit_f2_sub r20, r21, r10, r11
    emit_f2_sub r20, r21, r12, r13
    emit_f2_sub r20, r21, r14, r15
    emit_f2_sub r22, r23, r8, r9
    emit_f2_sub r22, r23, r10, r11
    emit_f2_sub r22, r23, r12, r13
    emit_f2_sub r22, r23, r14, r15

    ; F2 60-6B: MOV32 in contiguous QPAIR12 order. Upper-pair to
    ; upper-pair copies are omitted because the assembler expands them to two
    ; one-byte upper-register MOV instructions.
    emit_f2_mov32 r8,  r10, r8,  r10  ; q0,q0
    emit_f2_mov32 r8,  r10, r12, r14  ; q0,q1
    emit_f2_mov32 r8,  r10, r16, r18  ; q0,q2
    emit_f2_mov32 r8,  r10, r20, r22  ; q0,q3
    emit_f2_mov32 r12, r14, r8,  r10  ; q1,q0
    emit_f2_mov32 r12, r14, r12, r14  ; q1,q1
    emit_f2_mov32 r12, r14, r16, r18  ; q1,q2
    emit_f2_mov32 r12, r14, r20, r22  ; q1,q3
    emit_f2_mov32 r16, r18, r8,  r10  ; q2,q0
    emit_f2_mov32 r16, r18, r12, r14  ; q2,q1
    emit_f2_mov32 r20, r22, r8,  r10  ; q3,q0
    emit_f2_mov32 r20, r22, r12, r14  ; q3,q1
f2_table_end:
.if (f2_table_end - f2_table) != (2 * 0x6C * 3)
    .error "f2_table has incorrect size"
.endif

f3_table:
    ; F3: bounded three-word memory and widening-multiply table
    emit_f3_st8 r16, r8
    emit_f3_st8 r16, r10
    emit_f3_st8 r16, r12
    emit_f3_st8 r16, r14
    emit_f3_st8 r18, r8
    emit_f3_st8 r18, r10
    emit_f3_st8 r18, r12
    emit_f3_st8 r18, r14
    emit_f3_st8 r20, r8
    emit_f3_st8 r20, r10
    emit_f3_st8 r20, r12
    emit_f3_st8 r20, r14
    emit_f3_st8 r22, r8
    emit_f3_st8 r22, r10
    emit_f3_st8 r22, r12
    emit_f3_st8 r22, r14
    emit_f3_mul mul, r16, r16
    emit_f3_mul mul, r16, r18
    emit_f3_mul mul, r16, r20
    emit_f3_mul mul, r16, r22
    emit_f3_mul mul, r18, r16
    emit_f3_mul mul, r18, r18
    emit_f3_mul mul, r18, r20
    emit_f3_mul mul, r18, r22
    emit_f3_mul mul, r20, r16
    emit_f3_mul mul, r20, r18
    emit_f3_mul mul, r20, r20
    emit_f3_mul mul, r20, r22
    emit_f3_mul mul, r22, r16
    emit_f3_mul mul, r22, r18
    emit_f3_mul mul, r22, r20
    emit_f3_mul mul, r22, r22
    emit_f3_mul muls, r16, r16
    emit_f3_mul muls, r16, r18
    emit_f3_mul muls, r16, r20
    emit_f3_mul muls, r16, r22
    emit_f3_mul muls, r18, r16
    emit_f3_mul muls, r18, r18
    emit_f3_mul muls, r18, r20
    emit_f3_mul muls, r18, r22
    emit_f3_mul muls, r20, r16
    emit_f3_mul muls, r20, r18
    emit_f3_mul muls, r20, r20
    emit_f3_mul muls, r20, r22
    emit_f3_mul muls, r22, r16
    emit_f3_mul muls, r22, r18
    emit_f3_mul muls, r22, r20
    emit_f3_mul muls, r22, r22
    emit_f3_mul mulsu, r16, r16
    emit_f3_mul mulsu, r16, r18
    emit_f3_mul mulsu, r16, r20
    emit_f3_mul mulsu, r16, r22
    emit_f3_mul mulsu, r18, r16
    emit_f3_mul mulsu, r18, r18
    emit_f3_mul mulsu, r18, r20
    emit_f3_mul mulsu, r18, r22
    emit_f3_mul mulsu, r20, r16
    emit_f3_mul mulsu, r20, r18
    emit_f3_mul mulsu, r20, r20
    emit_f3_mul mulsu, r20, r22
    emit_f3_mul mulsu, r22, r16
    emit_f3_mul mulsu, r22, r18
    emit_f3_mul mulsu, r22, r20
    emit_f3_mul mulsu, r22, r22
    emit_f3_ldsp8u r16, r17, 0
    emit_f3_ldsp8u r18, r19, 0
    emit_f3_ldsp8u r20, r21, 0
    emit_f3_ldsp8u r22, r23, 0
    emit_f3_ldsp8u r16, r17, 1
    emit_f3_ldsp8u r18, r19, 1
    emit_f3_ldsp8u r20, r21, 1
    emit_f3_ldsp8u r22, r23, 1
    emit_f3_ldsp8u r16, r17, 2
    emit_f3_ldsp8u r18, r19, 2
    emit_f3_ldsp8u r20, r21, 2
    emit_f3_ldsp8u r22, r23, 2
    emit_f3_ldsp8u r16, r17, 3
    emit_f3_ldsp8u r18, r19, 3
    emit_f3_ldsp8u r20, r21, 3
    emit_f3_ldsp8u r22, r23, 3
    emit_f3_ldsp8u r16, r17, 4
    emit_f3_ldsp8u r18, r19, 4
    emit_f3_ldsp8u r20, r21, 4
    emit_f3_ldsp8u r22, r23, 4
    emit_f3_ldsp8u r16, r17, 5
    emit_f3_ldsp8u r18, r19, 5
    emit_f3_ldsp8u r20, r21, 5
    emit_f3_ldsp8u r22, r23, 5
    emit_f3_ldsp8u r16, r17, 6
    emit_f3_ldsp8u r18, r19, 6
    emit_f3_ldsp8u r20, r21, 6
    emit_f3_ldsp8u r22, r23, 6
    emit_f3_ldsp8u r16, r17, 7
    emit_f3_ldsp8u r18, r19, 7
    emit_f3_ldsp8u r20, r21, 7
    emit_f3_ldsp8u r22, r23, 7
    emit_f3_ldsp8u r16, r17, 8
    emit_f3_ldsp8u r18, r19, 8
    emit_f3_ldsp8u r20, r21, 8
    emit_f3_ldsp8u r22, r23, 8
    emit_f3_ldsp8u r16, r17, 9
    emit_f3_ldsp8u r18, r19, 9
    emit_f3_ldsp8u r20, r21, 9
    emit_f3_ldsp8u r22, r23, 9
    emit_f3_ldsp8u r16, r17, 10
    emit_f3_ldsp8u r18, r19, 10
    emit_f3_ldsp8u r20, r21, 10
    emit_f3_ldsp8u r22, r23, 10
    emit_f3_ldsp8u r16, r17, 11
    emit_f3_ldsp8u r18, r19, 11
    emit_f3_ldsp8u r20, r21, 11
    emit_f3_ldsp8u r22, r23, 11
    emit_f3_ldsp8u r16, r17, 12
    emit_f3_ldsp8u r18, r19, 12
    emit_f3_ldsp8u r20, r21, 12
    emit_f3_ldsp8u r22, r23, 12
    emit_f3_ldsp8u r16, r17, 13
    emit_f3_ldsp8u r18, r19, 13
    emit_f3_ldsp8u r20, r21, 13
    emit_f3_ldsp8u r22, r23, 13
    emit_f3_ldsp8u r16, r17, 14
    emit_f3_ldsp8u r18, r19, 14
    emit_f3_ldsp8u r20, r21, 14
    emit_f3_ldsp8u r22, r23, 14
    emit_f3_ldsp8u r16, r17, 15
    emit_f3_ldsp8u r18, r19, 15
    emit_f3_ldsp8u r20, r21, 15
    emit_f3_ldsp8u r22, r23, 15
f3_table_end:
.if (f3_table_end - f3_table) != (2 * 0x80 * 3)
    .error "f3_table has incorrect size"
.endif

; Cluster B serves F4-F6 and provides both one- and two-cycle flag-commit
; landings needed by TST8, CMP, and TST16 families.
cluster_b_start:
cluster_b_tail_17_delay_1:
    nop
cluster_b_tail_17:
    dispatch_reverse

flags_commit_b_18_delay_2:
    out  VM_FLAGS, SECONDARY_OPCODE
cluster_b_tail_18_delay_2:
    rjmp cluster_b_tail_18
flags_commit_b_18_delay_1:
    out  VM_FLAGS, SECONDARY_OPCODE
cluster_b_tail_18_delay_1:
    nop
cluster_b_tail:
cluster_b_tail_18:
    dispatch
cluster_b_end:
.if (cluster_b_end - cluster_b_start) != 50
    .error "secondary cadence Cluster B must occupy 25 AVR words"
.endif

; F4-F7 contain their exact native slots. A nearby invalid-secondary shim is
; used only by the reserved postincrement-load alias entries in F7.
secondary_tables_before_cluster_c:
secondary_invalid_b_func:
    rjmp invalid_secondary_instruction_func

f4_table:
    ; F4: bounded three-word stack, unary, and fixed-shift table
    emit_f4_ldsp16 r16, r17, 0, 1
    emit_f4_ldsp16 r18, r19, 0, 1
    emit_f4_ldsp16 r20, r21, 0, 1
    emit_f4_ldsp16 r22, r23, 0, 1
    emit_f4_ldsp16 r16, r17, 1, 2
    emit_f4_ldsp16 r18, r19, 1, 2
    emit_f4_ldsp16 r20, r21, 1, 2
    emit_f4_ldsp16 r22, r23, 1, 2
    emit_f4_ldsp16 r16, r17, 2, 3
    emit_f4_ldsp16 r18, r19, 2, 3
    emit_f4_ldsp16 r20, r21, 2, 3
    emit_f4_ldsp16 r22, r23, 2, 3
    emit_f4_ldsp16 r16, r17, 3, 4
    emit_f4_ldsp16 r18, r19, 3, 4
    emit_f4_ldsp16 r20, r21, 3, 4
    emit_f4_ldsp16 r22, r23, 3, 4
    emit_f4_ldsp16 r16, r17, 4, 5
    emit_f4_ldsp16 r18, r19, 4, 5
    emit_f4_ldsp16 r20, r21, 4, 5
    emit_f4_ldsp16 r22, r23, 4, 5
    emit_f4_ldsp16 r16, r17, 5, 6
    emit_f4_ldsp16 r18, r19, 5, 6
    emit_f4_ldsp16 r20, r21, 5, 6
    emit_f4_ldsp16 r22, r23, 5, 6
    emit_f4_ldsp16 r16, r17, 6, 7
    emit_f4_ldsp16 r18, r19, 6, 7
    emit_f4_ldsp16 r20, r21, 6, 7
    emit_f4_ldsp16 r22, r23, 6, 7
    emit_f4_ldsp16 r16, r17, 7, 8
    emit_f4_ldsp16 r18, r19, 7, 8
    emit_f4_ldsp16 r20, r21, 7, 8
    emit_f4_ldsp16 r22, r23, 7, 8
    emit_f4_ldsp16 r16, r17, 8, 9
    emit_f4_ldsp16 r18, r19, 8, 9
    emit_f4_ldsp16 r20, r21, 8, 9
    emit_f4_ldsp16 r22, r23, 8, 9
    emit_f4_ldsp16 r16, r17, 9, 10
    emit_f4_ldsp16 r18, r19, 9, 10
    emit_f4_ldsp16 r20, r21, 9, 10
    emit_f4_ldsp16 r22, r23, 9, 10
    emit_f4_ldsp16 r16, r17, 10, 11
    emit_f4_ldsp16 r18, r19, 10, 11
    emit_f4_ldsp16 r20, r21, 10, 11
    emit_f4_ldsp16 r22, r23, 10, 11
    emit_f4_ldsp16 r16, r17, 11, 12
    emit_f4_ldsp16 r18, r19, 11, 12
    emit_f4_ldsp16 r20, r21, 11, 12
    emit_f4_ldsp16 r22, r23, 11, 12
    emit_f4_ldsp16 r16, r17, 12, 13
    emit_f4_ldsp16 r18, r19, 12, 13
    emit_f4_ldsp16 r20, r21, 12, 13
    emit_f4_ldsp16 r22, r23, 12, 13
    emit_f4_ldsp16 r16, r17, 13, 14
    emit_f4_ldsp16 r18, r19, 13, 14
    emit_f4_ldsp16 r20, r21, 13, 14
    emit_f4_ldsp16 r22, r23, 13, 14
    emit_f4_ldsp16 r16, r17, 14, 15
    emit_f4_ldsp16 r18, r19, 14, 15
    emit_f4_ldsp16 r20, r21, 14, 15
    emit_f4_ldsp16 r22, r23, 14, 15
    emit_f4_ldsp16 r16, r17, 15, 16
    emit_f4_ldsp16 r18, r19, 15, 16
    emit_f4_ldsp16 r20, r21, 15, 16
    emit_f4_ldsp16 r22, r23, 15, 16
    emit_f4_stsp16 r16, r17, 0, 1
    emit_f4_stsp16 r18, r19, 0, 1
    emit_f4_stsp16 r20, r21, 0, 1
    emit_f4_stsp16 r22, r23, 0, 1
    emit_f4_stsp16 r16, r17, 1, 2
    emit_f4_stsp16 r18, r19, 1, 2
    emit_f4_stsp16 r20, r21, 1, 2
    emit_f4_stsp16 r22, r23, 1, 2
    emit_f4_stsp16 r16, r17, 2, 3
    emit_f4_stsp16 r18, r19, 2, 3
    emit_f4_stsp16 r20, r21, 2, 3
    emit_f4_stsp16 r22, r23, 2, 3
    emit_f4_stsp16 r16, r17, 3, 4
    emit_f4_stsp16 r18, r19, 3, 4
    emit_f4_stsp16 r20, r21, 3, 4
    emit_f4_stsp16 r22, r23, 3, 4
    emit_f4_stsp16 r16, r17, 4, 5
    emit_f4_stsp16 r18, r19, 4, 5
    emit_f4_stsp16 r20, r21, 4, 5
    emit_f4_stsp16 r22, r23, 4, 5
    emit_f4_stsp16 r16, r17, 5, 6
    emit_f4_stsp16 r18, r19, 5, 6
    emit_f4_stsp16 r20, r21, 5, 6
    emit_f4_stsp16 r22, r23, 5, 6
    emit_f4_stsp16 r16, r17, 6, 7
    emit_f4_stsp16 r18, r19, 6, 7
    emit_f4_stsp16 r20, r21, 6, 7
    emit_f4_stsp16 r22, r23, 6, 7
    emit_f4_stsp16 r16, r17, 7, 8
    emit_f4_stsp16 r18, r19, 7, 8
    emit_f4_stsp16 r20, r21, 7, 8
    emit_f4_stsp16 r22, r23, 7, 8
    emit_f4_stsp16 r16, r17, 8, 9
    emit_f4_stsp16 r18, r19, 8, 9
    emit_f4_stsp16 r20, r21, 8, 9
    emit_f4_stsp16 r22, r23, 8, 9
    emit_f4_stsp16 r16, r17, 9, 10
    emit_f4_stsp16 r18, r19, 9, 10
    emit_f4_stsp16 r20, r21, 9, 10
    emit_f4_stsp16 r22, r23, 9, 10
    emit_f4_stsp16 r16, r17, 10, 11
    emit_f4_stsp16 r18, r19, 10, 11
    emit_f4_stsp16 r20, r21, 10, 11
    emit_f4_stsp16 r22, r23, 10, 11
    emit_f4_stsp16 r16, r17, 11, 12
    emit_f4_stsp16 r18, r19, 11, 12
    emit_f4_stsp16 r20, r21, 11, 12
    emit_f4_stsp16 r22, r23, 11, 12
    emit_f4_stsp16 r16, r17, 12, 13
    emit_f4_stsp16 r18, r19, 12, 13
    emit_f4_stsp16 r20, r21, 12, 13
    emit_f4_stsp16 r22, r23, 12, 13
    emit_f4_stsp16 r16, r17, 13, 14
    emit_f4_stsp16 r18, r19, 13, 14
    emit_f4_stsp16 r20, r21, 13, 14
    emit_f4_stsp16 r22, r23, 13, 14
    emit_f4_stsp16 r16, r17, 14, 15
    emit_f4_stsp16 r18, r19, 14, 15
    emit_f4_stsp16 r20, r21, 14, 15
    emit_f4_stsp16 r22, r23, 14, 15
    emit_f4_stsp16 r16, r17, 15, 16
    emit_f4_stsp16 r18, r19, 15, 16
    emit_f4_stsp16 r20, r21, 15, 16
    emit_f4_stsp16 r22, r23, 15, 16
    emit_f4_lsl16 r8, r9
    emit_f4_lsl16 r10, r11
    emit_f4_lsl16 r12, r13
    emit_f4_lsl16 r14, r15
    emit_f4_lsl16 r16, r17
    emit_f4_lsl16 r18, r19
    emit_f4_lsl16 r20, r21
    emit_f4_lsl16 r22, r23
    emit_f4_shift lsr, ror, r8, r9
    emit_f4_shift lsr, ror, r10, r11
    emit_f4_shift lsr, ror, r12, r13
    emit_f4_shift lsr, ror, r14, r15
    emit_f4_shift lsr, ror, r16, r17
    emit_f4_shift lsr, ror, r18, r19
    emit_f4_shift lsr, ror, r20, r21
    emit_f4_shift lsr, ror, r22, r23
    emit_f4_shift asr, ror, r8, r9
    emit_f4_shift asr, ror, r10, r11
    emit_f4_shift asr, ror, r12, r13
    emit_f4_shift asr, ror, r14, r15
    emit_f4_shift asr, ror, r16, r17
    emit_f4_shift asr, ror, r18, r19
    emit_f4_shift asr, ror, r20, r21
    emit_f4_shift asr, ror, r22, r23
    emit_f4_not16 r8, r9
    emit_f4_not16 r10, r11
    emit_f4_not16 r12, r13
    emit_f4_not16 r14, r15
    emit_f4_not16 r16, r17
    emit_f4_not16 r18, r19
    emit_f4_not16 r20, r21
    emit_f4_not16 r22, r23
    emit_f4_tst8 r8
    emit_f4_tst8 r10
    emit_f4_tst8 r12
    emit_f4_tst8 r14
    emit_f4_tst8 r16
    emit_f4_tst8 r18
    emit_f4_tst8 r20
    emit_f4_tst8 r22
    emit_f4_inc16 r8, r9
    emit_f4_inc16 r10, r11
    emit_f4_inc16 r12, r13
    emit_f4_inc16 r14, r15
    emit_f4_inc16 r16, r17
    emit_f4_inc16 r18, r19
    emit_f4_inc16 r20, r21
    emit_f4_inc16 r22, r23
    emit_f4_dec16 r8, r9
    emit_f4_dec16 r10, r11
    emit_f4_dec16 r12, r13
    emit_f4_dec16 r14, r15
    emit_f4_dec16 r16, r17
    emit_f4_dec16 r18, r19
    emit_f4_dec16 r20, r21
    emit_f4_dec16 r22, r23
f4_table_end:
.if (f4_table_end - f4_table) != (2 * 0xB8 * 3)
    .error "f4_table has incorrect size"
.endif

f5_table:
    ; F5: bounded four-word compare and ordinary upper-register-pointer memory table
    emit_f5_cmp r8, r9, r8, r9
    emit_f5_cmp r8, r9, r10, r11
    emit_f5_cmp r8, r9, r12, r13
    emit_f5_cmp r8, r9, r14, r15
    emit_f5_cmp r8, r9, r16, r17
    emit_f5_cmp r8, r9, r18, r19
    emit_f5_cmp r8, r9, r20, r21
    emit_f5_cmp r8, r9, r22, r23
    emit_f5_cmp r10, r11, r8, r9
    emit_f5_cmp r10, r11, r10, r11
    emit_f5_cmp r10, r11, r12, r13
    emit_f5_cmp r10, r11, r14, r15
    emit_f5_cmp r10, r11, r16, r17
    emit_f5_cmp r10, r11, r18, r19
    emit_f5_cmp r10, r11, r20, r21
    emit_f5_cmp r10, r11, r22, r23
    emit_f5_cmp r12, r13, r8, r9
    emit_f5_cmp r12, r13, r10, r11
    emit_f5_cmp r12, r13, r12, r13
    emit_f5_cmp r12, r13, r14, r15
    emit_f5_cmp r12, r13, r16, r17
    emit_f5_cmp r12, r13, r18, r19
    emit_f5_cmp r12, r13, r20, r21
    emit_f5_cmp r12, r13, r22, r23
    emit_f5_cmp r14, r15, r8, r9
    emit_f5_cmp r14, r15, r10, r11
    emit_f5_cmp r14, r15, r12, r13
    emit_f5_cmp r14, r15, r14, r15
    emit_f5_cmp r14, r15, r16, r17
    emit_f5_cmp r14, r15, r18, r19
    emit_f5_cmp r14, r15, r20, r21
    emit_f5_cmp r14, r15, r22, r23
    emit_f5_cmp r16, r17, r8, r9
    emit_f5_cmp r16, r17, r10, r11
    emit_f5_cmp r16, r17, r12, r13
    emit_f5_cmp r16, r17, r14, r15
    emit_f5_cmp r18, r19, r8, r9
    emit_f5_cmp r18, r19, r10, r11
    emit_f5_cmp r18, r19, r12, r13
    emit_f5_cmp r18, r19, r14, r15
    emit_f5_cmp r20, r21, r8, r9
    emit_f5_cmp r20, r21, r10, r11
    emit_f5_cmp r20, r21, r12, r13
    emit_f5_cmp r20, r21, r14, r15
    emit_f5_cmp r22, r23, r8, r9
    emit_f5_cmp r22, r23, r10, r11
    emit_f5_cmp r22, r23, r12, r13
    emit_f5_cmp r22, r23, r14, r15
    emit_f5_ld8u r8, r9, r16
    emit_f5_ld8u r10, r11, r16
    emit_f5_ld8u r12, r13, r16
    emit_f5_ld8u r14, r15, r16
    emit_f5_ld8u r8, r9, r18
    emit_f5_ld8u r10, r11, r18
    emit_f5_ld8u r12, r13, r18
    emit_f5_ld8u r14, r15, r18
    emit_f5_ld8u r8, r9, r20
    emit_f5_ld8u r10, r11, r20
    emit_f5_ld8u r12, r13, r20
    emit_f5_ld8u r14, r15, r20
    emit_f5_ld8u r8, r9, r22
    emit_f5_ld8u r10, r11, r22
    emit_f5_ld8u r12, r13, r22
    emit_f5_ld8u r14, r15, r22
    emit_f5_ld16 r8, r9, r16
    emit_f5_ld16 r10, r11, r16
    emit_f5_ld16 r12, r13, r16
    emit_f5_ld16 r14, r15, r16
    emit_f5_ld16 r8, r9, r18
    emit_f5_ld16 r10, r11, r18
    emit_f5_ld16 r12, r13, r18
    emit_f5_ld16 r14, r15, r18
    emit_f5_ld16 r8, r9, r20
    emit_f5_ld16 r10, r11, r20
    emit_f5_ld16 r12, r13, r20
    emit_f5_ld16 r14, r15, r20
    emit_f5_ld16 r8, r9, r22
    emit_f5_ld16 r10, r11, r22
    emit_f5_ld16 r12, r13, r22
    emit_f5_ld16 r14, r15, r22
    emit_f5_st16 r16, r8, r9
    emit_f5_st16 r16, r10, r11
    emit_f5_st16 r16, r12, r13
    emit_f5_st16 r16, r14, r15
    emit_f5_st16 r18, r8, r9
    emit_f5_st16 r18, r10, r11
    emit_f5_st16 r18, r12, r13
    emit_f5_st16 r18, r14, r15
    emit_f5_st16 r20, r8, r9
    emit_f5_st16 r20, r10, r11
    emit_f5_st16 r20, r12, r13
    emit_f5_st16 r20, r14, r15
    emit_f5_st16 r22, r8, r9
    emit_f5_st16 r22, r10, r11
    emit_f5_st16 r22, r12, r13
    emit_f5_st16 r22, r14, r15
f5_table_end:
.if (f5_table_end - f5_table) != (2 * 0x60 * 4)
    .error "f5_table has incorrect size"
.endif

f6_table:
    ; F6: bounded four-word postincrement-store and unary table
    emit_f6_st8_post r16, r8
    emit_f6_st8_post r16, r10
    emit_f6_st8_post r16, r12
    emit_f6_st8_post r16, r14
    emit_f6_st8_post r16, r16
    emit_f6_st8_post r16, r18
    emit_f6_st8_post r16, r20
    emit_f6_st8_post r16, r22
    emit_f6_st8_post r18, r8
    emit_f6_st8_post r18, r10
    emit_f6_st8_post r18, r12
    emit_f6_st8_post r18, r14
    emit_f6_st8_post r18, r16
    emit_f6_st8_post r18, r18
    emit_f6_st8_post r18, r20
    emit_f6_st8_post r18, r22
    emit_f6_st8_post r20, r8
    emit_f6_st8_post r20, r10
    emit_f6_st8_post r20, r12
    emit_f6_st8_post r20, r14
    emit_f6_st8_post r20, r16
    emit_f6_st8_post r20, r18
    emit_f6_st8_post r20, r20
    emit_f6_st8_post r20, r22
    emit_f6_st8_post r22, r8
    emit_f6_st8_post r22, r10
    emit_f6_st8_post r22, r12
    emit_f6_st8_post r22, r14
    emit_f6_st8_post r22, r16
    emit_f6_st8_post r22, r18
    emit_f6_st8_post r22, r20
    emit_f6_st8_post r22, r22
    emit_f6_bswap16 r8, r9
    emit_f6_bswap16 r10, r11
    emit_f6_bswap16 r12, r13
    emit_f6_bswap16 r14, r15
    emit_f6_bswap16 r16, r17
    emit_f6_bswap16 r18, r19
    emit_f6_bswap16 r20, r21
    emit_f6_bswap16 r22, r23
    emit_f6_tst16 r8, r9
    emit_f6_tst16 r10, r11
    emit_f6_tst16 r12, r13
    emit_f6_tst16 r14, r15
    emit_f6_tst16 r16, r17
    emit_f6_tst16 r18, r19
    emit_f6_tst16 r20, r21
    emit_f6_tst16 r22, r23
    emit_f6_mul8 r16, r17, r16
    emit_f6_mul8 r16, r17, r18
    emit_f6_mul8 r16, r17, r20
    emit_f6_mul8 r16, r17, r22
    emit_f6_mul8 r18, r19, r16
    emit_f6_mul8 r18, r19, r18
    emit_f6_mul8 r18, r19, r20
    emit_f6_mul8 r18, r19, r22
    emit_f6_mul8 r20, r21, r16
    emit_f6_mul8 r20, r21, r18
    emit_f6_mul8 r20, r21, r20
    emit_f6_mul8 r20, r21, r22
    emit_f6_mul8 r22, r23, r16
    emit_f6_mul8 r22, r23, r18
    emit_f6_mul8 r22, r23, r20
    emit_f6_mul8 r22, r23, r22
    emit_f6_sext8 r8, r9
    emit_f6_sext8 r10, r11
    emit_f6_sext8 r12, r13
    emit_f6_sext8 r14, r15
    emit_f6_sext8 r16, r17
    emit_f6_sext8 r18, r19
    emit_f6_sext8 r20, r21
    emit_f6_sext8 r22, r23
    emit_f6_neg16 r8, r9
    emit_f6_neg16 r10, r11
    emit_f6_neg16 r12, r13
    emit_f6_neg16 r14, r15
    emit_f6_neg16 r16, r17
    emit_f6_neg16 r18, r19
    emit_f6_neg16 r20, r21
    emit_f6_neg16 r22, r23
f6_table_end:
.if (f6_table_end - f6_table) != (2 * 0x50 * 4)
    .error "f6_table has incorrect size"
.endif

f7_table:
    ; F7: bounded five-word postincrement, 32-bit, and BOOL table
    emit_f7_ld8u_post r8, r9, r16
    emit_f7_ld8u_post r10, r11, r16
    emit_f7_ld8u_post r12, r13, r16
    emit_f7_ld8u_post r14, r15, r16
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_ld8u_post r18, r19, r16
    emit_f7_ld8u_post r20, r21, r16
    emit_f7_ld8u_post r22, r23, r16
    emit_f7_ld8u_post r8, r9, r18
    emit_f7_ld8u_post r10, r11, r18
    emit_f7_ld8u_post r12, r13, r18
    emit_f7_ld8u_post r14, r15, r18
    emit_f7_ld8u_post r16, r17, r18
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_ld8u_post r20, r21, r18
    emit_f7_ld8u_post r22, r23, r18
    emit_f7_ld8u_post r8, r9, r20
    emit_f7_ld8u_post r10, r11, r20
    emit_f7_ld8u_post r12, r13, r20
    emit_f7_ld8u_post r14, r15, r20
    emit_f7_ld8u_post r16, r17, r20
    emit_f7_ld8u_post r18, r19, r20
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_ld8u_post r22, r23, r20
    emit_f7_ld8u_post r8, r9, r22
    emit_f7_ld8u_post r10, r11, r22
    emit_f7_ld8u_post r12, r13, r22
    emit_f7_ld8u_post r14, r15, r22
    emit_f7_ld8u_post r16, r17, r22
    emit_f7_ld8u_post r18, r19, r22
    emit_f7_ld8u_post r20, r21, r22
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_ld16_post r8, r9, r16
    emit_f7_ld16_post r10, r11, r16
    emit_f7_ld16_post r12, r13, r16
    emit_f7_ld16_post r14, r15, r16
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_ld16_post r18, r19, r16
    emit_f7_ld16_post r20, r21, r16
    emit_f7_ld16_post r22, r23, r16
    emit_f7_ld16_post r8, r9, r18
    emit_f7_ld16_post r10, r11, r18
    emit_f7_ld16_post r12, r13, r18
    emit_f7_ld16_post r14, r15, r18
    emit_f7_ld16_post r16, r17, r18
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_ld16_post r20, r21, r18
    emit_f7_ld16_post r22, r23, r18
    emit_f7_ld16_post r8, r9, r20
    emit_f7_ld16_post r10, r11, r20
    emit_f7_ld16_post r12, r13, r20
    emit_f7_ld16_post r14, r15, r20
    emit_f7_ld16_post r16, r17, r20
    emit_f7_ld16_post r18, r19, r20
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_ld16_post r22, r23, r20
    emit_f7_ld16_post r8, r9, r22
    emit_f7_ld16_post r10, r11, r22
    emit_f7_ld16_post r12, r13, r22
    emit_f7_ld16_post r14, r15, r22
    emit_f7_ld16_post r16, r17, r22
    emit_f7_ld16_post r18, r19, r22
    emit_f7_ld16_post r20, r21, r22
    emit_f7_invalid secondary_invalid_b_func
    emit_f7_st16_post r16, r8, r9
    emit_f7_st16_post r16, r10, r11
    emit_f7_st16_post r16, r12, r13
    emit_f7_st16_post r16, r14, r15
    emit_f7_st16_post r16, r16, r17
    emit_f7_st16_post r16, r18, r19
    emit_f7_st16_post r16, r20, r21
    emit_f7_st16_post r16, r22, r23
    emit_f7_st16_post r18, r8, r9
    emit_f7_st16_post r18, r10, r11
    emit_f7_st16_post r18, r12, r13
    emit_f7_st16_post r18, r14, r15
    emit_f7_st16_post r18, r16, r17
    emit_f7_st16_post r18, r18, r19
    emit_f7_st16_post r18, r20, r21
    emit_f7_st16_post r18, r22, r23
    emit_f7_st16_post r20, r8, r9
    emit_f7_st16_post r20, r10, r11
    emit_f7_st16_post r20, r12, r13
    emit_f7_st16_post r20, r14, r15
    emit_f7_st16_post r20, r16, r17
    emit_f7_st16_post r20, r18, r19
    emit_f7_st16_post r20, r20, r21
    emit_f7_st16_post r20, r22, r23
    emit_f7_st16_post r22, r8, r9
    emit_f7_st16_post r22, r10, r11
    emit_f7_st16_post r22, r12, r13
    emit_f7_st16_post r22, r14, r15
    emit_f7_st16_post r22, r16, r17
    emit_f7_st16_post r22, r18, r19
    emit_f7_st16_post r22, r20, r21
    emit_f7_st16_post r22, r22, r23
    emit_f7_add32 r8, r9, r10, r11, r8, r9, r10, r11
    emit_f7_add32 r8, r9, r10, r11, r12, r13, r14, r15
    emit_f7_add32 r8, r9, r10, r11, r16, r17, r18, r19
    emit_f7_add32 r8, r9, r10, r11, r20, r21, r22, r23
    emit_f7_add32 r12, r13, r14, r15, r8, r9, r10, r11
    emit_f7_add32 r12, r13, r14, r15, r12, r13, r14, r15
    emit_f7_add32 r12, r13, r14, r15, r16, r17, r18, r19
    emit_f7_add32 r12, r13, r14, r15, r20, r21, r22, r23
    emit_f7_add32 r16, r17, r18, r19, r8, r9, r10, r11
    emit_f7_add32 r16, r17, r18, r19, r12, r13, r14, r15
    emit_f7_add32 r16, r17, r18, r19, r16, r17, r18, r19
    emit_f7_add32 r16, r17, r18, r19, r20, r21, r22, r23
    emit_f7_add32 r20, r21, r22, r23, r8, r9, r10, r11
    emit_f7_add32 r20, r21, r22, r23, r12, r13, r14, r15
    emit_f7_add32 r20, r21, r22, r23, r16, r17, r18, r19
    emit_f7_add32 r20, r21, r22, r23, r20, r21, r22, r23
    emit_f7_sub32 r8, r9, r10, r11, r8, r9, r10, r11
    emit_f7_sub32 r8, r9, r10, r11, r12, r13, r14, r15
    emit_f7_sub32 r8, r9, r10, r11, r16, r17, r18, r19
    emit_f7_sub32 r8, r9, r10, r11, r20, r21, r22, r23
    emit_f7_sub32 r12, r13, r14, r15, r8, r9, r10, r11
    emit_f7_sub32 r12, r13, r14, r15, r12, r13, r14, r15
    emit_f7_sub32 r12, r13, r14, r15, r16, r17, r18, r19
    emit_f7_sub32 r12, r13, r14, r15, r20, r21, r22, r23
    emit_f7_sub32 r16, r17, r18, r19, r8, r9, r10, r11
    emit_f7_sub32 r16, r17, r18, r19, r12, r13, r14, r15
    emit_f7_sub32 r16, r17, r18, r19, r16, r17, r18, r19
    emit_f7_sub32 r16, r17, r18, r19, r20, r21, r22, r23
    emit_f7_sub32 r20, r21, r22, r23, r8, r9, r10, r11
    emit_f7_sub32 r20, r21, r22, r23, r12, r13, r14, r15
    emit_f7_sub32 r20, r21, r22, r23, r16, r17, r18, r19
    emit_f7_sub32 r20, r21, r22, r23, r20, r21, r22, r23
    emit_f7_lsr32 r8, r9, r10, r11
    emit_f7_lsr32 r12, r13, r14, r15
    emit_f7_lsr32 r16, r17, r18, r19
    emit_f7_lsr32 r20, r21, r22, r23
    emit_f7_asr32 r8, r9, r10, r11
    emit_f7_asr32 r12, r13, r14, r15
    emit_f7_asr32 r16, r17, r18, r19
    emit_f7_asr32 r20, r21, r22, r23
    emit_f7_bool r8, r9
    emit_f7_bool r10, r11
    emit_f7_bool r12, r13
    emit_f7_bool r14, r15
    emit_f7_bool r16, r17
    emit_f7_bool r18, r19
    emit_f7_bool r20, r21
    emit_f7_bool r22, r23
f7_table_end:
.if (f7_table_end - f7_table) != (2 * 0x90 * 5)
    .error "f7_table has incorrect size"
.endif

; Cluster C serves F7/F8 and the late forwarding/shared-body pages.
cluster_c_start:
cluster_c_tail_17_delay_1:
    nop
cluster_c_tail_17:
    dispatch_reverse

cluster_c_tail_18_delay_2:
    rjmp cluster_c_tail_18
cluster_c_tail_18_delay_1:
    nop
cluster_c_tail:
cmov_tail:
cluster_c_tail_18:
    dispatch
cluster_c_end:
.if (cluster_c_end - cluster_c_start) != 46
    .error "secondary cadence Cluster C must occupy 23 AVR words"
.endif

; FA contains immediate body jumps,
; register-count forwarding entries, and destination-specialized shift bodies;
; FE contains forwarding entries and destination-specialized multiplication
; bodies. FB-FD validate secondary < 0x80 in the shared condition gate,
; then use bits 5:0 to select one of the 64 two-word MOVW entries below.
secondary_tables_after_cluster_c:
; FA contains a thirteen-entry immediate body-jump table, 48 two-word
; register-count forwarding entries, and twelve destination-specialized shared
; shift bodies. Register entries copy low4(count) to native r26 before the
; destination can be overwritten, so rD == rCount remains valid. Immediate
; forms place the encoded count in r26 before entering the same bodies.

.macro emit_fa_shift_forward countl, target
.Lfa_forward_start_\@:
    mov   r26, \countl
    rjmp  \target
.Lfa_forward_end_\@:
    .if (.Lfa_forward_end_\@ - .Lfa_forward_start_\@) != 4
        .error "FA shift forwarding entry is not exactly two AVR words"
    .endif
.endm

.macro emit_fa_shl_body label, dstl, dsth
\label:
    andi  r26, 15
    sbrs  r26, 3
    rjmp  .Lfa_shl_no8_\@
    mov   \dsth, \dstl
    clr   \dstl
    andi  r26, 7
.Lfa_shl_no8_\@:
    breq  .Lfa_shl_done_\@
.Lfa_shl_loop_\@:
    lsl   \dstl
    rol   \dsth
    dec   r26
    brne  .Lfa_shl_loop_\@
.Lfa_shl_done_\@:
    rjmp  cluster_c_tail_18
.Lfa_shl_end_\@:
    .if (.Lfa_shl_end_\@ - \label) != 24
        .error "FA SHL16V shared body is not exactly twelve AVR words"
    .endif
.endm

.macro emit_fa_lsr_body label, dstl, dsth
\label:
    andi  r26, 15
    sbrs  r26, 3
    rjmp  .Lfa_lsr_no8_\@
    mov   \dstl, \dsth
    clr   \dsth
    andi  r26, 7
.Lfa_lsr_no8_\@:
    breq  .Lfa_lsr_done_\@
.Lfa_lsr_loop_\@:
    lsr   \dsth
    ror   \dstl
    dec   r26
    brne  .Lfa_lsr_loop_\@
.Lfa_lsr_done_\@:
    rjmp  cluster_c_tail_18
.Lfa_lsr_end_\@:
    .if (.Lfa_lsr_end_\@ - \label) != 24
        .error "FA LSR16V shared body is not exactly twelve AVR words"
    .endif
.endm

.macro emit_fa_asr_body label, dstl, dsth
\label:
    andi  r26, 15
    sbrs  r26, 3
    rjmp  .Lfa_asr_no8_\@
    mov   \dstl, \dsth
    lsl   \dsth
    sbc   \dsth, \dsth
    andi  r26, 7
.Lfa_asr_no8_\@:
    breq  .Lfa_asr_done_\@
.Lfa_asr_loop_\@:
    asr   \dsth
    ror   \dstl
    dec   r26
    brne  .Lfa_asr_loop_\@
.Lfa_asr_done_\@:
    rjmp  cluster_c_tail_18
.Lfa_asr_end_\@:
    .if (.Lfa_asr_end_\@ - \label) != 26
        .error "FA ASR16V shared body is not exactly thirteen AVR words"
    .endif
.endm

fa_immediate_jump_table:
    rjmp  fa_shl_r4
    rjmp  fa_shl_r5
    rjmp  fa_shl_r6
    rjmp  fa_shl_r7
    rjmp  fa_lsr_r4
    rjmp  fa_lsr_r5
    rjmp  fa_lsr_r6
    rjmp  fa_lsr_r7
    rjmp  fa_asr_r4
    rjmp  fa_asr_r5
    rjmp  fa_asr_r6
    rjmp  fa_asr_r7
fa_immediate_invalid:
    rjmp  fa_immediate_invalid
fa_immediate_jump_table_end:
.if (fa_immediate_jump_table_end - fa_immediate_jump_table) != (13 * 2)
    .error "FA immediate jump table must occupy exactly thirteen AVR words"
.endif

fa_forward_table:
    emit_fa_shift_forward r16, fa_shl_r4
    emit_fa_shift_forward r18, fa_shl_r4
    emit_fa_shift_forward r20, fa_shl_r4
    emit_fa_shift_forward r22, fa_shl_r4
    emit_fa_shift_forward r16, fa_shl_r5
    emit_fa_shift_forward r18, fa_shl_r5
    emit_fa_shift_forward r20, fa_shl_r5
    emit_fa_shift_forward r22, fa_shl_r5
    emit_fa_shift_forward r16, fa_shl_r6
    emit_fa_shift_forward r18, fa_shl_r6
    emit_fa_shift_forward r20, fa_shl_r6
    emit_fa_shift_forward r22, fa_shl_r6
    emit_fa_shift_forward r16, fa_shl_r7
    emit_fa_shift_forward r18, fa_shl_r7
    emit_fa_shift_forward r20, fa_shl_r7
    emit_fa_shift_forward r22, fa_shl_r7
    emit_fa_shift_forward r16, fa_lsr_r4
    emit_fa_shift_forward r18, fa_lsr_r4
    emit_fa_shift_forward r20, fa_lsr_r4
    emit_fa_shift_forward r22, fa_lsr_r4
    emit_fa_shift_forward r16, fa_lsr_r5
    emit_fa_shift_forward r18, fa_lsr_r5
    emit_fa_shift_forward r20, fa_lsr_r5
    emit_fa_shift_forward r22, fa_lsr_r5
    emit_fa_shift_forward r16, fa_lsr_r6
    emit_fa_shift_forward r18, fa_lsr_r6
    emit_fa_shift_forward r20, fa_lsr_r6
    emit_fa_shift_forward r22, fa_lsr_r6
    emit_fa_shift_forward r16, fa_lsr_r7
    emit_fa_shift_forward r18, fa_lsr_r7
    emit_fa_shift_forward r20, fa_lsr_r7
    emit_fa_shift_forward r22, fa_lsr_r7
    emit_fa_shift_forward r16, fa_asr_r4
    emit_fa_shift_forward r18, fa_asr_r4
    emit_fa_shift_forward r20, fa_asr_r4
    emit_fa_shift_forward r22, fa_asr_r4
    emit_fa_shift_forward r16, fa_asr_r5
    emit_fa_shift_forward r18, fa_asr_r5
    emit_fa_shift_forward r20, fa_asr_r5
    emit_fa_shift_forward r22, fa_asr_r5
    emit_fa_shift_forward r16, fa_asr_r6
    emit_fa_shift_forward r18, fa_asr_r6
    emit_fa_shift_forward r20, fa_asr_r6
    emit_fa_shift_forward r22, fa_asr_r6
    emit_fa_shift_forward r16, fa_asr_r7
    emit_fa_shift_forward r18, fa_asr_r7
    emit_fa_shift_forward r20, fa_asr_r7
    emit_fa_shift_forward r22, fa_asr_r7
fa_forward_table_end:
.if (fa_forward_table_end - fa_forward_table) != (2 * 0x30 * 2)
    .error "fa_forward_table has incorrect size"
.endif

; The shift-by-eight path reduces counts 8-15 to a byte transfer followed by
; at most seven single-bit iterations. Counts 0-7 use only the loop.
emit_fa_shl_body fa_shl_r4, r16, r17
emit_fa_shl_body fa_shl_r5, r18, r19
emit_fa_shl_body fa_shl_r6, r20, r21
emit_fa_shl_body fa_shl_r7, r22, r23
emit_fa_lsr_body fa_lsr_r4, r16, r17
emit_fa_lsr_body fa_lsr_r5, r18, r19
emit_fa_lsr_body fa_lsr_r6, r20, r21
emit_fa_lsr_body fa_lsr_r7, r22, r23
emit_fa_asr_body fa_asr_r4, r16, r17
emit_fa_asr_body fa_asr_r5, r18, r19
emit_fa_asr_body fa_asr_r6, r20, r21
emit_fa_asr_body fa_asr_r7, r22, r23

fa_shift_bodies_end:
.if (fa_shift_bodies_end - fa_forward_table_end) != ((8 * 12 + 4 * 13) * 2)
    .error "FA shared shift bodies must occupy exactly 296 bytes"
.endif

cmov_table:
    emit_cmov_entry r8, r8
    emit_cmov_entry r8, r10
    emit_cmov_entry r8, r12
    emit_cmov_entry r8, r14
    emit_cmov_entry r8, r16
    emit_cmov_entry r8, r18
    emit_cmov_entry r8, r20
    emit_cmov_entry r8, r22
    emit_cmov_entry r10, r8
    emit_cmov_entry r10, r10
    emit_cmov_entry r10, r12
    emit_cmov_entry r10, r14
    emit_cmov_entry r10, r16
    emit_cmov_entry r10, r18
    emit_cmov_entry r10, r20
    emit_cmov_entry r10, r22
    emit_cmov_entry r12, r8
    emit_cmov_entry r12, r10
    emit_cmov_entry r12, r12
    emit_cmov_entry r12, r14
    emit_cmov_entry r12, r16
    emit_cmov_entry r12, r18
    emit_cmov_entry r12, r20
    emit_cmov_entry r12, r22
    emit_cmov_entry r14, r8
    emit_cmov_entry r14, r10
    emit_cmov_entry r14, r12
    emit_cmov_entry r14, r14
    emit_cmov_entry r14, r16
    emit_cmov_entry r14, r18
    emit_cmov_entry r14, r20
    emit_cmov_entry r14, r22
    emit_cmov_entry r16, r8
    emit_cmov_entry r16, r10
    emit_cmov_entry r16, r12
    emit_cmov_entry r16, r14
    emit_cmov_entry r16, r16
    emit_cmov_entry r16, r18
    emit_cmov_entry r16, r20
    emit_cmov_entry r16, r22
    emit_cmov_entry r18, r8
    emit_cmov_entry r18, r10
    emit_cmov_entry r18, r12
    emit_cmov_entry r18, r14
    emit_cmov_entry r18, r16
    emit_cmov_entry r18, r18
    emit_cmov_entry r18, r20
    emit_cmov_entry r18, r22
    emit_cmov_entry r20, r8
    emit_cmov_entry r20, r10
    emit_cmov_entry r20, r12
    emit_cmov_entry r20, r14
    emit_cmov_entry r20, r16
    emit_cmov_entry r20, r18
    emit_cmov_entry r20, r20
    emit_cmov_entry r20, r22
    emit_cmov_entry r22, r8
    emit_cmov_entry r22, r10
    emit_cmov_entry r22, r12
    emit_cmov_entry r22, r14
    emit_cmov_entry r22, r16
    emit_cmov_entry r22, r18
    emit_cmov_entry r22, r20
    emit_cmov_entry r22, r22
cmov_table_end:
.if (cmov_table_end - cmov_table) != (2 * 0x40 * 2)
    .error "cmov_table has incorrect size"
.endif

; FE contains a 64-entry two-word forwarding table followed by eight
; destination-specialized MUL16 bodies. Each forwarding entry preserves the
; complete source operand in native X before the selected body captures and
; overwrites the architectural destination. This makes every source/destination
; alias legal, including MUL16 rD,rD.

.macro emit_fe_mul16_forward src, target
.Lfe_forward_start_\@:
    movw  r26, \src
    rjmp  \target
.Lfe_forward_end_\@:
    .if (.Lfe_forward_end_\@ - .Lfe_forward_start_\@) != 4
        .error "FE MUL16 forwarding entry is not exactly two AVR words"
    .endif
.endm

.macro emit_fe_mul16_body label, dstl, dsth
\label:
    movw  r30, \dstl       ; preserve original destination aL:aH

    mul   r30, r26          ; aL * bL
    movw  \dstl, r0       ; low product supplies result bits 15:0

    mul   r31, r26          ; aH * bL
    add   \dsth, r0       ; add its low byte into result high byte

    mul   r30, r27          ; aL * bH
    add   \dsth, r0       ; add its low byte into result high byte

    rjmp  cluster_c_tail_18
.Lfe_body_end_\@:
    .if (.Lfe_body_end_\@ - \label) != 16
        .error "FE MUL16 shared body is not exactly eight AVR words"
    .endif
.endm

fe_forward_table:
    emit_fe_mul16_forward r8, fe_mul16_r0
    emit_fe_mul16_forward r10, fe_mul16_r0
    emit_fe_mul16_forward r12, fe_mul16_r0
    emit_fe_mul16_forward r14, fe_mul16_r0
    emit_fe_mul16_forward r16, fe_mul16_r0
    emit_fe_mul16_forward r18, fe_mul16_r0
    emit_fe_mul16_forward r20, fe_mul16_r0
    emit_fe_mul16_forward r22, fe_mul16_r0
    emit_fe_mul16_forward r8, fe_mul16_r1
    emit_fe_mul16_forward r10, fe_mul16_r1
    emit_fe_mul16_forward r12, fe_mul16_r1
    emit_fe_mul16_forward r14, fe_mul16_r1
    emit_fe_mul16_forward r16, fe_mul16_r1
    emit_fe_mul16_forward r18, fe_mul16_r1
    emit_fe_mul16_forward r20, fe_mul16_r1
    emit_fe_mul16_forward r22, fe_mul16_r1
    emit_fe_mul16_forward r8, fe_mul16_r2
    emit_fe_mul16_forward r10, fe_mul16_r2
    emit_fe_mul16_forward r12, fe_mul16_r2
    emit_fe_mul16_forward r14, fe_mul16_r2
    emit_fe_mul16_forward r16, fe_mul16_r2
    emit_fe_mul16_forward r18, fe_mul16_r2
    emit_fe_mul16_forward r20, fe_mul16_r2
    emit_fe_mul16_forward r22, fe_mul16_r2
    emit_fe_mul16_forward r8, fe_mul16_r3
    emit_fe_mul16_forward r10, fe_mul16_r3
    emit_fe_mul16_forward r12, fe_mul16_r3
    emit_fe_mul16_forward r14, fe_mul16_r3
    emit_fe_mul16_forward r16, fe_mul16_r3
    emit_fe_mul16_forward r18, fe_mul16_r3
    emit_fe_mul16_forward r20, fe_mul16_r3
    emit_fe_mul16_forward r22, fe_mul16_r3
    emit_fe_mul16_forward r8, fe_mul16_r4
    emit_fe_mul16_forward r10, fe_mul16_r4
    emit_fe_mul16_forward r12, fe_mul16_r4
    emit_fe_mul16_forward r14, fe_mul16_r4
    emit_fe_mul16_forward r16, fe_mul16_r4
    emit_fe_mul16_forward r18, fe_mul16_r4
    emit_fe_mul16_forward r20, fe_mul16_r4
    emit_fe_mul16_forward r22, fe_mul16_r4
    emit_fe_mul16_forward r8, fe_mul16_r5
    emit_fe_mul16_forward r10, fe_mul16_r5
    emit_fe_mul16_forward r12, fe_mul16_r5
    emit_fe_mul16_forward r14, fe_mul16_r5
    emit_fe_mul16_forward r16, fe_mul16_r5
    emit_fe_mul16_forward r18, fe_mul16_r5
    emit_fe_mul16_forward r20, fe_mul16_r5
    emit_fe_mul16_forward r22, fe_mul16_r5
    emit_fe_mul16_forward r8, fe_mul16_r6
    emit_fe_mul16_forward r10, fe_mul16_r6
    emit_fe_mul16_forward r12, fe_mul16_r6
    emit_fe_mul16_forward r14, fe_mul16_r6
    emit_fe_mul16_forward r16, fe_mul16_r6
    emit_fe_mul16_forward r18, fe_mul16_r6
    emit_fe_mul16_forward r20, fe_mul16_r6
    emit_fe_mul16_forward r22, fe_mul16_r6
    emit_fe_mul16_forward r8, fe_mul16_r7
    emit_fe_mul16_forward r10, fe_mul16_r7
    emit_fe_mul16_forward r12, fe_mul16_r7
    emit_fe_mul16_forward r14, fe_mul16_r7
    emit_fe_mul16_forward r16, fe_mul16_r7
    emit_fe_mul16_forward r18, fe_mul16_r7
    emit_fe_mul16_forward r20, fe_mul16_r7
    emit_fe_mul16_forward r22, fe_mul16_r7
fe_forward_table_end:
.if (fe_forward_table_end - fe_forward_table) != (2 * 0x40 * 2)
    .error "fe_forward_table has incorrect size"
.endif

; Each body is eight words and twelve native cycles including its final RJMP.
; The omitted aH*bH term contributes only above result bit 15.
emit_fe_mul16_body fe_mul16_r0, r8, r9
emit_fe_mul16_body fe_mul16_r1, r10, r11
emit_fe_mul16_body fe_mul16_r2, r12, r13
emit_fe_mul16_body fe_mul16_r3, r14, r15
emit_fe_mul16_body fe_mul16_r4, r16, r17
emit_fe_mul16_body fe_mul16_r5, r18, r19
emit_fe_mul16_body fe_mul16_r6, r20, r21
emit_fe_mul16_body fe_mul16_r7, r22, r23

fe_mul16_bodies_end:
.if (fe_mul16_bodies_end - fe_forward_table_end) != (8 * 8 * 2)
    .error "FE MUL16 shared bodies must occupy exactly 128 bytes"
.endif

; The active secondary executable tables must occupy exactly 6,894 bytes.
.if ((f0_veneer_table_end - f0_veneer_table) + (f1_table_end - f1_table) + (f2_table_end - f2_table) + (f3_table_end - f3_table) + (f4_table_end - f4_table) + (f5_table_end - f5_table) + (f6_table_end - f6_table) + (f7_table_end - f7_table) + (fa_immediate_jump_table_end - fa_immediate_jump_table) + (fa_forward_table_end - fa_forward_table) + (cmov_table_end - cmov_table) + (fe_forward_table_end - fe_forward_table)) != 6894
    .error "secondary executable tables must occupy exactly 6894 bytes"
.endif

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; External-flash bytecode stream positioning
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Seek to the current 24-bit image-relative VM PC and prime one byte. The
; physical W25Q128 address is (data_page_data << 8) + VM_PC, modulo 24 bits.
fx_seek_to_pc:
    fx_disable
    ldi  r30, SFC_READ
    fx_enable
    out  SPDR, r30

    lds  r26, data_page_data+0
    add  r26, VM_PCM
    lds  r27, data_page_data+1
    adc  r27, VM_PCH

    ; A meaningful transmitted address byte must avoid cycle 17, where the
    ; AVR transmits zero. Match the common seek path's 18-cycle first gap.
    rcall fx_seek_delay_11
    out  SPDR, r27
    rcall fx_seek_delay_17
    out  SPDR, r26
    rcall fx_seek_delay_17
    out  SPDR, VM_PCL
    rcall fx_seek_delay_17
    out  SPDR, ZERO

    ; Wait 16 cycles: 2 + 10 + 4 from RET. The addressed byte is ready in
    ; SPDR when this routine returns.
    delay_2
    rcall fx_seek_delay_10
    ret

; Fixed delay ladder. Each name denotes total cycles from the calling RCALL
; through the returning RET, matching the cadence used by the SPI pipeline.
; Entries 7 and 9-14 cover the operand-fetch slack used below without
; repeated inline delay sequences. No current path requires an 8-cycle call.
fx_seek_delay_17:
    nop
fx_seek_delay_16:
    delay_2
fx_seek_delay_14:
    nop
fx_seek_delay_13:
    nop
fx_seek_delay_12:
    nop
fx_seek_delay_11:
    nop
fx_seek_delay_10:
    nop
fx_seek_delay_9:
    delay_2
fx_seek_delay_7:
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Reset/startup
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Startup supports both Arduboy FX flashcart launches and development/emulator
; placement at the end of the 16 MiB FX address space.
;
; Flashcart mode:
;   * reserved interrupt-vector slots contain 0x9518 keys
;   * data/save page numbers follow each key in big-endian byte order
;
; Development mode:
;   * check the AVM tail at 0xFFFFF8 (no save sector)
;   * otherwise check 0xFFEFF8 (final 4 KiB is the save sector)
;   * imageBasePage = tailPage + 1 - imagePageCount
;
; Normal startup validates only the fields needed for safe initialization.
startup_func:
    cli

    ; Native AVR hardware stack. The VM stack is held separately in Y.
    ldi  r26, lo8(RAMEND)
    out  SPL, r26
    ldi  r26, hi8(RAMEND)
    out  SPH, r26

    ; Establish the immutable interpreter constants before any helper runs.
    clr  ZERO
    ldi  r26, 1
    mov  ONE, r26
    ldi  r26, 4
    mov  FOUR, r26

    ; Cathy3K detaches USB when starting a sketch but leaves USB interrupt
    ; enables/controller state intact. A pending event would enter default_isr
    ; at our first SEI, before the guest can draw its title. Detach, mask USB
    ; interrupts, and reset the controller before reconfiguring the shared PLL.
    sts  UDIEN, ZERO
    ldi  r26, _BV(DETACH)
    sts  UDCON, r26
    ldi  r26, _BV(FRZCLK)
    sts  USBCON, r26
    sts  UDINT, ZERO
    sts  USBINT, ZERO

    ; Application static storage is initialized by copying the complete data
    ; image below. There is no separate .bss region or SRAM-clear pass. Clear
    ; only interpreter-private state that is not supplied by the image.
    ; Include inactive sprite/font caches so one loop initializes the complete
    ; contiguous region. Data/save page pointers are installed separately.
    ldi  r30, lo8(data_startup_flags)
    ldi  r31, hi8(data_startup_flags)
    ldi  r26, (data_audio_end-data_startup_flags)
.if (data_audio_end-data_startup_flags) > 255
    .error "startup private-state clear must fit its byte counter"
.endif
1:
    st   Z+, ZERO
    dec  r26
    brne 1b
    ldi  r26, SPRITE_MODE_SELF_MASKED
    sts  data_text_mode, r26

    ; Initialize persistent architectural state. VM_FLAGS lives in low-I/O
    ; GPIOR0; VM PC is loaded from the image header below.
    ldi  VM_SPL, lo8(VM_SP_INITIAL_VALUE)
    ldi  VM_SPH, hi8(VM_SP_INITIAL_VALUE)
    out  VM_FLAGS, ZERO

    ; Configure the complete Arduboy GPIO set before enabling SPI. This leaves
    ; the OLED selected and held in reset, while keeping the FX flash deselected.
    rcall hardware_init_pins_func

    ; Initialize SPI. Startup uses SPIF polling; the bytecode interpreter uses
    ; the fixed-cadence transfer pipeline after the first opcode is primed.
    ; Mode 0, MSB first, f_CPU/2 matches Arduboy2 bootSPI().
    ldi  r26, (_BV(SPE) | _BV(MSTR))
    out  SPCR, r26
    ldi  r26, _BV(SPI2X)
    out  SPSR, r26

    ; Reset and configure the selected SPI OLED controller. Pixel data is sent
    ; only after the application data image has been initialized below.
    rcall oled_startup_init_func

    ; Release the W25Q128 from power-down.
    fx_enable
    ldi  r30, SFC_RELEASE_POWERDOWN
    rcall fx_spi_transfer_blocking
    fx_disable
    rcall fx_startup_wake_delay

    ; Prefer the page values installed by the FX flashcart bootloader.
    ldi  r30, lo8(FX_VECTOR_KEY_POINTER)
    ldi  r31, hi8(FX_VECTOR_KEY_POINTER)
    lpm  r20, Z+
    lpm  r21, Z+
    cpi  r20, lo8(FX_VECTOR_KEY)
    brne startup_find_development_image
    cpi  r21, hi8(FX_VECTOR_KEY)
    brne startup_find_development_image

    ; The flashcart stores page words high byte first in program flash.
    lpm  r27, Z+
    lpm  r26, Z+
    sts  data_page_data+0, r26
    sts  data_page_data+1, r27

    ; A save page is independently keyed and may be absent.
    lpm  r20, Z+
    lpm  r21, Z+
    cpi  r20, lo8(FX_VECTOR_KEY)
    brne startup_read_header
    cpi  r21, hi8(FX_VECTOR_KEY)
    brne startup_read_header
    lpm  r27, Z+
    lpm  r26, Z+
    sts  data_page_save+0, r26
    sts  data_page_save+1, r27
    ldi  r26, _BV(STARTUP_SAVE_PAGE_VALID)
    sts  data_startup_flags, r26
    rjmp startup_read_header

startup_find_development_image:
    ; First try an image whose tail is at the physical end of flash. This form
    ; has no following save sector.
    ldi  r22, FX_DEV_TAIL_NOSAVE_HI
    ldi  r27, FX_DEV_TAIL_NOSAVE_MID
    ldi  r26, AVM_TAIL_OFFSET_IN_PAGE
    clr  r20                      ; tailPage + 1 = 0x0000
    clr  r21
    rcall startup_try_tail
    brcs startup_read_header

    ; Then try an image ending immediately before the final 4 KiB save sector.
    ldi  r22, FX_DEV_TAIL_SAVE_HI
    ldi  r27, FX_DEV_TAIL_SAVE_MID
    ldi  r26, AVM_TAIL_OFFSET_IN_PAGE
    ldi  r20, FX_DEV_SAVE_PAGE_LO ; tailPage + 1 = save page
    ldi  r21, FX_DEV_SAVE_PAGE_HI
    rcall startup_try_tail
    brcs 1f
    rjmp startup_invalid_image
1:

    ldi  r26, FX_DEV_SAVE_PAGE_LO
    ldi  r27, FX_DEV_SAVE_PAGE_HI
    sts  data_page_save+0, r26
    sts  data_page_save+1, r27
    ldi  r26, _BV(STARTUP_SAVE_PAGE_VALID)
    sts  data_startup_flags, r26

startup_read_header:
    ; Begin a read at imageBase + 0x000000.
    clr  r26
    lds  r27, data_page_data+0
    lds  r22, data_page_data+1
    rcall fx_startup_begin_read

    ; magic[4]
    rcall fx_startup_read_byte
    cpi  r30, AVM_HEADER_MAGIC0
    breq 1f
    rjmp startup_invalid_image
1:
    rcall fx_startup_read_byte
    cpi  r30, AVM_HEADER_MAGIC1
    breq 1f
    rjmp startup_invalid_image
1:
    rcall fx_startup_read_byte
    cpi  r30, AVM_HEADER_MAGIC2
    breq 1f
    rjmp startup_invalid_image
1:
    rcall fx_startup_read_byte
    cpi  r30, AVM_HEADER_MAGIC3
    breq 1f
    rjmp startup_invalid_image
1:

    ; One coarse compatibility byte covers the ISA, ABI, and runtime services.
    rcall fx_startup_read_byte
    cpi  r30, AVM_RUNTIME_VERSION
    breq 1f
    rjmp startup_invalid_image
1:

    ; entryPoint, packed little-endian 24-bit image-relative address.
    rcall fx_startup_read_byte
    mov  VM_PCL, r30
    rcall fx_startup_read_byte
    mov  VM_PCM, r30
    rcall fx_startup_read_byte
    mov  VM_PCH, r30

    ; dataSize at header offset 0x08. This is the complete .saved + .data
    ; image size, including bytes whose initial value is zero. It is also the
    ; number of bytes copied from image offset 0x0100 to SRAM address 0x0100.
    rcall fx_startup_read_byte
    mov  r16, r30
    rcall fx_startup_read_byte
    mov  r17, r30

    ; saveSize at header offset 0x0A. Startup uses it only for validation;
    ; persistence services reread it from the image header on every call.
    rcall fx_startup_read_byte
    mov  r20, r30
    rcall fx_startup_read_byte
    mov  r21, r30
    fx_disable

    ; saveSize <= dataSize because the saved region is part of the data image
    ; copied into SRAM.
    cp   r16, r20
    cpc  r17, r21
    brlo startup_invalid_image
1:

    ; dataSize <= 1024. Values below 0x0400 are accepted; 0x0400 itself is
    ; accepted only when the low byte is zero.
    cpi  r17, 0x04
    brlo 1f
    brne startup_invalid_image
2:
    tst  r16
    brne startup_invalid_image
1:

    ; A nonzero save request requires either a keyed flashcart save page or the
    ; development layout with a final 4 KiB save sector. The preceding checks
    ; already imply saveSize <= 1024.
    cp   r20, ZERO
    cpc  r21, ZERO
    breq 3f
    lds  r26, data_startup_flags
    sbrs r26, STARTUP_SAVE_PAGE_VALID
    rjmp startup_invalid_image
3:

    ; Copy the complete data image, including explicitly stored zero bytes.
    ; No separate .bss clear is performed.
startup_copy_data:
    cp   r16, ZERO
    cpc  r17, ZERO
    breq startup_enter_image

    ; Static initializers always begin at image offset 0x0100, one page after
    ; the header.
    lds  r27, data_page_data+0
    lds  r22, data_page_data+1
    inc  r27
    brne 4f
    inc  r22
4:
    clr  r26
    rcall fx_startup_begin_read
    ldi  r26, lo8(data_globals)
    ldi  r27, hi8(data_globals)
startup_copy_data_loop:
    rcall fx_startup_read_byte
    st   X+, r30
    subi r16, 1
    sbci r17, 0
    brne startup_copy_data_loop
    fx_disable

startup_enter_image:
    ; The framebuffer is outside the application data image. Clear all 1024
    ; bytes, then invoke the same native display-update function used by SYS
    ; display.
    ldi   r30, lo8(data_display)
    ldi   r31, hi8(data_display)
    ldi   r24, lo8(1024)
    ldi   r25, hi8(1024)
startup_clear_framebuffer_loop:
    st    Z+, ZERO
    sbiw  r24, 1
    brne  startup_clear_framebuffer_loop

    mov   VM_R4L, ZERO
    call  display_update_func

    ; Timer0 is initialized only after the data image copy and initial display
    ; blanking. Its compare interrupt becomes globally active at the SEI below.
    rcall timer0_init_func
    call  audio_init_func

    ; VM_PCH:VM_PCM:VM_PCL already contains the image entry point. Seek to
    ; it, consume the first primary opcode, and start the following transfer.
    rcall fx_seek_to_pc
    in   PRIMARY_OPCODE, SPDR
    out  SPDR, ZERO
    sei
    delay_1
    mul  PRIMARY_OPCODE, FOUR
    movw r30, r0
    subi r31, hi8(-(pm(primary_table)))
    ijmp

startup_invalid_image:
    cli
    fx_disable
startup_invalid_image_loop:
    rjmp startup_invalid_image_loop

; Configure Timer0 for a 1 kHz compare-A interrupt at f_CPU = 16 MHz:
;   CTC mode, prescaler 64, OCR0A = 249.
; Global interrupts remain disabled until startup_enter_image executes SEI.
timer0_init_func:
    ; Clear both timer power gates before configuring the clock and audio.
    lds  r26, PRR0
    andi r26, (0xff ^ (_BV(PRTIM0) | _BV(PRTIM1)))
    sts  PRR0, r26
    ; Stop Timer0 and mask its interrupts while replacing any bootloader state.
    out  TCCR0B, ZERO
    sts  TIMSK0, ZERO

    ldi  r26, _BV(WGM01)
    out  TCCR0A, r26
    out  TCNT0, ZERO
    ldi  r26, 249
    out  OCR0A, r26

    ; Clear a stale compare-A flag before unmasking the interrupt.
    ldi  r26, _BV(OCF0A)
    out  TIFR0, r26
    ldi  r26, _BV(OCIE0A)
    sts  TIMSK0, r26

    ; Start Timer0 at f_CPU/64.
    ldi  r26, (_BV(CS01) | _BV(CS00))
    out  TCCR0B, r26
    ret

; Try a development tail.
;
; Input:
;   r22:r27:r26 = physical address of tail magic
;   r21:r20     = page immediately following the tail page
;
; Output:
;   C = 1 and data_page_data installed when valid
;   C = 0 otherwise
startup_try_tail:
    rcall fx_startup_begin_read
    rcall fx_startup_read_byte
    cpi  r30, AVM_TAIL_MAGIC0
    brne startup_try_tail_fail
    rcall fx_startup_read_byte
    cpi  r30, AVM_TAIL_MAGIC1
    brne startup_try_tail_fail
    rcall fx_startup_read_byte
    cpi  r30, AVM_TAIL_MAGIC2
    brne startup_try_tail_fail
    rcall fx_startup_read_byte
    cpi  r30, AVM_TAIL_MAGIC3
    brne startup_try_tail_fail

    ; imagePageCount, little-endian. Zero is never valid.
    rcall fx_startup_read_byte
    mov  r0, r30
    rcall fx_startup_read_byte
    mov  r1, r30
    fx_disable
    cp   r0, ZERO
    cpc  r1, ZERO
    breq startup_try_tail_fail_disabled

    ; imageBasePage = pageAfterTail - imagePageCount.
    mov  r26, r20
    mov  r27, r21
    sub  r26, r0
    sbc  r27, r1
    sts  data_page_data+0, r26
    sts  data_page_data+1, r27
    sec
    ret

startup_try_tail_fail:
    fx_disable
startup_try_tail_fail_disabled:
    clc
    ret

; Begin a blocking SFC_READ command.
;
; Input physical byte address: r22:r27:r26 (high:middle:low).
fx_startup_begin_read:
    fx_disable
    fx_enable
    ldi  r30, SFC_READ
    rcall fx_spi_transfer_blocking
    mov  r30, r22
    rcall fx_spi_transfer_blocking
    mov  r30, r27
    rcall fx_spi_transfer_blocking
    mov  r30, r26
    rjmp fx_spi_transfer_blocking

; Read one byte from an already-open startup read stream.
; Result is returned in r30.
fx_startup_read_byte:
    mov  r30, ZERO

; Blocking SPI byte transfer. Input/output: r30. Clobbers r31.
fx_spi_transfer_blocking:
    out  SPDR, r30
1:
    in   r31, SPSR
    sbrs r31, SPIF
    rjmp 1b
    in   r30, SPDR
    ret

; Conservative post-wakeup delay. Startup is not cycle critical.
fx_startup_wake_delay:
    ldi  r26, 32
1:
    dec  r26
    brne 1b
    ret


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Device pin and OLED startup
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Establish the same supported-device idle levels used by Arduboy2 bootPins,
; while changing only explicitly configured pins rather than replacing complete
; PORT/DDR registers. The speaker pins remain untouched, as in Arduboy2.
hardware_init_pins_func:
    ; Shared ATmega32U4 hardware SPI bus: SCK and MOSI outputs low, MISO input
    ; without a pull-up. These pins cannot be remapped by a device preset.
    pin_output_low    PORTB, DDRB, PORTB1
    pin_output_low    PORTB, DDRB, PORTB2
    pin_input_floating PORTB, DDRB, PORTB3

    ; Keep the serial flash inactive while the display is reset and configured.
    pin_output_high AVM_FX_PORT, AVM_FX_DDR, AVM_FX_BIT

    ; Arduboy2 starts with OLED CS asserted, D/C high, and reset asserted low.
    pin_output_low  AVM_OLED_CS_PORT,  AVM_OLED_CS_DDR,  AVM_OLED_CS_BIT
    pin_output_high AVM_OLED_DC_PORT,  AVM_OLED_DC_DDR,  AVM_OLED_DC_BIT
    pin_output_low  AVM_OLED_RST_PORT, AVM_OLED_RST_DDR, AVM_OLED_RST_BIT

#if AVM_INIT_RGB_LED
    ; Active-low RGB channels off.
    pin_output_high AVM_LED_RED_PORT,   AVM_LED_RED_DDR,   AVM_LED_RED_BIT
    pin_output_high AVM_LED_GREEN_PORT, AVM_LED_GREEN_DDR, AVM_LED_GREEN_BIT
    pin_output_high AVM_LED_BLUE_PORT,  AVM_LED_BLUE_DDR,  AVM_LED_BLUE_BIT
#endif

#if AVM_INIT_TX_RX_LEDS
    ; Active-low USB activity LEDs off.
    pin_output_high AVM_LED_TX_PORT, AVM_LED_TX_DDR, AVM_LED_TX_BIT
    pin_output_high AVM_LED_RX_PORT, AVM_LED_RX_DDR, AVM_LED_RX_BIT
#endif

#if AVM_INIT_BUTTONS
    ; All six buttons are active low and use internal pull-ups.
    pin_input_pullup AVM_BUTTON_LEFT_PORT,  AVM_BUTTON_LEFT_DDR,  AVM_BUTTON_LEFT_BIT
    pin_input_pullup AVM_BUTTON_RIGHT_PORT, AVM_BUTTON_RIGHT_DDR, AVM_BUTTON_RIGHT_BIT
    pin_input_pullup AVM_BUTTON_UP_PORT,    AVM_BUTTON_UP_DDR,    AVM_BUTTON_UP_BIT
    pin_input_pullup AVM_BUTTON_DOWN_PORT,  AVM_BUTTON_DOWN_DDR,  AVM_BUTTON_DOWN_BIT
    pin_input_pullup AVM_BUTTON_A_PORT,     AVM_BUTTON_A_DDR,     AVM_BUTTON_A_BIT
    pin_input_pullup AVM_BUTTON_B_PORT,     AVM_BUTTON_B_DDR,     AVM_BUTTON_B_BIT
#endif

#if AVM_INIT_RANDOM_SEED_ADC
    ; Match Arduboy2's floating ADC1 random-seed input and initial mux choice.
    pin_input_floating AVM_RANDOM_SEED_PORT, AVM_RANDOM_SEED_DDR, AVM_RANDOM_SEED_BIT
    ldi  r26, (_BV(REFS0) | _BV(REFS1) | _BV(MUX0))
    sts  ADMUX, r26
#endif
    ret

; Approximately 5 ms at 16 MHz. Startup timing is intentionally conservative
; and is not part of the bytecode interpreter's cycle contract.
oled_reset_delay_5ms_func:
    ldi  r24, 104
1:
    clr  r25
2:
    dec  r25
    brne 2b
    dec  r24
    brne 1b
    ret

; Blocking SPI transfer used while Z walks the OLED command table.
; Input/output: r26. Clobbers r27; preserves Z.
oled_spi_transfer_blocking_func:
    out  SPDR, r26
1:
    in   r27, SPSR
    sbrs r27, SPIF
    rjmp 1b
    in   r26, SPDR
    ret

; Reset the OLED and send the Arduboy2-derived controller boot sequence.
; No display RAM is written here.
oled_startup_init_func:
    rcall oled_reset_delay_5ms_func
    sbi   AVM_OLED_RST_PORT, AVM_OLED_RST_BIT
    rcall oled_reset_delay_5ms_func

    display_enable
    display_command_mode

    ldi  r30, lo8(oled_boot_program)
    ldi  r31, hi8(oled_boot_program)
    ldi  r24, lo8(oled_boot_program_end - oled_boot_program)
1:
    lpm  r26, Z+
    rcall oled_spi_transfer_blocking_func
    dec  r24
    brne 1b

    ; Leave the shared SPI bus idle and ready for the FX flash transaction.
    display_data_mode
    display_disable
    fx_disable
    ret

.p2align 2

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Far FF typed bridges and interpreter-native floating-point cores
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; This code is deliberately placed outside the Cluster-A-to-secondary-table
; window. Entry and dispatch-tail transfers use explicit JMP instructions;
; internal control flow remains relative.

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Direct FMIN/FMAX/FCMP operand loading and comparison
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; GPIOR2 bits:
;   7     FCMP
;   6     FMAX (clear selects FMIN)
;   3:2   left q
;   1:0   right q
;
; Scratch representation after loading:
;   left  low/high = r26:r27 / r24:r25
;   right low/high = r0:r1   / r30:r31
;
; The source selectors use fixed MOVW operations, so no architectural register
; is modified and every source/destination overlap is naturally safe.

ff_direct_load_left_q:
    in    r30, FF_DIRECT_CONTROL_IO
    lsr   r30
    lsr   r30
    andi  r30, 0x03
    sbrc  r30, 1
    rjmp  .Lff_direct_left_high
    sbrc  r30, 0
    rjmp  .Lff_direct_left_q1

.Lff_direct_left_q0:
    movw  r26, r8
    movw  r24, r10
    rjmp  ff_direct_load_right_q

.Lff_direct_left_q1:
    movw  r26, r12
    movw  r24, r14
    rjmp  ff_direct_load_right_q

.Lff_direct_left_high:
    sbrc  r30, 0
    rjmp  .Lff_direct_left_q3

.Lff_direct_left_q2:
    movw  r26, r16
    movw  r24, r18
    rjmp  ff_direct_load_right_q

.Lff_direct_left_q3:
    movw  r26, r20
    movw  r24, r22

ff_direct_load_right_q:
    in    r30, FF_DIRECT_CONTROL_IO
    andi  r30, 0x03
    sbrc  r30, 1
    rjmp  .Lff_direct_right_high
    sbrc  r30, 0
    rjmp  .Lff_direct_right_q1

.Lff_direct_right_q0:
    movw  r0, r8
    movw  r30, r10
    rjmp  ff_direct_operands_ready

.Lff_direct_right_q1:
    movw  r0, r12
    movw  r30, r14
    rjmp  ff_direct_operands_ready

.Lff_direct_right_high:
    sbrc  r30, 0
    rjmp  .Lff_direct_right_q3

.Lff_direct_right_q2:
    movw  r0, r16
    movw  r30, r18
    rjmp  ff_direct_operands_ready

.Lff_direct_right_q3:
    movw  r0, r20
    movw  r30, r22

ff_direct_operands_ready:
    ; Temporarily use permanent ZERO as the operation-control byte. No calls or
    ; SPI handoffs occur before every exit restores r2 with CLR.
    in    r2, FF_DIRECT_CONTROL_IO

    ; Detect a NaN left operand while restoring every temporarily masked bit.
    bst   r25, 7
    andi  r25, 0x7F
    cpi   r25, 0x7F
    brne  .Lff_direct_left_not_nan
    sbrs  r24, 7
    rjmp  .Lff_direct_left_not_nan
    andi  r24, 0x7F
    clr   r25
    or    r25, r26
    or    r25, r27
    or    r25, r24
    breq  .Lff_direct_left_nan_fraction_zero
    ori   r24, 0x80
    ldi   r25, 0x7F
    bld   r25, 7
    rjmp  .Lff_direct_left_nan
.Lff_direct_left_nan_fraction_zero:
    ori   r24, 0x80
    ldi   r25, 0x7F
    bld   r25, 7
    rjmp  .Lff_direct_check_right_nan
.Lff_direct_left_not_nan:
    bld   r25, 7
    rjmp  .Lff_direct_check_right_nan

.Lff_direct_left_nan:
    sbrc  r2, 7
    rjmp  .Lff_direct_cmp_unordered
    ; Number-preferred min/max returns the second operand when the left is NaN,
    ; including the both-NaN case; payload and signaling state remain exact.
    rjmp  .Lff_direct_select_right

.Lff_direct_check_right_nan:
    bst   r31, 7
    andi  r31, 0x7F
    cpi   r31, 0x7F
    brne  .Lff_direct_right_not_nan
    sbrs  r30, 7
    rjmp  .Lff_direct_right_not_nan
    andi  r30, 0x7F
    clr   r31
    or    r31, r0
    or    r31, r1
    or    r31, r30
    breq  .Lff_direct_right_nan_fraction_zero
    ori   r30, 0x80
    ldi   r31, 0x7F
    bld   r31, 7
    rjmp  .Lff_direct_right_nan
.Lff_direct_right_nan_fraction_zero:
    ori   r30, 0x80
    ldi   r31, 0x7F
    bld   r31, 7
    rjmp  .Lff_direct_compare_numeric
.Lff_direct_right_not_nan:
    bld   r31, 7
    rjmp  .Lff_direct_compare_numeric

.Lff_direct_right_nan:
    sbrc  r2, 7
    rjmp  .Lff_direct_cmp_unordered
    rjmp  .Lff_direct_select_left

.Lff_direct_compare_numeric:
    ; FCMP treats both signed zeros as equal. FMIN/FMAX deliberately continue
    ; through sign ordering so -0 wins FMIN and +0 wins FMAX.
    sbrs  r2, 7
    rjmp  .Lff_direct_compare_signs

    tst   r26
    brne  .Lff_direct_compare_signs
    tst   r27
    brne  .Lff_direct_compare_signs
    tst   r24
    brne  .Lff_direct_compare_signs
    cpi   r25, 0x00
    breq  .Lff_direct_left_zero
    cpi   r25, 0x80
    brne  .Lff_direct_compare_signs
.Lff_direct_left_zero:
    tst   r0
    brne  .Lff_direct_compare_signs
    tst   r1
    brne  .Lff_direct_compare_signs
    tst   r30
    brne  .Lff_direct_compare_signs
    cpi   r31, 0x00
    breq  .Lff_direct_equal
    cpi   r31, 0x80
    breq  .Lff_direct_equal

.Lff_direct_compare_signs:
    sbrc  r25, 7
    rjmp  .Lff_direct_left_negative
    sbrc  r31, 7
    rjmp  .Lff_direct_greater
    rjmp  .Lff_direct_compare_positive

.Lff_direct_left_negative:
    sbrs  r31, 7
    rjmp  .Lff_direct_less

    ; Both negative: larger raw magnitude is numerically smaller.
    cp    r25, r31
    brlo  .Lff_direct_greater
    brne  .Lff_direct_less
    cp    r24, r30
    brlo  .Lff_direct_greater
    brne  .Lff_direct_less
    cp    r27, r1
    brlo  .Lff_direct_greater
    brne  .Lff_direct_less
    cp    r26, r0
    brlo  .Lff_direct_greater
    brne  .Lff_direct_less
    rjmp  .Lff_direct_equal

.Lff_direct_compare_positive:
    cp    r25, r31
    brlo  .Lff_direct_less
    brne  .Lff_direct_greater
    cp    r24, r30
    brlo  .Lff_direct_less
    brne  .Lff_direct_greater
    cp    r27, r1
    brlo  .Lff_direct_less
    brne  .Lff_direct_greater
    cp    r26, r0
    brlo  .Lff_direct_less
    brne  .Lff_direct_greater

.Lff_direct_equal:
    sbrc  r2, 7
    rjmp  .Lff_direct_cmp_equal
    rjmp  .Lff_direct_select_left

.Lff_direct_less:
    sbrc  r2, 7
    rjmp  .Lff_direct_cmp_less
    sbrc  r2, 6
    rjmp  .Lff_direct_select_right
    rjmp  .Lff_direct_select_left

.Lff_direct_greater:
    sbrc  r2, 7
    rjmp  .Lff_direct_cmp_greater
    sbrc  r2, 6
    rjmp  .Lff_direct_select_left
    rjmp  .Lff_direct_select_right

.Lff_direct_select_right:
    movw  r26, r0
    movw  r24, r30
.Lff_direct_select_left:
    clr   r2
    in    r30, FF_BRIDGE_META_IO
    rjmp  ff_store_q_result

.Lff_direct_cmp_less:
    ldi   r24, 0xFF
    ldi   r25, 0xFF
    rjmp  .Lff_direct_cmp_store
.Lff_direct_cmp_equal:
    clr   r24
    clr   r25
    rjmp  .Lff_direct_cmp_store
.Lff_direct_cmp_greater:
    ldi   r24, 1
    clr   r25
    rjmp  .Lff_direct_cmp_store
.Lff_direct_cmp_unordered:
    ldi   r24, 2
    clr   r25
.Lff_direct_cmp_store:
    clr   r2
    in    r30, FF_BRIDGE_META_IO
    rjmp  ff_bridge_store_r16

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Direct FTRUNC/FFLOOR/FCEIL/FROUND
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Mode in GPIOR2:
;   0 trunc toward zero
;   1 floor
;   2 ceil
;   3 round halfway away from zero
;
; The selected q value is loaded into the same canonical result representation
; used by the q writer: low half r26:r27, high half r24:r25.
; Partial-byte masks are generated by a loop bounded to seven shifts.
ff_direct_round_load_q:
    in    r0, FF_BRIDGE_META_IO
    sbrc  r0, 1
    rjmp  .Lff_direct_round_high
    sbrc  r0, 0
    rjmp  .Lff_direct_round_q1

.Lff_direct_round_q0:
    movw  r26, r8
    movw  r24, r10
    rjmp  ff_direct_round_ready

.Lff_direct_round_q1:
    movw  r26, r12
    movw  r24, r14
    rjmp  ff_direct_round_ready

.Lff_direct_round_high:
    sbrc  r0, 0
    rjmp  .Lff_direct_round_q3

.Lff_direct_round_q2:
    movw  r26, r16
    movw  r24, r18
    rjmp  ff_direct_round_ready

.Lff_direct_round_q3:
    movw  r26, r20
    movw  r24, r22

ff_direct_round_ready:
    in    r2, FF_DIRECT_CONTROL_IO

    ; Assemble the unbiased-field source exponent E in r30. E >= 150 means the
    ; binary32 value has no fractional bit; this also returns infinities and
    ; NaNs unchanged.
    mov   r30, r25
    lsl   r30
    sbrc  r24, 7
    ori   r30, 1
    cpi   r30, 150
    brlo  .Lff_direct_round_not_integral
    rjmp  .Lff_direct_round_finish
.Lff_direct_round_not_integral:
    cpi   r30, 127
    brsh  .Lff_direct_round_fractional_integer

    ; |x| < 1. Preserve exact signed zero. All other small inputs reduce to
    ; signed zero or signed one according to mode and sign.
    mov   r31, r25
    andi  r31, 0x7F
    or    r31, r24
    or    r31, r27
    or    r31, r26
    brne  .Lff_direct_round_small_nonzero
    rjmp  .Lff_direct_round_finish
.Lff_direct_round_small_nonzero:
    tst   r2
    breq  .Lff_direct_round_make_zero
    sbrc  r2, 1
    rjmp  .Lff_direct_round_small_high_mode

    ; Mode 1: FLOOR.
    sbrs  r25, 7
    rjmp  .Lff_direct_round_make_zero
    rjmp  .Lff_direct_round_make_one

.Lff_direct_round_small_high_mode:
    sbrc  r2, 0
    rjmp  .Lff_direct_round_small_round

    ; Mode 2: CEIL.
    sbrc  r25, 7
    rjmp  .Lff_direct_round_make_zero
    rjmp  .Lff_direct_round_make_one

.Lff_direct_round_small_round:
    ; Mode 3: E == 126 is exactly the [0.5,1) binade.
    cpi   r30, 126
    brlo  .Lff_direct_round_make_zero

.Lff_direct_round_make_one:
    clr   r26
    clr   r27
    ldi   r24, 0x80
    andi  r25, 0x80
    ori   r25, 0x3F
    rjmp  .Lff_direct_round_finish

.Lff_direct_round_make_zero:
    clr   r26
    clr   r27
    clr   r24
    andi  r25, 0x80
    rjmp  .Lff_direct_round_finish

.Lff_direct_round_fractional_integer:
    ; n = 150-E is the number of low raw-magnitude bits to discard (1-23).
    ; Preserve the sign in T and operate on the unsigned magnitude. Split n
    ; into a byte group and a within-byte shift count. The common path builds
    ; its mask in at most seven shifts, examines the discarded fraction, and
    ; clears the low bits without shifting the complete value away and back.
    ldi   r31, 150
    sub   r31, r30
    bst   r25, 7
    andi  r25, 0x7F

    mov   r30, r31
    andi  r30, 0x07             ; within-byte bit count
    cpi   r31, 8
    brlo  .Lff_direct_round_compact_low
    cpi   r31, 16
    brlo  .Lff_direct_round_compact_mid

.Lff_direct_round_compact_high:
    mov   r2, ONE
    lsl   r2                    ; ULP is in r24
    mov   r0, r24               ; partial-byte source
    mov   r1, r26
    or    r1, r27               ; all lower discarded bytes
    tst   r30
    brne  .Lff_direct_round_compact_partial
    mov   r0, r27               ; boundary halfway bit is r27.7
    rjmp  .Lff_direct_round_compact_boundary

.Lff_direct_round_compact_mid:
    mov   r2, ONE               ; ULP is in r27
    mov   r0, r27               ; partial-byte source
    mov   r1, r26               ; lower discarded byte
    tst   r30
    brne  .Lff_direct_round_compact_partial
    mov   r0, r26               ; boundary halfway bit is r26.7
    rjmp  .Lff_direct_round_compact_boundary

.Lff_direct_round_compact_low:
    clr   r2                    ; ULP is in r26; n cannot be a boundary
    mov   r0, r26
    clr   r1

.Lff_direct_round_compact_partial:
    ; r31 = 1 << (n & 7), generated by a loop bounded to seven iterations.
    ldi   r31, 1
.Lff_direct_round_compact_mask_loop:
    lsl   r31
    dec   r30
    brne  .Lff_direct_round_compact_mask_loop

    ; Result flags in r30: bit 0 means any discarded fraction and bit 1 means
    ; the halfway bit is set. r1 already contains all fully discarded bytes.
    mov   r30, r31
    lsr   r30
    and   r30, r0
    breq  .Lff_direct_round_compact_no_half
    ldi   r30, 0x02
    rjmp  .Lff_direct_round_compact_half_done
.Lff_direct_round_compact_no_half:
    clr   r30
.Lff_direct_round_compact_half_done:
    dec   r31                   ; mask below the retained ULP
    and   r0, r31
    or    r1, r0
    breq  .Lff_direct_round_compact_no_discard
    ori   r30, 0x01
.Lff_direct_round_compact_no_discard:

    ; Clear the discarded bits. Convert the low mask to a keep mask, apply it
    ; to the selected byte, and clear all complete lower bytes.
    com   r31
    tst   r2
    breq  .Lff_direct_round_compact_clear_low
    cp    r2, ONE
    breq  .Lff_direct_round_compact_clear_mid

.Lff_direct_round_compact_clear_high:
    and   r24, r31
    clr   r27
    clr   r26
    rjmp  .Lff_direct_round_compact_restore_ulp

.Lff_direct_round_compact_clear_mid:
    and   r27, r31
    clr   r26
    rjmp  .Lff_direct_round_compact_restore_ulp

.Lff_direct_round_compact_clear_low:
    and   r26, r31

.Lff_direct_round_compact_restore_ulp:
    com   r31
    inc   r31                   ; restore 1 << (n & 7)
    rjmp  .Lff_direct_round_decide_increment

.Lff_direct_round_compact_boundary:
    ; n is 8 or 16. The ULP is bit zero of the selected byte, and r0 contains
    ; the preceding byte whose top bit is the halfway bit. r1 is the OR of all
    ; discarded bytes, including r0.
    ldi   r31, 1
    clr   r30
    sbrc  r0, 7
    ori   r30, 0x02
    tst   r1
    breq  .Lff_direct_round_compact_boundary_no_discard
    ori   r30, 0x01
.Lff_direct_round_compact_boundary_no_discard:
    cp    r2, ONE
    breq  .Lff_direct_round_compact_boundary_mid
    clr   r27                   ; n == 16
.Lff_direct_round_compact_boundary_mid:
    clr   r26

.Lff_direct_round_decide_increment:
    ; No discarded fraction means every mode returns the masked value.
    sbrs  r30, 0
    rjmp  .Lff_direct_round_restore_sign

    in    r0, FF_DIRECT_CONTROL_IO
    tst   r0
    breq  .Lff_direct_round_restore_sign
    sbrc  r0, 1
    rjmp  .Lff_direct_round_high_mode_increment

    ; Mode 1: floor.
    brtc  .Lff_direct_round_restore_sign
    rjmp  .Lff_direct_round_apply_direct_ulp

.Lff_direct_round_high_mode_increment:
    sbrc  r0, 0
    rjmp  .Lff_direct_round_round_increment

    ; Mode 2: ceil.
    brts  .Lff_direct_round_restore_sign
    rjmp  .Lff_direct_round_apply_direct_ulp

.Lff_direct_round_round_increment:
    ; Mode 3: round halfway away from zero.
    sbrs  r30, 1
    rjmp  .Lff_direct_round_restore_sign

.Lff_direct_round_apply_direct_ulp:
    clr   r1
    tst   r2
    breq  .Lff_direct_round_add_low
    cp    r2, ONE
    breq  .Lff_direct_round_add_mid

.Lff_direct_round_add_high:
    add   r24, r31
    adc   r25, r1
    rjmp  .Lff_direct_round_restore_sign

.Lff_direct_round_add_mid:
    add   r27, r31
    adc   r24, r1
    adc   r25, r1
    rjmp  .Lff_direct_round_restore_sign

.Lff_direct_round_add_low:
    add   r26, r31
    adc   r27, r1
    adc   r24, r1
    adc   r25, r1

.Lff_direct_round_restore_sign:
    bld   r25, 7
    rjmp  .Lff_direct_round_finish

.Lff_direct_round_finish:
    clr   r2
    in    r30, FF_BRIDGE_META_IO
    rjmp  ff_store_q_result

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Embedded-libm typed bridges
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Binary qD,qS -> qD. The low descriptor nibble has ddss format.
; The destination bits directly choose the save class; no metadata write or
; post-helper destination decode is needed because each table row targets a
; destination-specific call/restore/writeback continuation.
ff_bridge_binary_q_to_q:
    sbrc  FF_BRIDGE_DESC, 3
    rjmp  .Lff_bridge_heavy_binary_high_dest

.Lff_bridge_heavy_binary_save_full:
    push  r18
    push  r19
    push  r20
    push  r21
    push  r22
    push  r23
    rjmp  .Lff_bridge_heavy_binary_saved

.Lff_bridge_heavy_binary_high_dest:
    sbrc  FF_BRIDGE_DESC, 2
    rjmp  .Lff_bridge_heavy_binary_save_q3

.Lff_bridge_heavy_binary_save_q2:
    push  r20
    push  r21
    push  r22
    push  r23
    rjmp  .Lff_bridge_heavy_binary_saved

.Lff_bridge_heavy_binary_save_q3:
    push  r18
    push  r19

.Lff_bridge_heavy_binary_saved:
    movw  r26, r30

    ; Multiply the ddss table index by five in AVR word-address space.
    mov   FF_BRIDGE_META, FF_BRIDGE_DESC
    andi  FF_BRIDGE_META, 0x0F
    ldi   r30, 5
    mul   FF_BRIDGE_META, r30
    ldi   r30, lo8(pm(ff_binary_marshal_table))
    ldi   r31, hi8(pm(ff_binary_marshal_table))
    add   r30, r0
    adc   r31, ZERO
    ijmp

; Emit one alias-safe binary marshalling slot. The four MOVW operations place
; qS in fplib operand B (r18-r21) and qD in operand A (r22-r25).
.macro emit_ff_binary_marshal label, target, d0, s0, d1, s1, d2, s2, d3, s3
\label:
    movw  \d0, \s0
    movw  \d1, \s1
    movw  \d2, \s2
    movw  \d3, \s3
    rjmp  \target
.Lff_binary_marshal_end_\@:
    .if (.Lff_binary_marshal_end_\@ - \label) != 10
        .error "FF binary marshal slot must occupy exactly five AVR words"
    .endif
.endm

ff_binary_marshal_table:
    emit_ff_binary_marshal .Lff_bin_q0_q0, ff_bridge_call_heavy_q0_result, r18, r8,  r20, r10, r22, r8,  r24, r10
    emit_ff_binary_marshal .Lff_bin_q0_q1, ff_bridge_call_heavy_q0_result, r18, r12, r20, r14, r22, r8,  r24, r10
    emit_ff_binary_marshal .Lff_bin_q0_q2, ff_bridge_call_heavy_q0_result, r20, r18, r18, r16, r22, r8,  r24, r10
    emit_ff_binary_marshal .Lff_bin_q0_q3, ff_bridge_call_heavy_q0_result, r18, r20, r20, r22, r22, r8,  r24, r10

    emit_ff_binary_marshal .Lff_bin_q1_q0, ff_bridge_call_heavy_q1_result, r18, r8,  r20, r10, r22, r12, r24, r14
    emit_ff_binary_marshal .Lff_bin_q1_q1, ff_bridge_call_heavy_q1_result, r18, r12, r20, r14, r22, r12, r24, r14
    emit_ff_binary_marshal .Lff_bin_q1_q2, ff_bridge_call_heavy_q1_result, r20, r18, r18, r16, r22, r12, r24, r14
    emit_ff_binary_marshal .Lff_bin_q1_q3, ff_bridge_call_heavy_q1_result, r18, r20, r20, r22, r22, r12, r24, r14

    emit_ff_binary_marshal .Lff_bin_q2_q0, ff_bridge_call_heavy_q2_result, r20, r10, r22, r16, r24, r18, r18, r8
    emit_ff_binary_marshal .Lff_bin_q2_q1, ff_bridge_call_heavy_q2_result, r20, r14, r22, r16, r24, r18, r18, r12
    emit_ff_binary_marshal .Lff_bin_q2_q2, ff_bridge_call_heavy_q2_result, r20, r18, r18, r16, r22, r16, r24, r20
    emit_ff_binary_marshal .Lff_bin_q2_q3, ff_bridge_call_heavy_q2_result, r24, r18, r18, r20, r20, r22, r22, r16

    emit_ff_binary_marshal .Lff_bin_q3_q0, ff_bridge_call_heavy_q3_result, r18, r8,  r24, r22, r22, r20, r20, r10
    emit_ff_binary_marshal .Lff_bin_q3_q1, ff_bridge_call_heavy_q3_result, r18, r12, r24, r22, r22, r20, r20, r14
    emit_ff_binary_marshal .Lff_bin_q3_q2, ff_bridge_call_heavy_q3_result, r24, r22, r22, r20, r20, r18, r18, r16
    emit_ff_binary_marshal .Lff_bin_q3_q3, ff_bridge_call_heavy_q3_result, r18, r20, r20, r22, r22, r18, r24, r20
ff_binary_marshal_table_end:
.if (ff_binary_marshal_table_end - ff_binary_marshal_table) != 160
    .error "FF binary marshal table must occupy exactly eighty AVR words"
.endif

; Unary qD -> qD SQRT uses the heavy helper class.
ff_bridge_unary_q_to_q:
    mov   FF_BRIDGE_META, FF_BRIDGE_DESC
    andi  FF_BRIDGE_META, 0x03
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META
    clr   r1
    rjmp  ff_bridge_save_heavy_q_source

; qS -> qD conversions use the light helper class.
ff_bridge_q_to_q:
    mov   FF_BRIDGE_META, FF_BRIDGE_DESC
    lsr   FF_BRIDGE_META
    lsr   FF_BRIDGE_META
    andi  FF_BRIDGE_META, 0x03
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META
    mov   r1, ONE
    rjmp  ff_bridge_save_light_q_source

; qS -> rD conversions use the light helper class.
ff_bridge_q_to_r16:
    mov   FF_BRIDGE_META, FF_BRIDGE_DESC
    swap  FF_BRIDGE_META
    andi  FF_BRIDGE_META, 0x07
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META
    mov   r1, ONE
    lsl   r1                      ; result-kind 2: light r16
    rjmp  ff_bridge_save_light_q_source

ff_bridge_save_heavy_q_source:
    cpi   FF_BRIDGE_META, 2
    breq  .Lff_bridge_heavy_q_source_save_q2
    brsh  .Lff_bridge_heavy_q_source_save_q3

.Lff_bridge_heavy_q_source_save_full:
    push  r18
    push  r19
    push  r20
    push  r21
    push  r22
    push  r23
    rjmp  .Lff_bridge_q_source_saved

.Lff_bridge_heavy_q_source_save_q2:
    push  r20
    push  r21
    push  r22
    push  r23
    rjmp  .Lff_bridge_q_source_saved

.Lff_bridge_heavy_q_source_save_q3:
    push  r18
    push  r19
    rjmp  .Lff_bridge_q_source_saved

ff_bridge_save_light_q_source:
    ; r1 bit 1 selects r16 result metadata; otherwise metadata is qD.
    sbrc  r1, 1
    rjmp  .Lff_bridge_light_q_source_check_r16
    cpi   FF_BRIDGE_META, 3
    breq  .Lff_bridge_q_source_saved
    push  r22
    push  r23
    rjmp  .Lff_bridge_q_source_saved

.Lff_bridge_light_q_source_check_r16:
    cpi   FF_BRIDGE_META, 7
    breq  .Lff_bridge_q_source_saved
    push  r22
    push  r23

.Lff_bridge_q_source_saved:
    movw  r26, r30
    andi  FF_BRIDGE_DESC, 0x03
    sbrc  FF_BRIDGE_DESC, 1
    rjmp  .Lff_q_source_high
    sbrc  FF_BRIDGE_DESC, 0
    rjmp  .Lff_q_source_q1

.Lff_q_source_q0:
    movw  r22, r8
    movw  r24, r10
    rjmp  ff_bridge_q_source_ready

.Lff_q_source_q1:
    movw  r22, r12
    movw  r24, r14
    rjmp  ff_bridge_q_source_ready

.Lff_q_source_high:
    sbrc  FF_BRIDGE_DESC, 0
    rjmp  .Lff_q_source_q3

.Lff_q_source_q2:
    movw  r22, r16
    movw  r24, r18
    rjmp  ff_bridge_q_source_ready

.Lff_q_source_q3:
    movw  r24, r22
    movw  r22, r20

ff_bridge_q_source_ready:
    tst   r1
    brne  .Lff_bridge_q_source_light_result
    rjmp  ff_bridge_call_heavy_q_result
.Lff_bridge_q_source_light_result:
    sbrc  r1, 1
    rjmp  ff_bridge_call_light_r16_result
    rjmp  ff_bridge_call_light_q_result

; Signed/unsigned rS -> qD conversions retain the generic source decoder.
ff_bridge_r16_to_q_s:
    mov   FF_BRIDGE_META, FF_BRIDGE_DESC
    andi  FF_BRIDGE_META, 0x03
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META
    clr   r1
    rjmp  ff_bridge_save_light_r16_source

ff_bridge_r16_to_q_u:
    mov   FF_BRIDGE_META, FF_BRIDGE_DESC
    andi  FF_BRIDGE_META, 0x03
    out   FF_BRIDGE_META_IO, FF_BRIDGE_META
    mov   r1, ONE

ff_bridge_save_light_r16_source:
    cpi   FF_BRIDGE_META, 3
    breq  .Lff_bridge_light_r16_source_saved
    push  r22
    push  r23
.Lff_bridge_light_r16_source_saved:
    sbrc  r1, 0
    rjmp  ff_bridge_marshal_r16_u

ff_bridge_marshal_r16_s:
    mov   FF_BRIDGE_INDEX, FF_BRIDGE_DESC
    swap  FF_BRIDGE_INDEX
    andi  FF_BRIDGE_INDEX, 0x07
    lsl   FF_BRIDGE_INDEX
    subi  FF_BRIDGE_INDEX, -9
    clr   FF_BRIDGE_XH
    ld    r23, X
    ld    r22, -X
    mov   r24, r23
    lsl   r24
    sbc   r24, r24
    mov   r25, r24
    movw  r26, r30
    rjmp  ff_bridge_call_light_q_result

ff_bridge_marshal_r16_u:
    mov   FF_BRIDGE_INDEX, FF_BRIDGE_DESC
    swap  FF_BRIDGE_INDEX
    andi  FF_BRIDGE_INDEX, 0x07
    lsl   FF_BRIDGE_INDEX
    subi  FF_BRIDGE_INDEX, -9
    clr   FF_BRIDGE_XH
    ld    r23, X
    ld    r22, -X
    clr   r24
    clr   r25
    movw  r26, r30
    rjmp  ff_bridge_call_light_q_result

; Binary helpers use destination-specific call/restore/writeback paths.
; This removes both destination decodes from the binary hot path while still
; omitting destination-owned saves for q2 and q3.
ff_bridge_call_heavy_q0_result:
    movw  r30, r26
    icall
    movw  r8, r22
    movw  r10, r24
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    pop   r19
    pop   r18
    rjmp  ff_cluster_tail_18

ff_bridge_call_heavy_q1_result:
    movw  r30, r26
    icall
    movw  r12, r22
    movw  r14, r24
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    pop   r19
    pop   r18
    rjmp  ff_cluster_tail_18

ff_bridge_call_heavy_q2_result:
    movw  r30, r26
    icall
    movw  r16, r22
    movw  r18, r24
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    rjmp  ff_cluster_tail_18

ff_bridge_call_heavy_q3_result:
    movw  r30, r26
    icall
    movw  r20, r22
    movw  r22, r24
    pop   r19
    pop   r18
    rjmp  ff_cluster_tail_18

; Unary heavy helpers (currently FSQRT) retain the metadata-selected finish.
ff_bridge_call_heavy_q_result:
    movw  r30, r26
    icall
    in    r30, FF_BRIDGE_META_IO
    movw  r26, r22

    cpi   r30, 2
    breq  .Lff_bridge_restore_heavy_q2
    brsh  .Lff_bridge_restore_heavy_q3

.Lff_bridge_restore_heavy_full:
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    pop   r19
    pop   r18
    rjmp  ff_store_q_result

.Lff_bridge_restore_heavy_q2:
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    rjmp  ff_store_q_result

.Lff_bridge_restore_heavy_q3:
    pop   r19
    pop   r18
    rjmp  ff_store_q_result

; Light q helper result: only r22-r23 need restoration, except for q3.
ff_bridge_call_light_q_result:
    movw  r30, r26
    icall
    in    r30, FF_BRIDGE_META_IO
    movw  r26, r22
    cpi   r30, 3
    breq  ff_store_q_result
    pop   r23
    pop   r22

; Canonical q result is low r26:r27, high r24:r25; r30 is qD.
ff_store_q_result:
    sbrc  r30, 1
    rjmp  .Lff_store_q_high
    sbrc  r30, 0
    rjmp  .Lff_store_q1

.Lff_store_q0:
    movw  r8, r26
    movw  r10, r24

ff_cluster_tail_18:
    dispatch

.Lff_store_q1:
    movw  r12, r26
    movw  r14, r24
    rjmp  ff_cluster_tail_18

.Lff_store_q_high:
    sbrc  r30, 0
    rjmp  .Lff_store_q3

.Lff_store_q2:
    movw  r16, r26
    movw  r18, r24
    rjmp  ff_cluster_tail_18

.Lff_store_q3:
    movw  r20, r26
    movw  r22, r24
    rjmp  ff_cluster_tail_18

; Light r16 helper result: generic rD address/store is retained.
ff_bridge_call_light_r16_result:
    movw  r30, r26
    icall
    in    r30, FF_BRIDGE_META_IO
    movw  r24, r22
    cpi   r30, 7
    breq  ff_bridge_store_r16
    pop   r23
    pop   r22

ff_bridge_store_r16:
    andi  r30, 0x07
    lsl   r30
    subi  r30, -8
    clr   r31
    st    Z+, r24
    st    Z,  r25
    rjmp  ff_cluster_tail_18


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Embedded avr-libc/libm-derived binary32 routines
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; The instruction bodies below were transcribed from the exact avr-libc/libm
; and fplib closure present in interp(1).lst. Address-derived local labels keep
; cross-routine control flow unambiguous. Every original in-range absolute
; CALL/JMP has been manually relaxed to RCALL/RJMP; linker relaxation remains
; disabled so the interpreter's fixed-layout dispatch structures are untouched.
;
; Public entry labels retain the names used by the FF helper tables. The block
; includes all shared packing, splitting, normalization, comparison, conversion,
; arithmetic, rounding, and square-root routines reachable from those entries.
; ZERO supplies constant-zero operands; native r1 is free for MUL results and
; sqrtf trial-bit state and is not required to be zero at routine boundaries.

.p2align 1
__subsf3:
    subi  r21, 0x80
__addsf3:
    eor   r27, r27
    eor   r26, r26
    rcall __addsf3x
    rjmp  __fp_round
.L__addsf3_special_cases:
    rcall __fp_pscA
    brcs  .L__addsf3_nan
    rcall __fp_pscB
    brcs  .L__addsf3_nan
    brne  .L__addsf3_infinity
    cpi   r25, 0xFF
    brne  .L__addsf3_infinity_b
    brtc  .L__addsf3_infinity
.L__addsf3_nan:
    rjmp  __fp_nan
.L__addsf3_infinity_b:
    brtc  .L__addsf3_infinity
    com   r30
.L__addsf3_infinity:
    bst   r30, 7
    rjmp  __fp_inf
__addsf3x:
    mov   r30, r25
    rcall __fp_split3
    brcs  .L__addsf3_special_cases
    cp    r27, r26
    cpc   r22, r18
    cpc   r23, r19
    cpc   r24, r20
    cpc   r25, r21
    brcs  .L__addsf3x_swap_operands
    brne  .L__addsf3x_align_mantissas
    brtc  .L__addsf3x_add_mantissas
    rjmp  __fp_zero
.L__addsf3x_swap_operands:
    brtc  .L__addsf3x_swap_values
    com   r30
.L__addsf3x_swap_values:
    mov   r0, r27
    mov   r27, r26
    mov   r26, r0
    movw  r0, r22
    movw  r22, r18
    movw  r18, r0
    movw  r0, r24
    movw  r24, r20
    movw  r20, r0
.L__addsf3x_align_mantissas:
    eor   r31, r31
    sub   r21, r25
.L__addsf3x_align_bytes:
    breq  .L__addsf3x_combine_mantissas
    cpi   r21, 0xF9
    brcc  .L__addsf3x_align_bits
    cpi   r21, 0xE0
    brcs  .L__addsf3x_pack_result
    cp    ZERO, r26
    sbci  r31, 0x00
    mov   r26, r18
    mov   r18, r19
    mov   r19, r20
    eor   r20, r20
    subi  r21, 0xF8
    rjmp  .L__addsf3x_align_bytes
.L__addsf3x_align_bits:
    lsr   r20
    ror   r19
    ror   r18
    ror   r26
    sbci  r31, 0x00
    inc   r21
    brne  .L__addsf3x_align_bits
.L__addsf3x_combine_mantissas:
    brtc  .L__addsf3x_add_mantissas
    cp    ZERO, r31
    sbc   r27, r26
    sbc   r22, r18
    sbc   r23, r19
    sbc   r24, r20
    brmi  .L__addsf3x_pack_result
.L__addsf3x_normalize_difference:
    subi  r25, 0x01
    breq  .L__addsf3x_increment_exponent
    add   r31, r31
    adc   r27, r27
    adc   r22, r22
    adc   r23, r23
    adc   r24, r24
    brpl  .L__addsf3x_normalize_difference
    rjmp  .L__addsf3x_pack_result
.L__addsf3x_add_mantissas:
    add   r27, r26
    adc   r22, r18
    adc   r23, r19
    adc   r24, r20
    brcc  .L__addsf3x_pack_result
    ror   r24
    ror   r23
    ror   r22
    ror   r27
    ror   r31
    cpi   r25, 0xFE
    brcs  .L__addsf3x_increment_exponent
    rjmp  .L__addsf3_infinity
.L__addsf3x_increment_exponent:
    inc   r25
.L__addsf3x_pack_result:
    add   r24, r24
    brcs  .L__addsf3x_apply_sign
    eor   r25, r25
.L__addsf3x_apply_sign:
    add   r30, r30
    ror   r25
    ror   r24
    ret
__divsf3:
    rcall __divsf3x
    rjmp  __fp_round
.L__divsf3_special_cases:
    rcall __fp_pscB
    brcs  .L__divsf3_nan
    rcall __fp_pscA
    brcs  .L__divsf3_nan
    brne  .L__divsf3_szero
    cpi   r21, 0xFF
    breq  .L__divsf3_nan
.L__divsf3_infinity:
    rjmp  __fp_inf
.L__divsf3_zero_numerator:
    cpse  r21, ZERO
.L__divsf3_szero:
    rjmp  __fp_szero
.L__divsf3_nan:
    rjmp  __fp_nan
__divsf3x:
    rcall __fp_split3
    brcs  .L__divsf3_special_cases
__divsf3_pse:
    and   r25, r25
    breq  .L__divsf3_zero_numerator
    and   r21, r21
    breq  .L__divsf3_infinity
    sub   r25, r21
    sbc   r21, r21
    eor   r27, r27
    eor   r26, r26
.L__divsf3_normalize_divisor:
    cp    r22, r18
    cpc   r23, r19
    cpc   r24, r20
    brcs  .L__divsf3_begin_quotient
    subi  r25, 0xFF
    sbci  r21, 0xFF
    add   r18, r18
    adc   r19, r19
    adc   r20, r20
    adc   r26, r26
    breq  .L__divsf3_normalize_divisor
.L__divsf3_begin_quotient:
    rcall .L__divsf3_divide_byte
    mov   r0, r30
    brmi  .L__divsf3_build_remaining_quotient
.L__divsf3_build_leading_quotient:
    ldi   r30, 0x80
    rcall .L__divsf3_divide_bit
    subi  r25, 0x01
    sbci  r21, 0x00
    lsr   r30
    adc   r0, r0
    brpl  .L__divsf3_build_leading_quotient
.L__divsf3_build_remaining_quotient:
    rcall .L__divsf3_divide_byte
    mov   r31, r30
    rcall .L__divsf3_divide_byte
    add   r22, r22
    adc   r23, r23
    adc   r24, r24
    adc   r27, r27
    cp    r18, r22
    cpc   r19, r23
    cpc   r20, r24
    cpc   r26, r27
    ldi   r27, 0x80
    breq  .L__divsf3_finish_quotient
    sbc   r27, r27
.L__divsf3_finish_quotient:
    mov   r24, r0
    movw  r22, r30
    eor   r31, r31
    subi  r25, 0x83
    sbci  r21, 0xFF
    brmi  .L__divsf3_prepare_denormal
    cpi   r25, 0xFE
    cpc   r21, ZERO
    brcs  .L__divsf3_pack_result
    rjmp  __fp_inf
.L__divsf3_underflow_zero:
    rjmp  __fp_szero
.L__divsf3_prepare_denormal:
    cpi   r21, 0xFF
    brlt  .L__divsf3_underflow_zero
    cpi   r25, 0xE8
    brlt  .L__divsf3_underflow_zero
.L__divsf3_denormalize:
    lsr   r24
    ror   r23
    ror   r22
    ror   r27
    ror   r31
    subi  r25, 0xFF
    brne  .L__divsf3_denormalize
.L__divsf3_pack_result:
    add   r24, r24
    adc   r25, ZERO
    lsr   r25
    ror   r24
    bld   r25, 7
    ret
.L__divsf3_divide_byte:
    ldi   r30, 0x01
.L__divsf3_divide_bit:
    add   r22, r22
    adc   r23, r23
    adc   r24, r24
    adc   r27, r27
    cp    r22, r18
    cpc   r23, r19
    cpc   r24, r20
    cpc   r27, r26
    brcs  .L__divsf3_divide_emit_bit
    sub   r22, r18
    sbc   r23, r19
    sbc   r24, r20
    sbc   r27, r26
.L__divsf3_divide_emit_bit:
    adc   r30, r30
    brcc  .L__divsf3_divide_bit
    com   r30
    ret
__fixsfsi:
    rcall __fixunssfsi
    set
    cpse  r27, ZERO
    rjmp  __fp_szero
    ret
__fixunssfsi:
    rcall __fp_splitA
    brcs  .L__fixunssfsi_error
    subi  r25, 0x7F
    brcs  .L__fixunssfsi_zero
    mov   r27, r25
    eor   r25, r25
    subi  r27, 0x17
    brcs  .L__fixunssfsi_select_right_shift
    breq  .L__fixunssfsi_apply_sign
.L__fixunssfsi_shift_left:
    add   r22, r22
    adc   r23, r23
    adc   r24, r24
    adc   r25, r25
    brmi  .L__fixunssfsi_check_signed_overflow
    dec   r27
    brne  .L__fixunssfsi_shift_left
    rjmp  .L__fixunssfsi_apply_sign
.L__fixunssfsi_check_signed_overflow:
    cpi   r27, 0x01
    breq  .L__fixunssfsi_apply_sign
.L__fixunssfsi_error:
    rcall __fp_zero
    ldi   r27, 0x01
    ret
.L__fixunssfsi_zero:
    rjmp  __fp_zero
.L__fixunssfsi_shift_right_byte:
    mov   r22, r23
    mov   r23, r24
    eor   r24, r24
    subi  r27, 0xF8
    breq  .L__fixunssfsi_apply_sign
.L__fixunssfsi_select_right_shift:
    cpi   r27, 0xF9
    brlt  .L__fixunssfsi_shift_right_byte
.L__fixunssfsi_shift_right_bit:
    lsr   r24
    ror   r23
    ror   r22
    inc   r27
    brne  .L__fixunssfsi_shift_right_bit
.L__fixunssfsi_apply_sign:
    brtc  .L__fixunssfsi_return
    com   r25
    com   r24
    com   r23
    neg   r22
    sbci  r23, 0xFF
    sbci  r24, 0xFF
    sbci  r25, 0xFF
.L__fixunssfsi_return:
    ret
__floatunsisf:
    clt
    rjmp  .L__floatsisf_magnitude_ready
__floatsisf:
    bst   r25, 7
    brtc  .L__floatsisf_magnitude_ready
    com   r25
    com   r24
    com   r23
    neg   r22
    sbci  r23, 0xFF
    sbci  r24, 0xFF
    sbci  r25, 0xFF
.L__floatsisf_magnitude_ready:
    and   r25, r25
    breq  .L__floatsisf_check_middle_byte
    mov   r31, r25
    ldi   r25, 0x96
    eor   r27, r27
.L__floatsisf_shift_right:
    inc   r25
    lsr   r31
    ror   r24
    ror   r23
    ror   r22
    ror   r27
    cpse  r31, ZERO
    rjmp  .L__floatsisf_shift_right
    brpl  .L__floatsisf_pack
    add   r27, r27
    brne  .L__floatsisf_round_up
    sbrs  r22, 0
    rjmp  .L__floatsisf_pack
.L__floatsisf_round_up:
    subi  r22, 0xFF
    sbci  r23, 0xFF
    sbci  r24, 0xFF
    sbci  r25, 0xFF
    rjmp  .L__floatsisf_pack
.L__floatsisf_check_middle_byte:
    and   r24, r24
    breq  .L__floatsisf_check_low_word
    ldi   r25, 0x96
    rjmp  .L__floatsisf_continue_left_shift
.L__floatsisf_check_low_word:
    and   r23, r23
    breq  .L__floatsisf_check_low_byte
    ldi   r25, 0x8E
    mov   r24, r23
    mov   r23, r22
    rjmp  .L__floatsisf_prepare_left_shift
.L__floatsisf_check_low_byte:
    and   r22, r22
    breq  .L__floatsisf_return
    ldi   r25, 0x86
    mov   r24, r22
    ldi   r23, 0x00
.L__floatsisf_prepare_left_shift:
    ldi   r22, 0x00
    brmi  .L__floatsisf_pack
.L__floatsisf_shift_left:
    dec   r25
    add   r22, r22
    adc   r23, r23
    adc   r24, r24
.L__floatsisf_continue_left_shift:
    brpl  .L__floatsisf_shift_left
.L__floatsisf_pack:
    add   r24, r24
    lsr   r25
    ror   r24
    bld   r25, 7
.L__floatsisf_return:
    ret
__fp_inf:
    bld   r25, 7
    ori   r25, 0x7F
    ldi   r24, 0x80
    ldi   r23, 0x00
    ldi   r22, 0x00
    ret
__fp_mpack:
    cpi   r25, 0xFF
    breq  .L__fp_mpack_pack_common
__fp_mpack_finite:
    subi  r25, 0x01
    brcc  .L__fp_mpack_pack_common
    ror   r24
    ror   r23
    ror   r22
    ror   r27
.L__fp_mpack_pack_common:
    add   r24, r24
    adc   r25, ZERO
    lsr   r25
    ror   r24
    bld   r25, 7
    ret
__fp_nan:
    ldi   r25, 0xFF
    ldi   r24, 0xC0
    ret
__fp_pscA:
    eor   r0, r0
    dec   r0
    cp    ZERO, r22
    cpc   ZERO, r23
    cpc   ZERO, r24
    cpc   r0, r25
    ret
__fp_pscB:
    eor   r0, r0
    dec   r0
    cp    ZERO, r18
    cpc   ZERO, r19
    cpc   ZERO, r20
    cpc   r0, r21
    ret
__fp_round:
    mov   r0, r25
    inc   r0
    add   r0, r0
    brne  .L__fp_round_check_rounding
    and   r24, r24
    brmi  .L__fp_round_return
.L__fp_round_check_rounding:
    add   r27, r27
    brcc  .L__fp_round_return
    or    r27, r31
    brne  .L__fp_round_increment
    sbrs  r22, 0
    rjmp  .L__fp_round_return
.L__fp_round_increment:
    subi  r22, 0xFF
    sbci  r23, 0xFF
    sbci  r24, 0xFF
    sbci  r25, 0xFF
.L__fp_round_return:
    ret
__fp_split3:
    sbrc  r21, 7
    subi  r25, 0x80
    add   r20, r20
    adc   r21, r21
    breq  .L__fp_split3_b_zero_or_subnormal
    cpi   r21, 0xFF
    breq  .L__fp_split3_b_nonfinite
.L__fp_split3_restore_b_mantissa:
    ror   r20
__fp_splitA:
    add   r24, r24
    bst   r25, 7
    adc   r25, r25
    breq  .L__fp_splitA_zero_or_subnormal
    cpi   r25, 0xFF
    breq  .L__fp_splitA_nonfinite
.L__fp_splitA_restore_mantissa:
    ror   r24
    ret
.L__fp_split3_b_zero_or_subnormal:
    cp    ZERO, r18
    cpc   ZERO, r19
    cpc   ZERO, r20
    adc   r21, r21
    rjmp  .L__fp_split3_restore_b_mantissa
.L__fp_split3_b_nonfinite:
    lsr   r20
    rcall __fp_splitA
    rjmp  .L__fp_splitA_return_nonfinite
.L__fp_splitA_zero_or_subnormal:
    cp    ZERO, r22
    cpc   ZERO, r23
    cpc   ZERO, r24
    adc   r25, r25
    rjmp  .L__fp_splitA_restore_mantissa
.L__fp_splitA_nonfinite:
    lsr   r24
    cpc   r23, ZERO
    cpc   r22, ZERO
.L__fp_splitA_return_nonfinite:
    sec
    ret
__fp_zero:
    clt
__fp_szero:
    eor   r27, r27
    eor   r22, r22
    eor   r23, r23
    movw  r24, r22
    bld   r25, 7
    ret
__mulsf3:
    rcall __mulsf3x
    rjmp  __fp_round
.L__mulsf3_special_cases:
    rcall __fp_pscA
    brcs  .L__mulsf3_nan
    rcall __fp_pscB
    brcs  .L__mulsf3_nan
    and   r25, r21
    breq  .L__mulsf3_nan
    rjmp  __fp_inf
.L__mulsf3_nan:
    rjmp  __fp_nan
.L__mulsf3_szero:
    rjmp  __fp_szero
__mulsf3x:
    rcall __fp_split3
    brcs  .L__mulsf3_special_cases
__mulsf3_pse:
    mul   r25, r21
    breq  .L__mulsf3_szero
    add   r25, r21
    ldi   r21, 0x00
    adc   r21, r21
    mul   r22, r18
    movw  r30, r0
    mul   r23, r18
    eor   r27, r27
    add   r31, r0
    adc   r27, r1
    mul   r22, r19
    eor   r26, r26
    add   r31, r0
    adc   r27, r1
    adc   r26, r26
    mul   r22, r20
    eor   r22, r22
    add   r27, r0
    adc   r26, r1
    adc   r22, r22
    mul   r24, r18
    eor   r18, r18
    add   r27, r0
    adc   r26, r1
    adc   r22, r18
    mul   r23, r19
    add   r27, r0
    adc   r26, r1
    adc   r22, r18
    mul   r24, r19
    add   r26, r0
    adc   r22, r1
    adc   r18, r18
    mul   r23, r20
    eor   r19, r19
    add   r26, r0
    adc   r22, r1
    adc   r18, r19
    mul   r24, r20
    add   r22, r0
    adc   r18, r1
    mov   r24, r18
    mov   r23, r22
    mov   r22, r26
    subi  r25, 0x7F
    sbci  r21, 0x00
    brmi  .L__mulsf3_prepare_denormal
    breq  .L__mulsf3_pack_result
.L__mulsf3_normalize:
    and   r24, r24
    brmi  .L__mulsf3_check_overflow
    add   r30, r30
    adc   r31, r31
    adc   r27, r27
    adc   r22, r22
    adc   r23, r23
    adc   r24, r24
    subi  r25, 0x01
    sbci  r21, 0x00
    brne  .L__mulsf3_normalize
.L__mulsf3_check_overflow:
    cpi   r25, 0xFE
    cpc   r21, ZERO
    brcs  .L__mulsf3_pack_result
    rjmp  __fp_inf
.L__mulsf3_underflow_zero:
    rjmp  __fp_szero
.L__mulsf3_prepare_denormal:
    cpi   r21, 0xFF
    brlt  .L__mulsf3_underflow_zero
    cpi   r25, 0xE8
    brlt  .L__mulsf3_underflow_zero
.L__mulsf3_denormalize:
    lsr   r24
    ror   r23
    ror   r22
    ror   r27
    ror   r31
    ror   r30
    subi  r25, 0xFF
    brne  .L__mulsf3_denormalize
.L__mulsf3_pack_result:
    or    r31, r30
    add   r24, r24
    adc   r25, ZERO
    lsr   r25
    ror   r24
    bld   r25, 7
    ret
.L_sqrtf_nonfinite:
    brne  .L_sqrtf_pack
    brtc  .L_sqrtf_pack
.L_sqrtf_nan:
    rjmp  __fp_nan
.L_sqrtf_pack:
    rjmp  __fp_mpack
sqrt:
sqrtf:
    rcall __fp_splitA
    brcs  .L_sqrtf_nonfinite
    and   r25, r25
    breq  .L_sqrtf_pack
    brts  .L_sqrtf_nan
    subi  r25, 0x7F
    sbc   r21, r21
    sbrs  r24, 7
    rcall __fp_norm2
    eor   r0, r0
    mov   r1, ZERO
    ldi   r26, 0x60
    ldi   r20, 0xA0
    movw  r18, r0
    subi  r24, 0x80
    lsr   r21
    ror   r25
    brcc  .L_sqrtf_compare_trial
    subi  r24, 0xC0
.L_sqrtf_digit_loop:
    add   r22, r22
    adc   r23, r23
    adc   r24, r24
    brcs  .L_sqrtf_accept_trial
.L_sqrtf_compare_trial:
    cp    r18, r22
    cpc   r19, r23
    cpc   r20, r24
    brcc  .L_sqrtf_advance_digit
.L_sqrtf_accept_trial:
    sub   r22, r18
    sbc   r23, r19
    sbc   r24, r20
    or    r18, r0
    or    r19, r1
    or    r20, r26
.L_sqrtf_advance_digit:
    lsr   r26
    ror   r1
    ror   r0
    eor   r18, r0
    eor   r19, r1
    eor   r20, r26
    brcc  .L_sqrtf_digit_loop
.L_sqrtf_rounding_loop:
    add   r22, r22
    adc   r23, r23
    adc   r24, r24
    brcs  .L_sqrtf_accept_rounding_bit
    cp    r18, r22
    cpc   r19, r23
    cpc   r20, r24
    brcc  .L_sqrtf_advance_rounding
.L_sqrtf_accept_rounding_bit:
    sbc   r22, r18
    sbc   r23, r19
    sbc   r24, r20
    add   r18, r0
    adc   r19, r1
    adc   r20, r1
.L_sqrtf_advance_rounding:
    com   r26
    brne  .L_sqrtf_rounding_loop
    movw  r22, r18
    mov   r24, r20
    subi  r25, 0x81
    add   r24, r24
    lsr   r25
    ror   r24
    ret
__fp_norm2:
    subi  r25, 0x01
    sbci  r21, 0x00
    add   r22, r22
    adc   r23, r23
    adc   r24, r24
    brpl  __fp_norm2
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Additional avr-libc/libm-derived transcendental and remainder routines
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Calling convention within this block is the avr-libc fplib convention:
;   A/result = r25:r24:r23:r22, extension r27
;   B        = r21:r20:r19:r18, extension r26
;
; Constant tables remain in .text so ordinary LPM byte addresses are valid on
; the ATmega32U4. Cross-routine transfers start in absolute form and are
; manually relaxed after final layout validation.

; float squaref(float A)
squaref:
    movw  r18, r22
    movw  r20, r24
    rjmp   __mulsf3

; float __inversef(float A) = 1.0f / A
__inversef:
    movw  r18, r22
    movw  r20, r24
    ldi   r22, 0x00
    ldi   r23, 0x00
    ldi   r24, 0x80
    ldi   r25, 0x3f
    rjmp   __divsf3

; Evaluate a table-driven polynomial in A. The first table byte is the degree;
; the leading coefficient is binary32 and each remaining coefficient is the
; five-byte internal fplib format.
__fp_powser:
    push  r29
    push  r28
    push  r17
    push  r16
    push  r15
    push  r14
    push  r13
    movw  r14, r22
    movw  r16, r24
    set
    rjmp  .L__fp_powser_load_coefficient

.L__fp_powser_capture_degree:
    mov   r13, r26

.L__fp_powser_multiply_loop:
    movw  r28, r30
    rcall  __mulsf3x
    movw  r30, r28
    clt

.L__fp_powser_load_coefficient:
    lpm   r26, Z+
    lpm   r18, Z+
    lpm   r19, Z+
    lpm   r20, Z+
    lpm   r21, Z+
    brts  .L__fp_powser_capture_degree

    movw  r28, r30
    rcall  __addsf3x
    movw  r30, r28
    movw  r18, r14
    movw  r20, r16
    dec   r13
    brne  .L__fp_powser_multiply_loop

    pop   r13
    pop   r14
    pop   r15
    pop   r16
    pop   r17
    pop   r28
    pop   r29
    ret

; Evaluate an odd-power polynomial and return a rounded binary32 result.
__fp_powsodd:
    push  r25
    push  r24
    push  r23
    push  r22
    push  r31
    push  r30
    movw  r18, r22
    movw  r20, r24
    rcall  __mulsf3
    pop   r30
    pop   r31
    rcall  __fp_powser
    pop   r18
    pop   r19
    pop   r20
    pop   r21
    rjmp   __mulsf3

; Reduce |A| modulo pi/2. Returns the five-byte internal remainder and the low
; quotient byte in r30.
__fp_rempio2:
    rcall  __fp_splitA
    brcc  .L__fp_rempio2_finite
    rjmp   __fp_nan

.L__fp_rempio2_finite:
    clt
    ldi   r30, 0
    clr   r27
    subi  r25, 0x7f
    brlo  .L__fp_rempio2_pack
    ldi   r18, 0xda
    ldi   r19, 0x0f
    ldi   r20, 0xc9
    rjmp  .L__fp_rempio2_compare

.L__fp_rempio2_loop:
    lsl   r30
    lsl   r27
    rol   r22
    rol   r23
    rol   r24
    brcs  .L__fp_rempio2_subtract

.L__fp_rempio2_compare:
    cpi   r27, 0xa2
    cpc   r22, r18
    cpc   r23, r19
    cpc   r24, r20
    brlo  .L__fp_rempio2_advance

.L__fp_rempio2_subtract:
    subi  r27, 0xa2
    sbc   r22, r18
    sbc   r23, r19
    sbc   r24, r20
    inc   r30

.L__fp_rempio2_advance:
    dec   r25
    brpl  .L__fp_rempio2_loop
    cpi   r24, 0x80
    brsh  .L__fp_rempio2_pack

.L__fp_rempio2_normalize:
    dec   r25
    lsl   r27
    rol   r22
    rol   r23
    rol   r24
    brpl  .L__fp_rempio2_normalize

.L__fp_rempio2_pack:
    sbci  r25, 0x80
    rjmp   __fp_mpack_finite

; Shared sine/cosine kernel. r30 contains the reduced quadrant number.
__fp_sinus:
    push  r30
    sbrs  r30, 0
    rjmp  .L__fp_sinus_round_remainder
    ldi   r26, 0xa2
    ldi   r18, 0xda
    ldi   r19, 0x0f
    ldi   r20, 0xc9
    ldi   r21, 0xbf
    rcall  __addsf3x

.L__fp_sinus_round_remainder:
    rcall  __fp_round
    pop   r0
    inc   r0
    sbrc  r0, 1
    subi  r25, 0x80
    ldi   r30, lo8(sinf_coefficients)
    ldi   r31, hi8(sinf_coefficients)
    rjmp   __fp_powsodd

; float sinf(float A)
sinf:
    push  r25
    rcall  __fp_rempio2
    pop   r0
    sbrc  r0, 7
    subi  r30, -2
    rjmp   __fp_sinus

; float cosf(float A)
cosf:
    rcall  __fp_rempio2
    inc   r30
    rjmp   __fp_sinus

; float atanf(float A)
atanf:
    push  r29
    clr   r29
    mov   r27, r25
    andi  r27, 0x7f
    ldi   r20, 0x80
    ldi   r21, 0x3f
    cp    ZERO, r22
    cpc   ZERO, r23
    cpc   r20, r24
    cpc   r21, r27
    brsh  .Latanf_reduced
    mov   r29, r25
    rcall  __inversef

.Latanf_reduced:
    push  r25
    push  r24
    push  r23
    push  r22
    rcall  squaref
    ldi   r30, lo8(atanf_coefficients)
    ldi   r31, hi8(atanf_coefficients)
    rcall  __fp_powser
    rcall  __fp_round
    pop   r18
    pop   r19
    pop   r20
    pop   r21
    rcall  __mulsf3x
    tst   r29
    breq  .Latanf_finish
    subi  r25, 0x80
    ldi   r26, 0xa2
    ldi   r18, 0xda
    ldi   r19, 0x0f
    ldi   r20, 0xc9
    ldi   r21, 0x3f
    andi  r29, 0x80
    eor   r21, r29
    rcall  __addsf3x

.Latanf_finish:
    pop   r29
    rjmp   __fp_round

; float atan2f(float y=A, float x=B)
atan2f:
    mov   r30, r25
    andi  r30, 0x80
    rcall  __fp_split3
    brcs  .Latan2f_nonfinite

.Latan2f_operands_finite:
    mov   r0, r25
    or    r0, r21
    breq  .Latan2f_zero_result

.Latan2f_compare_magnitudes:
    cp    r18, r22
    cpc   r19, r23
    cpc   r20, r24
    cpc   r21, r25
    brlo  .Latan2f_swap_operands

    mov   r0, r30
    bld   r0, 7
    eor   r30, r0
    breq  .Latan2f_divide
    eor   r30, r0
    ori   r30, 0x40
    rjmp  .Latan2f_divide

.Latan2f_swap_operands:
    ori   r30, 0x3f
    bld   r0, 7
    com   r0
    bst   r0, 7
    movw  r26, r22
    movw  r22, r18
    movw  r18, r26
    movw  r26, r24
    movw  r24, r20
    movw  r20, r26

.Latan2f_divide:
    push  r30
    rcall  __divsf3_pse
    rcall  __fp_round
    rcall  atanf
    pop   r21
    tst   r21
    breq  .Latan2f_return
    ldi   r18, 0xdb
    ldi   r19, 0x0f
    ldi   r20, 0x49
    sbrc  r21, 0
    ldi   r20, 0xc9
    rjmp   __addsf3

.Latan2f_return:
    ret

.Latan2f_nonfinite:
    rcall  __fp_pscA
    brcs  .Latan2f_nan_result
    ldi   r24, 0x80
    ldi   r25, 0x01
    brne  .Latan2f_nonfinite_a_ready
    ldi   r25, 0xfe

.Latan2f_nonfinite_a_ready:
    rcall  __fp_pscB
    brcs  .Latan2f_nan_result
    ldi   r20, 0x80
    ldi   r21, 0x01
    brne  .Latan2f_compare_magnitudes
    ldi   r21, 0xfe
    rjmp  .Latan2f_compare_magnitudes

.Latan2f_nan_result:
    rjmp   __fp_nan

.Latan2f_zero_result:
    rjmp   __fp_zero

; float tanf(float A)
tanf:
    push  r29
    mov   r29, r25
    rcall  __fp_rempio2
    lsr   r30
    ror   r29
    ldi   r18, 0xda
    ldi   r19, 0x0f
    ldi   r20, 0x49
    ldi   r21, 0x3f
    cpi   r27, 0xa3
    cpc   r22, r18
    cpc   r23, r19
    cpc   r24, r20
    cpc   r25, r21
    ror   r29
    brmi  .Ltanf_reduced
    ldi   r26, 0xa2
    ldi   r20, 0xc9
    ori   r25, 0x80
    rcall  __addsf3x
    rcall  __fp_round

.Ltanf_reduced:
    ldi   r30, lo8(tanf_coefficients)
    ldi   r31, hi8(tanf_coefficients)
    rcall  __fp_powsodd
    lsl   r29
    brvs  .Ltanf_no_inverse
    rcall  __inversef

.Ltanf_no_inverse:
    lsl   r29
    brvc  .Ltanf_restore_saved_register
    subi  r25, 0x80

.Ltanf_restore_saved_register:
    pop   r29
    ret

; float modff(float A, float *iptr in r21:r20)
modff:
    movw  r30, r20
    movw  r26, r24
    lsl   r26
    rol   r27
    movw  r18, r22
    movw  r20, r24
    subi  r27, 127
    brsh  .Lmodff_has_integral_part
    clr   r18
    clr   r19
    clr   r20
    andi  r21, 0x80
    rjmp  .Lmodff_write_integral

.Lmodff_has_integral_part:
    subi  r27, 23
    brsh  .Lmodff_large_or_nonfinite
    mov   r26, r27
    clr   r0

.Lmodff_scan_fraction:
    lsr   r20
    ror   r19
    ror   r18
    adc   r0, ZERO
    inc   r26
    brmi  .Lmodff_scan_fraction
    tst   r0
    breq  .Lmodff_no_fraction

.Lmodff_restore_integral:
    lsl   r18
    rol   r19
    rol   r20
    inc   r27
    brmi  .Lmodff_restore_integral
    rcall .Lmodff_write_integral
    rjmp   __subsf3

.Lmodff_large_or_nonfinite:
    cpi   r22, 1
    cpc   r23, ZERO
    ldi   r26, 0x80
    cpc   r24, r26
    sbci  r27, 105
    brsh  .Lmodff_write_integral

.Lmodff_no_fraction:
    movw  r18, r22
    movw  r20, r24
    clr   r22
    clr   r23
    clr   r24
    andi  r25, 0x80

.Lmodff_write_integral:
    adiw  r30, 0
    breq  .Lmodff_return
    st    Z, r18
    std   Z+1, r19
    std   Z+2, r20
    std   Z+3, r21

.Lmodff_return:
    ret

; float ldexpf(float A, int exponent in r21:r20)
ldexpf:
    rcall  __fp_splitA
    brcc  .Lldexpf_finite
    rjmp   __fp_mpack

.Lldexpf_finite:
    tst   r25
    brne  .Lldexpf_add_exponent
    rjmp   __fp_mpack

.Lldexpf_add_exponent:
    add   r25, r20
    adc   r21, ZERO
    brvc  .Lldexpf_check_low_exponent
    rjmp   __fp_inf

.Lldexpf_check_low_exponent:
    subi  r25, 1
    sbci  r21, 0
    brlt  .Lldexpf_denormalize
    breq  .Lldexpf_pack

.Lldexpf_normalize:
    tst   r24
    brmi  .Lldexpf_check_overflow
    lsl   r22
    rol   r23
    rol   r24
    subi  r25, 1
    sbci  r21, 0
    brne  .Lldexpf_normalize

.Lldexpf_check_overflow:
    cpi   r25, 254
    cpc   r21, ZERO
    brlt  .Lldexpf_pack
    rjmp   __fp_inf

.Lldexpf_pack:
    lsl   r24
    adc   r25, ZERO
    lsr   r25
    ror   r24
    bld   r25, 7
    ret

.Lldexpf_denormalize:
    cpi   r21, 0xff
    brne  .Lldexpf_zero
    cpi   r25, 0xe8
    brlo  .Lldexpf_zero
    clr   r27

.Lldexpf_denormalize_loop:
    lsr   r24
    ror   r23
    ror   r22
    ror   r27
    brcc  .Lldexpf_denormalize_no_sticky
    ori   r27, 1

.Lldexpf_denormalize_no_sticky:
    inc   r25
    brne  .Lldexpf_denormalize_loop
    lsl   r27
    brcc  .Lldexpf_pack
    brne  .Lldexpf_round_up
    sbrs  r22, 0
    rjmp  .Lldexpf_pack

.Lldexpf_round_up:
    subi  r22, -1
    sbci  r23, -1
    sbci  r24, -1
    sbci  r25, -1
    rjmp  .Lldexpf_pack

.Lldexpf_zero:
    rjmp   __fp_szero

; float expf(float A)
expf:
    rcall  __fp_splitA
    brcc  .Lexpf_finite
    brne  .Lexpf_nan
    brts  .Lexpf_zero
    rjmp   __fp_inf

.Lexpf_nan:
    rjmp   __fp_nan

.Lexpf_zero:
    rjmp   __fp_zero

.Lexpf_finite:
    cpi   r25, 0x86
    brlo  .Lexpf_in_range
    brts  .Lexpf_zero
    rjmp   __fp_inf

.Lexpf_in_range:
    bld   r0, 7
    push  r0
    clt
    ldi   r18, 0x3b
    ldi   r19, 0xaa
    ldi   r20, 0xb8
    ldi   r21, 0x7f
    rcall  __mulsf3_pse
    push  r0
    push  r0
    push  r0
    in    r20, SPL
    in    r21, SPH
    push  r0
    rcall  modff
    ldi   r30, lo8(expf_coefficients)
    ldi   r31, hi8(expf_coefficients)
    rcall  __fp_powser
    pop   r20
    pop   r21
    pop   r30
    pop   r31
    asr   r30
    rol   r30
    rol   r31
    breq  .Lexpf_scale_ready
    subi  r31, 0x7e
    ori   r30, 0x80
    clr   r20

.Lexpf_extract_integer_loop:
    lsl   r30
    rol   r20
    dec   r31
    brne  .Lexpf_extract_integer_loop
    neg   r20
    sbc   r21, r21

.Lexpf_scale_ready:
    rcall  ldexpf
    pop   r0
    sbrc  r0, 7
    ret
    rjmp   __inversef

; float log2f(float A)
log2f:
    rcall  __fp_splitA
    brcc  .Llog2f_finite
    brts  .Llog2f_nan
    rjmp   __fp_mpack

.Llog2f_nan:
    rjmp   __fp_nan

.Llog2f_negative_infinity:
    set
    rjmp   __fp_inf

.Llog2f_finite:
    tst   r25
    breq  .Llog2f_negative_infinity
    brts  .Llog2f_nan
    push  r29
    push  r28
    mov   r28, r25
    clr   r29
    tst   r24
    brmi  .Llog2f_mantissa_normalized

.Llog2f_normalize_subnormal:
    sbiw  r28, 1
    lsl   r22
    rol   r23
    rol   r24
    brpl  .Llog2f_normalize_subnormal

.Llog2f_mantissa_normalized:
    ldi   r18, 0x00
    ldi   r19, 0x00
    ldi   r20, 0x80
    ldi   r21, 0xbf
    ldi   r25, 0x3f
    cpi   r24, 0xc0
    brsh  .Llog2f_high_interval
    rcall  __addsf3
    ldi   r30, lo8(log2f_low_coefficients)
    ldi   r31, hi8(log2f_low_coefficients)
    rjmp  .Llog2f_evaluate_polynomial

.Llog2f_high_interval:
    andi  r24, 0x7f
    adiw  r28, 1
    rcall  __addsf3
    ldi   r30, lo8(log2f_high_coefficients)
    ldi   r31, hi8(log2f_high_coefficients)

.Llog2f_evaluate_polynomial:
    rcall  __fp_powser
    push  r27
    push  r23
    push  r22
    movw  r22, r28
    movw  r28, r24
    subi  r22, 127
    sbci  r23, 0
    rol   r23
    sbc   r24, r24
    sbc   r25, r25
    ror   r23
    rcall  __floatsisf
    pop   r18
    pop   r19
    pop   r26
    movw  r20, r28
    pop   r28
    pop   r29
    clr   r27
    rcall  __addsf3x
    rjmp   __fp_round

; float logf(float A)
logf:
    rcall  log2f
    ldi   r18, 0x18
    ldi   r19, 0x72
    ldi   r20, 0x31
    ldi   r21, 0x3f
    rjmp   __mulsf3

; float log10f(float A)
log10f:
    rcall  log2f
    ldi   r18, 0x9b
    ldi   r19, 0x20
    ldi   r20, 0x9a
    ldi   r21, 0x3e
    rjmp   __mulsf3

; float powf(float x=A, float y=B)
powf:
    movw  r30, r20
    lsl   r30
    rol   r31
    adiw  r30, 0
    cpc   r18, ZERO
    cpc   r19, ZERO
    breq  .Lpowf_return_one
    cp    r22, ZERO
    cpc   r23, ZERO
    brne  .Lpowf_check_sign
    cpi   r24, 0x80
    ldi   r27, 0x3f
    cpc   r25, r27
    breq  .Lpowf_return
    set
    cpi   r25, 0x80
    cpc   r24, ZERO
    breq  .Lpowf_integer_exponent_check
    cpi   r24, 0x80
    ldi   r27, 0xff
    cpc   r25, r27
    breq  .Lpowf_integer_exponent_check

.Lpowf_check_sign:
    tst   r25
    brpl  .Lpowf_compute
    cpi   r31, 0xff
    cpc   r30, ZERO
    cpc   r19, ZERO
    cpc   r18, ZERO
    breq  .Lpowf_replace_infinite_exponent
    clt

.Lpowf_integer_exponent_check:
    sec
    ror   r30
    movw  r26, r18

.Lpowf_find_low_nonzero_byte:
    tst   r26
    brne  .Lpowf_find_low_nonzero_bit
    mov   r26, r27
    mov   r27, r30
    subi  r31, -8
    brcs  .Lpowf_find_low_nonzero_byte
    rjmp  .Lpowf_nonintegral_exponent

.Lpowf_find_low_nonzero_bit:
    subi  r31, -1
    brcc  .Lpowf_nonintegral_exponent
    lsr   r26
    brcc  .Lpowf_find_low_nonzero_bit
    cpi   r31, 0x97
    brlo  .Lpowf_nonintegral_exponent
    breq  .Lpowf_odd_integer_exponent
    cpi   r31, 0xaf
    brsh  .Lpowf_nonintegral_exponent
    andi  r25, 0x7f

.Lpowf_odd_integer_exponent:
    push  r25
    rcall .Lpowf_compute
    pop   r0
    sbrc  r0, 7
    subi  r25, 0x80

.Lpowf_return:
    ret

.Lpowf_nonintegral_exponent:
    brts  .Lpowf_compute
    rjmp   __fp_nan

.Lpowf_return_one:
    ldi   r22, 0x00
    ldi   r23, 0x00
    ldi   r24, 0x80
    ldi   r25, 0x3f
    ret

.Lpowf_replace_infinite_exponent:
    ldi   r20, 0x7f

.Lpowf_compute:
    andi  r25, 0x7f
    push  r21
    push  r20
    push  r19
    push  r18
    rcall  logf
    pop   r18
    pop   r19
    pop   r20
    pop   r21
    rcall  __mulsf3
    rjmp   expf

; float hypotf(float A, float B)
hypotf:
    andi  r25, 0x7f
    andi  r21, 0x7f
    rcall  __fp_split3
    brcc  .Lhypotf_finite
    rjmp  .Lhypotf_nonfinite

.Lhypotf_finite:
    tst   r25
    brne  .Lhypotf_a_nonzero
    rjmp  .Lhypotf_return_b
.Lhypotf_a_nonzero:
    tst   r21
    brne  .Lhypotf_b_nonzero
    rjmp  .Lhypotf_return_a
.Lhypotf_b_nonzero:
    clr   r31
    cp    r25, r21
    brsh  .Lhypotf_a_exponent_larger
    mov   r30, r21
    sub   r30, r25
    cpi   r30, 13
    brlo  .Lhypotf_a_relevant
    rjmp  .Lhypotf_return_b
.Lhypotf_a_relevant:
    cpi   r21, 190
    brlo  .Lhypotf_a_small_check
    ldi   r31, 65
    rjmp  .Lhypotf_scale

.Lhypotf_a_small_check:
    cpi   r25, 64
    brsh  .Lhypotf_scale_ready
    rjmp  .Lhypotf_normalize_subnormals

.Lhypotf_a_exponent_larger:
    mov   r30, r25
    sub   r30, r21
    cpi   r30, 13
    brlo  .Lhypotf_b_relevant
    rjmp  .Lhypotf_return_a
.Lhypotf_b_relevant:
    cpi   r25, 190
    brlo  .Lhypotf_b_small_check
    ldi   r31, 65
    rjmp  .Lhypotf_scale

.Lhypotf_b_small_check:
    cpi   r21, 64
    brsh  .Lhypotf_scale_ready

.Lhypotf_normalize_subnormals:
    ldi   r31, 0xa9
    tst   r24
    brmi  .Lhypotf_normalize_b

.Lhypotf_normalize_a:
    dec   r25
    lsl   r22
    rol   r23
    rol   r24
    brpl  .Lhypotf_normalize_a

.Lhypotf_normalize_b:
    tst   r20
    brmi  .Lhypotf_scale

.Lhypotf_normalize_b_loop:
    dec   r21
    lsl   r18
    rol   r19
    rol   r20
    brpl  .Lhypotf_normalize_b_loop

.Lhypotf_scale:
    sub   r25, r31
    sub   r21, r31

.Lhypotf_scale_ready:
    push  r31
    push  r17
    push  r16
    push  r15
    push  r14
    movw  r14, r18
    movw  r16, r20
    clr   r27
    mov   r26, r27
    movw  r18, r22
    movw  r20, r24
    rcall  __mulsf3_pse
    movw  r18, r14
    movw  r20, r16
    push  r27
    movw  r14, r22
    movw  r16, r24
    clr   r26
    mov   r27, r26
    movw  r22, r18
    movw  r24, r20
    rcall  __mulsf3_pse
    pop   r26
    movw  r18, r14
    movw  r20, r16
    pop   r14
    pop   r15
    pop   r16
    pop   r17
    rcall  __addsf3x
    rcall  __fp_round
    rcall  sqrtf
    pop   r20
    sbrs  r20, 0
    ret
    clr   r21
    sbrc  r20, 7
    com   r21
    rjmp   ldexpf

.Lhypotf_return_b:
    movw  r22, r18
    movw  r24, r20

.Lhypotf_return_a:
    rjmp   __fp_mpack

.Lhypotf_nonfinite:
    rcall  __fp_pscA
    breq  .Lhypotf_infinity
    rcall  __fp_pscB
    breq  .Lhypotf_infinity
    rjmp   __fp_nan

.Lhypotf_infinity:
    rjmp   __fp_inf

; float fmodf(float A, float B)
fmodf:
    mov   r30, r25
    rcall  __fp_split3
    brcc  .Lfmodf_finite
    rjmp  .Lfmodf_nonfinite

.Lfmodf_finite:
    tst   r21
    brne  .Lfmodf_compare_magnitudes
    rjmp  .Lfmodf_nan

.Lfmodf_compare_magnitudes:
    bst   r30, 7
    cp    r22, r18
    cpc   r23, r19
    cpc   r24, r20
    cpc   r25, r21
    brlo  .Lfmodf_pack
    brne  .Lfmodf_magnitudes_differ
    rjmp  .Lfmodf_signed_zero
.Lfmodf_magnitudes_differ:
    mov   r30, r25
    clr   r31
    tst   r24
    brmi  .Lfmodf_a_normalized

.Lfmodf_normalize_a:
    sbiw  r30, 1
    lsl   r22
    rol   r23
    rol   r24
    brpl  .Lfmodf_normalize_a

.Lfmodf_a_normalized:
    mov   r25, r21
    clr   r21
    tst   r20
    brmi  .Lfmodf_b_normalized

.Lfmodf_normalize_b:
    subi  r25, 1
    sbci  r21, 0
    lsl   r18
    rol   r19
    rol   r20
    brpl  .Lfmodf_normalize_b

.Lfmodf_b_normalized:
    clr   r27
    sub   r30, r25
    sbc   r31, r21

.Lfmodf_remainder_loop:
    sub   r22, r18
    sbc   r23, r19
    sbc   r24, r20
    sbc   r27, ZERO
    breq  .Lfmodf_signed_zero
    brpl  .Lfmodf_subtraction_kept
    add   r22, r18
    adc   r23, r19
    adc   r24, r20
    adc   r27, ZERO

.Lfmodf_subtraction_kept:
    sbiw  r30, 1
    brmi  .Lfmodf_prepare_pack
    lsl   r22
    rol   r23
    rol   r24
    rol   r27
    rjmp  .Lfmodf_remainder_loop

.Lfmodf_prepare_pack:
    subi  r25, 1
    sbci  r21, 0
    brmi  .Lfmodf_denormalize
    breq  .Lfmodf_pack_normal

.Lfmodf_renormalize:
    tst   r24
    brmi  .Lfmodf_pack_normal
    lsl   r22
    rol   r23
    rol   r24
    subi  r25, 1
    sbci  r21, 0
    brne  .Lfmodf_renormalize

.Lfmodf_pack_normal:
    inc   r25

.Lfmodf_pack:
    rjmp   __fp_mpack

.Lfmodf_denormalize:
    lsr   r24
    ror   r23
    ror   r22
    subi  r25, -1
    brne  .Lfmodf_denormalize
    rjmp  .Lfmodf_pack_normal

.Lfmodf_nonfinite:
    rcall  __fp_pscA
    brcs  .Lfmodf_nan
    breq  .Lfmodf_nan
    rcall  __fp_pscB
    brcs  .Lfmodf_nan
    rjmp  .Lfmodf_compare_magnitudes

.Lfmodf_nan:
    rjmp   __fp_nan

.Lfmodf_signed_zero:
    rjmp   __fp_szero

; Polynomial coefficient tables. The first byte is the degree; the next four
; bytes are the leading binary32 coefficient; remaining entries are five-byte
; extended coefficients.
; Keep atan coefficients in the libm region. Its current rounding path also
; observes the table pointer's high byte; relocating it into page zero would
; change tie rounding. Sine/tangent finish through a fresh multiplication.
atanf_coefficients:
    .byte 8
    .byte 0x4a,0xd7,0x3b,0x3b
    .byte 0xce,0x01,0x6e,0x84,0xbc
    .byte 0xbf,0xfd,0xc1,0x2f,0x3d
    .byte 0x6c,0x74,0x31,0x9a,0xbd
    .byte 0x56,0x83,0x3d,0xda,0x3d
    .byte 0x00,0xc7,0x7f,0x11,0xbe
    .byte 0xd9,0xe4,0xbb,0x4c,0x3e
    .byte 0x91,0x6b,0xaa,0xaa,0xbe
    .byte 0x00,0x00,0x00,0x80,0x3f

expf_coefficients:
    .byte 7
    .byte 0x63,0x42,0x36,0xb7
    .byte 0x9b,0xd8,0xa7,0x1a,0x39
    .byte 0x68,0x56,0x18,0xae,0xba
    .byte 0xab,0x55,0x8c,0x1d,0x3c
    .byte 0xb7,0xcc,0x57,0x63,0xbd
    .byte 0x6d,0xed,0xfd,0x75,0x3e
    .byte 0xf6,0x17,0x72,0x31,0xbf
    .byte 0x00,0x00,0x00,0x80,0x3f

log2f_low_coefficients:
    .byte 8
    .byte 0x9c,0x1a,0x22,0xbd
    .byte 0xa0,0x92,0x20,0x00,0x3e
    .byte 0xbe,0xcc,0xd5,0x58,0xbe
    .byte 0x94,0xde,0xa0,0x90,0x3e
    .byte 0xa0,0xa5,0x4b,0xb8,0xbe
    .byte 0x20,0xa9,0x32,0xf6,0x3e
    .byte 0x80,0x2a,0xaa,0x38,0xbf
    .byte 0x22,0x3b,0xaa,0xb8,0x3f
    .byte 0x00,0x00,0x00,0x00,0x00

log2f_high_coefficients:
    .byte 8
    .byte 0x3c,0x5b,0xf7,0xbe
    .byte 0xda,0xd7,0xaa,0x71,0x3d
    .byte 0x8c,0x77,0x86,0x8c,0xbe
    .byte 0x2e,0xee,0x93,0x91,0x3e
    .byte 0x7a,0x9f,0xce,0xb8,0xbe
    .byte 0x10,0x24,0x37,0xf6,0x3e
    .byte 0xfa,0x3c,0xaa,0x38,0xbf
    .byte 0x28,0x3b,0xaa,0xb8,0x3f
    .byte 0x00,0x00,0x00,0x00,0x00

.p2align 1

avrlibm_embedded_end:

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; SYS memory services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; These handlers preserve all architectural input registers and VM_FLAGS.
; r4 therefore remains the destination pointer and the returned void*. Native
; scratch registers and native SREG are not architectural state.

; void *memmove(void *dst, void const *src, uint16_t n)
;   r4 = dst/result, r5 = src, r6 = n
; Copy backward exactly when dst > src and unsigned(dst - src) < n.
; The forward cases enter memcpy's shared forward-copy loop below.
sys_memmove_impl:
    movw  r30, VM_R4             ; Z = destination
    movw  r26, VM_R5             ; X = source
    movw  r24, VM_R6             ; r25:r24 = remaining count

    mov   r0, r24
    or    r0, r25
    breq  .Lsys_memcpy_done

    cp    r30, r26
    cpc   r31, r27
    breq  .Lsys_memcpy_done
    brlo  .Lsys_memcpy_loop

    movw  r0, r30                ; distance = dst - src
    sub   r0, r26
    sbc   r1, r27
    cp    r0, r24
    cpc   r1, r25
    brsh  .Lsys_memcpy_loop

    add   r26, r24               ; X = src + n
    adc   r27, r25
    add   r30, r24               ; Z = dst + n
    adc   r31, r25
    ; Copy pairs from the end; native T retains the odd-byte remainder.
    bst   r24, 0
    lsr   r25
    ror   r24
    sbiw  r24, 0
    breq  .Lsys_memmove_backward_remainder
.Lsys_memmove_backward_pairs:
    ld    r0, -X
    st    -Z, r0
    ld    r0, -X
    st    -Z, r0
    sbiw  r24, 1
    brne  .Lsys_memmove_backward_pairs
.Lsys_memmove_backward_remainder:
    brtc  .Lsys_memcpy_done
    ld    r0, -X
    st    -Z, r0
    rjmp  .Lsys_memcpy_done

; void *memcpy(void *dst, void const *src, uint16_t n)
;   r4 = dst/result, r5 = src, r6 = n
sys_memcpy_impl:
    movw  r30, VM_R4             ; Z = destination
    movw  r26, VM_R5             ; X = source
    movw  r24, VM_R6             ; r25:r24 = remaining count
    mov   r1, r24
    or    r1, r25
    breq  .Lsys_memcpy_done
.Lsys_memcpy_loop:
    ; Native T retains the low count bit while r24:r25 counts byte pairs.
    bst   r24, 0
    lsr   r25
    ror   r24
    sbiw  r24, 0
    breq  .Lsys_memcpy_remainder
.Lsys_memcpy_pairs:
    ld    r0, X+
    st    Z+, r0
    ld    r0, X+
    st    Z+, r0
    sbiw  r24, 1
    brne  .Lsys_memcpy_pairs
.Lsys_memcpy_remainder:
    brtc  .Lsys_memcpy_done
    ld    r0, X+
    st    Z+, r0
.Lsys_memcpy_done:
    jmp   cluster_tail_18

; void *memcpy_P(void *dst, progptr/uint24_t src, uint16_t n)
;   r4 = dst/result, q3[23:0] = src, r5 = n
;   q3[31:24] is ignored and preserved. This three-cycle landing retains the
;   previous successful-path timing; the skipped NOPs retain the four-word
;   layout so no later range-constrained code moves.
sys_memcpy_p_impl:
    rjmp  .Lsys_memcpy_p_padding_done
    nop
    nop
.Lsys_memcpy_p_padding_done:
    nop
    movw  r0, VM_R5              ; shared reader count
    mov   r27, r0
    or    r27, r1
    breq  .Lsys_memcpy_p_done

    add   VM_PCL, ONE            ; service byte -> following primary opcode
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    movw  r30, VM_R4             ; shared reader destination
    movw  r24, VM_R6             ; source bits 15:0
    mov   r26, VM_R7L            ; source bits 23:16
    call  fx_read_program_bytes_func
    jmp   seek_and_dispatch_func
.Lsys_memcpy_p_done:
    jmp   cluster_tail_18

; void *memset(void *dst, int16_t val, uint16_t n)
;   r4 = dst/result, r5 = val, r6 = n
sys_memset_impl:
    movw  r30, VM_R4             ; Z = destination
    movw  r24, VM_R6             ; r25:r24 = remaining count
    mov   r0, VM_R5L             ; low8(val), as required by C memset
    mov   r1, r24
    or    r1, r25
    breq  .Lsys_memset_done
.Lsys_memset_loop:
    ; Handle two bytes per count update, then the optional odd byte.
    bst   r24, 0
    lsr   r25
    ror   r24
    sbiw  r24, 0
    breq  .Lsys_memset_remainder
.Lsys_memset_pairs:
    st    Z+, r0
    st    Z+, r0
    sbiw  r24, 1
    brne  .Lsys_memset_pairs
.Lsys_memset_remainder:
    brtc  .Lsys_memset_done
    st    Z+, r0
.Lsys_memset_done:
    jmp   cluster_tail_18

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; SYS FX sprite drawing services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Explicit-pointer draw_sprite_* SYS ABI:
;   r4 = int16_t x
;   r5 = int16_t y
;   q1 = image-relative program pointer to { width, height, frame bytes... }
;   r6 = uint16_t frame index
;
; SET_SPRITE ABI:
;   q2 = image-relative program pointer to { width, height, frame bytes... }
;
; Cached-pointer draw_* SYS ABI:
;   r4 = int16_t x
;   r5 = int16_t y
;   r6 = uint16_t frame index
;
; SET_SPRITE stores the raw q2 pointer and its two-byte header in
; interpreter-private SRAM. The cached-pointer draw services reuse that state.
; No sprite is selected at startup; cached draws are then no-ops because the
; cached width is initialized to zero. Explicit-pointer draws do not alter the
; selected sprite.
;
; The frame data is page-major. OVERWRITE, SELF_MASKED, and ERASE use one
; source byte per column. PLUS_MASK uses interleaved image,mask byte pairs.
; The frame stride is width * ceil(height/8), doubled for PLUS_MASK. For a
; height not divisible by eight, OVERWRITE masks the final source page in the
; renderer. The other modes require unused high bits in that page to be zero
; (both image and mask bytes for PLUS_MASK).
;
; The header wrapper consumes the speculative bytecode transfer, reads the
; two-byte header, calculates the selected-frame pointer, and enters the raw
; renderer through the documented native ABI below. Architectural registers
; and VM_FLAGS are preserved. The raw renderer returns to its caller; the SYS
; wrapper alone restarts the bytecode stream.

sys_set_sprite_impl:
    ; The sprite transaction replaces the speculative bytecode transfer. Make
    ; VM_PC name the primary opcode following this SYS service before doing so.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; Cache the raw q2 program pointer. Z then naturally points at the width
    ; and height fields, which the shared fixed-count reader fills directly.
    ldi   r30, lo8(data_sprite_ptr)
    ldi   r31, hi8(data_sprite_ptr)
    movw  r24, VM_R4
    adiw  r24, 2
    st    Z+, r24
    st    Z+, r25
    mov   r24, VM_R5L
    adc   r24, ZERO
    st    Z+, r24

    movw  r24, VM_R4
    mov   r26, VM_R5L
    mov   r0, ONE
    lsl   r0                         ; two-byte width/height header
    mov   r1, ZERO
    call  fx_read_program_bytes_func
    jmp   seek_and_dispatch_func_disabled

sys_draw_cached_impl:
    out   GPIOR1, r27                ; retain mode across cached setup/MULs

    ; The renderer takes ownership of SPI. Advance from the service byte to the
    ; following primary opcode before terminating the speculative transaction.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; Recreate the state produced by the explicit header-read path: raw pointer
    ; plus two, width in r0/GPIOR2, height in r1, mode in GPIOR1, and FX idle.
    lds   r24, data_sprite_ptr+0
    lds   r25, data_sprite_ptr+1
    lds   r26, data_sprite_ptr+2
    lds   r0,  data_sprite_ptr+3
    lds   r1,  data_sprite_ptr+4
    out   GPIOR2, r0
    fx_disable
    rjmp  .Lsys_sprite_header_ready

sys_draw_sprite_header_impl:
    out   GPIOR1, r27              ; retain mode across header read/MULs

    ; The instruction stream must be restarted after the sprite has owned SPI.
    ; Advance VM_PC from the service byte to the following primary opcode now.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    movw  r24, VM_R2
    mov   r26, VM_R3L

    fx_disable

    ; Read width and height at q1. The shared address-phase helper is suitable
    ; for this fixed two-byte header read; the selected-frame seek below is a
    ; separate sprite-specific transaction whose command interval contains the
    ; clipping and render preparation.
    call  fx_start_program_read_func

    ; The helper returns five cycles after launching the width transfer. Twelve
    ; more cycles put the standard IN/OUT handoff at cycles 17/18.
    rcall sprite_delay_12
    in    r0, SPDR                  ; width
    out   SPDR, ZERO                ; begin height transfer

    ; Establish the unframed data pointer while height is in flight.
    movw  r24, VM_R2
    mov   r26, VM_R3L
    adiw  r24, 2
    adc   r26, ZERO
    out   GPIOR2, r0                ; retain width across MULs

    rcall sprite_delay_10

    in    r1, SPDR                  ; height
    fx_disable

.Lsys_sprite_header_ready:
    ; Preserve height while r0:r1 are used by the four partial products.
    push  r1

    ; pages = ceil(height / 8); stride = width * pages.
    in    r30, GPIOR2
    mov   r31, r1
    dec   r31
    lsr   r31
    lsr   r31
    lsr   r31
    inc   r31
    mul   r30, r31
    movw  r30, r0

    in    r27, GPIOR1
    cpi   r27, SPRITE_MODE_PLUS_MASK
    brne  .Lsys_sprite_stride_ready
    lsl   r30
    rol   r31
.Lsys_sprite_stride_ready:

    ; Add low24(frame * stride) to sprite+2. Frame zero is overwhelmingly
    ; common and skips all partial products. Frames below 256 skip the two
    ; high-frame-byte products. q1[31:24] is ignored.
    mov   r27, VM_R6L
    or    r27, VM_R6H
    breq  .Lsys_sprite_frame_offset_done

    mul   VM_R6L, r30
    add   r24, r0
    adc   r25, r1
    adc   r26, ZERO

    mul   VM_R6L, r31
    add   r25, r0
    adc   r26, r1

    tst   VM_R6H
    breq  .Lsys_sprite_frame_offset_done

    mul   VM_R6H, r30
    add   r25, r0
    adc   r26, r1

    mul   VM_R6H, r31
    add   r26, r0

.Lsys_sprite_frame_offset_done:
    pop   r1                         ; native raw-renderer height
    in    r0, GPIOR2                 ; native raw-renderer width
    in    r27, GPIOR1                ; native raw-renderer mode
    rcall draw_bitmap_seek_func
    jmp   seek_and_dispatch_func_disabled


; Reusable raw page-bitmap renderer ABI.
;
; Entry:
;   r0              width in pixels
;   r1              height in pixels
;   r24:r25:r26     selected frame's image-relative data pointer; generic
;                     setup converts it once to the shared physical-pointer contract
;   r27             SPRITE_MODE_*
;   AVM r4          int16_t x
;   AVM r5          int16_t y
;   FX deselected; no SPI transfer active
;
; Return:
;   RET with FX deselected and no SPI transfer active. The caller owns any
;   bytecode-stream restart. This makes the routine suitable for repeated calls
;   from a larger SYS service such as a text renderer.
;
; Data layout and semantics match the four sprite SYS services. This entry is
; deliberately exported so future text/glyph SYS services can prepare their
; own width, height, and bitmap pointer, then reuse clipping and rendering.
;
; Preservation contracts:
;   draw_bitmap_seek_func / draw_bitmap_seek_nonempty_func push and restore
;   all native r8-r23 (the complete AVM register file).
;   draw_bitmap_seek_nonempty_text_func is an internal text-only contract: the
;   caller has already preserved architectural state for the whole text SYS, so
;   the renderer may clobber r8-r23 and skips the per-glyph register frame.
;   VM_PC, VM_FLAGS, VM_SP, and the permanent constants are untouched. Native
;   r0:r1, r24:r27, r30:r31, GPIOR1:GPIOR2, and SREG are call-clobbered.
;
; Persistent working allocation after the optional pushes:
;   r8              source width during setup; overwrite row-valid mask
;   r9              source height during setup; overwrite low preserve mask
;   r10:r11         full source-row stride in bytes
;   r12             visible source rows remaining
;   r13             drawing mode during setup; loop counter while rendering
;   r14             framebuffer row advance (128-visibleColumns)
;   r15             overwrite final-source-page valid-bit mask
;   r16             visible column count
;   r17             preserved call-lifetime text status; unused by renderer
;   r18             vertical shift coefficient
;   r19             signed destination page during setup; high mask/temporary
;   r20:r21:r22     current visible source-row physical FX pointer
;   r23             top/bottom/reseek/surviving-partial flags
;   SREG.T          0=renderer preserves r8-r23, 1=text caller preserves them
;   GPIOR1:GPIOR2   selected mode-specific row-dispatch word address
;   X               current framebuffer page pointer
;   Z               adjacent framebuffer page pointer or dispatch target
;   r24:r25,r0:r1   stream and framebuffer temporaries
;
.Lsprite_raw_reject:
    ret
.global draw_bitmap_seek_func
draw_bitmap_seek_func:
    ; Reject invisible or empty bitmaps before touching architectural state or
    ; opening the sprite transaction.
    tst   r0
    breq  .Lsprite_raw_reject
    tst   r1
    breq  .Lsprite_raw_reject

; Internal preserved entry for callers that already proved r0 != 0 and r1 != 0.
draw_bitmap_seek_nonempty_func:
    clt                              ; generic renderer owns preservation

.Lsprite_raw_check_visible:
    cpi   VM_R4L, 128
    cpc   VM_R4H, ZERO
    brge  .Lsprite_raw_reject
    cpi   VM_R5L, 64
    cpc   VM_R5H, ZERO
    brge  .Lsprite_raw_reject

    movw  r30, VM_R4
    add   r30, r0
    adc   r31, ZERO
    cp    ZERO, r30
    cpc   ZERO, r31
    brge  .Lsprite_raw_reject

    movw  r30, VM_R5
    add   r30, r1
    adc   r31, ZERO
    cp    ZERO, r30
    cpc   ZERO, r31
    brge  .Lsprite_raw_reject

; Internal renderer entry for text callers that have already proved nonempty
; dimensions and complete screen intersection. The caller must set SREG.T to
; select the no-preservation contract before entering.
draw_bitmap_seek_visible_text_func:
.Lsprite_raw_visible:
    ; Start the selected-frame command before preserving architectural inputs.
    ; The sixteen pushes and the clipping work occupy the command-transfer
    ; interval. Because the exact cycle-17 boundary is intentionally missed,
    ; the eventual address-high handoff drains SPDR before transmitting.
    fx_disable
    ldi   r30, SFC_READ
    fx_enable
    out   SPDR, r30

    brts  .Lsprite_raw_registers_ready
    push  r8
    push  r9
    push  r10
    push  r11
    push  r12
    push  r13
    push  r14
    push  r15
    push  r16
    push  r17
    push  r18
    push  r19
    push  r20
    push  r21
    push  r22
    push  r23

.Lsprite_raw_registers_ready:
    mov   r8, r0                    ; source width, later current row mask
    mov   r9, r1                    ; source height, later overwrite low mask
    movw  r20, r24
    mov   r22, r26                  ; selected frame image-relative pointer

    ; Establish the shared renderer pointer contract immediately: r20:r22 is
    ; physical from this point onward for both generic sprites and prepared
    ; text. Top/left clipping and later row-stride advances therefore operate
    ; identically, and clipped-row reseeks never translate the pointer again.
    lds   r24, data_page_data+0
    add   r21, r24
    lds   r24, data_page_data+1
    adc   r22, r24

    mov   r13, r27                  ; drawing mode (setup only)

    ; Full source-row stride in bytes.
    mov   r10, r8
    clr   r11
    mov   r24, r13
    cpi   r24, SPRITE_MODE_PLUS_MASK
    brne  .Lsprite_stride_ready
    lsl   r10
    rol   r11
.Lsprite_stride_ready:

    ; Compute pages = ceil(height/8) for every mode. Only OVERWRITE needs a
    ; valid-bit mask for the final source page; PLUS_MASK, SELF_MASKED, and
    ; ERASE require unused high bits in their source data to be zero.
    ; r23 retains top, bottom, horizontal-reseek, and overwrite-partial flags.
    ; Native SREG.T remains solely the renderer preservation contract.
    clr   r23
    mov   r25, r9
    lsr   r25
    lsr   r25
    lsr   r25
    mov   r24, r9
    andi  r24, 0x07                 ; height remainder
    breq  .Lsprite_height_aligned

    inc   r25
    tst   r13                       ; only mode 0 (OVERWRITE) masks padding
    brne  .Lsprite_nonoverwrite_unaligned
    ori   r23, (1 << SPRITE_FLAG_PARTIAL)

    ; Fixed-time mask = (1 << remainder) - 1. Each SBRC and its one-word
    ; instruction consume two cycles whether the instruction executes or is
    ; skipped, so remainders 1-7 all take the same eight cycles.
    ldi   r30, 1
    sbrc  r24, 1
    ldi   r30, 4
    sbrc  r24, 0
    lsl   r30
    sbrc  r24, 2
    swap  r30
    dec   r30
    rjmp  .Lsprite_final_mask_ready

.Lsprite_nonoverwrite_unaligned:
.Lsprite_height_aligned:
    ldi   r30, 0xFF
.Lsprite_final_mask_ready:
    mov   r15, r30                  ; overwrite final-page valid-bit mask
    mov   r12, r25                  ; total source pages

    ; pageStart = arithmetic y / 8. Visibility checks constrain y to the range
    ; in which the compact low-byte continuation is exact.
    mov   r24, VM_R5L
    asr   VM_R5H
    ror   r24
    asr   r24
    asr   r24

    ; Skip complete source pages above the display. With a nonzero bit shift,
    ; pageStart == -1 remains visible through its high contribution; aligned
    ; sprites skip that otherwise-empty row as well.
    mov   r25, VM_R5L
    andi  r25, 0x07
    breq  .Lsprite_top_clip_aligned

    cpi   r24, 0xFF
    brge  .Lsprite_top_clip_done
    mov   r25, r24
    com   r25                       ; skip = -pageStart - 1
    rjmp  .Lsprite_apply_top_skip

.Lsprite_top_clip_aligned:
    tst   r24
    brpl  .Lsprite_top_clip_done
    mov   r25, r24
    neg   r25                       ; skip = -pageStart

.Lsprite_apply_top_skip:
    ; source += skip * rowStride; pages -= skip; pageStart += skip.
    movw  r30, r10
    mul   r25, r30
    add   r20, r0
    adc   r21, r1
    adc   r22, ZERO
    mul   r25, r31
    add   r21, r0
    adc   r22, r1
    sub   r12, r25
    add   r24, r25

.Lsprite_top_clip_done:
    mov   r19, r24                  ; clipped signed destination page index

    ; Horizontal clipping. r16 becomes visible columns and r31 start X.
    ; r17 remains untouched so prepared text retains call-lifetime status.
    mov   r25, VM_R4L
    sbrs  VM_R4H, 7
    rjmp  .Lsprite_x_nonnegative

    neg   r25                       ; leftSkip = -x, guaranteed < width
    mov   r16, r8
    sub   r16, r25

    ; source += leftSkip * bytesPerColumn.
    mov   r30, r25
    clr   r31
    mov   r24, r13
    cpi   r24, SPRITE_MODE_PLUS_MASK
    brne  .Lsprite_left_skip_ready
    lsl   r30
    rol   r31
.Lsprite_left_skip_ready:
    add   r20, r30
    adc   r21, r31
    adc   r22, ZERO
    clr   r31                       ; framebuffer x = 0
    rjmp  .Lsprite_clip_right

.Lsprite_x_nonnegative:
    mov   r31, r25                  ; framebuffer x
    mov   r16, r8

.Lsprite_clip_right:
    ldi   r24, 128
    sub   r24, r31                  ; columns available on screen
    cp    r24, r16
    brsh  .Lsprite_right_clip_done
    mov   r16, r24
.Lsprite_right_clip_done:

    cpi   r19, 0xFF
    brne  .Lsprite_not_top_row
    ori   r23, (1 << SPRITE_FLAG_TOP)
.Lsprite_not_top_row:

    ; r20:r22 already holds the finalized physical visible-row pointer.
    ; The command transfer has long since completed, so use the legal late
    ; standard handoff: drain the command response, then transmit address high.
    out   SPDR, r22                  ; physical address high

    ; Preserve y low while r18 is reused as the unsigned 128 operand for the
    ; signed page-index multiply below.
    mov   r9, VM_R5L

    ; Compute X = framebuffer + pageStart*128 + x with signed MULSU. A top
    ; source row therefore begins one page before the framebuffer and is moved
    ; forward by 128 in the common row dispatcher before its high contribution.
    ldi   r18, 128
    mulsu r19, r18
    ldi   r26, lo8(data_display)
    ldi   r27, hi8(data_display)
    add   r26, r0
    adc   r27, r1
    add   r26, r31
    adc   r27, ZERO

    ; Clip source rows against the bottom. If the original final source page is
    ; removed, its partial-page mask is no longer relevant.
    ldi   r24, 8
    sub   r24, r19                  ; maximum visible source rows
    cp    r24, r12
    brsh  .Lsprite_bottom_count_ready
    mov   r12, r24
    andi  r23, 0xF7                 ; clear SPRITE_FLAG_PARTIAL
.Lsprite_bottom_count_ready:

    mov   r24, r19
    add   r24, r12

    out   SPDR, r21                  ; physical address middle

    cpi   r24, 8
    brne  .Lsprite_not_bottom_row
    ori   r23, (1 << SPRITE_FLAG_BOTTOM)
.Lsprite_not_bottom_row:

    ; The retained source pointer is needed only when horizontal clipping means
    ; the visible bytes do not end at the next source row. Keep that condition
    ; in the spare renderer metadata bit so native T remains the preservation
    ; contract through every arithmetic instruction and protected SPI handoff.
    cpse  r16, r8
    ori   r23, (1 << SPRITE_FLAG_RESEEK)

    ldi   r24, 128
    sub   r24, r16
    mov   r14, r24                  ; framebuffer row advance

    ; Fixed-time coefficient construction overlaps the middle-address byte.
    mov   r24, r9
    ldi   r18, 1
    sbrc  r24, 1
    ldi   r18, 4
    sbrc  r24, 0
    lsl   r18
    sbrc  r24, 2
    swap  r18                        ; r18 = 1 << (y & 7)

    nop                              ; address data requires an 18-cycle gap
    out   SPDR, r20                  ; physical address low

    ; Select one mode-specific row dispatcher once. GPIOR1:GPIOR2 are free
    ; after address-low is launched and retain its AVR word address for every
    ; source row. Invalid raw-entry modes retain the historical erase fallback.
    mov   r24, r13
    tst   r24
    brne  .Lsprite_select_not_overwrite

    ldi   r30, lo8(pm(sprite_overwrite_row_dispatch))
    ldi   r31, hi8(pm(sprite_overwrite_row_dispatch))
    ; Precompute overwrite preservation masks for every full source row:
    ;   r9  = preserve bits below the shifted source contribution
    ;   r19 = preserve bits above the shifted source contribution
    ; Other modes reuse these registers as rendering temporaries.
    ldi   r24, 0xFF
    mul   r24, r18
    com   r0
    com   r1
    mov   r9, r0
    mov   r19, r1
    rjmp  .Lsprite_store_mode_dispatch

.Lsprite_select_not_overwrite:
    cpi   r24, SPRITE_MODE_PLUS_MASK
    breq  .Lsprite_select_plus_dispatch
    cpi   r24, SPRITE_MODE_SELF_MASKED
    breq  .Lsprite_select_self_dispatch
    ldi   r30, lo8(pm(sprite_erase_row_dispatch))
    ldi   r31, hi8(pm(sprite_erase_row_dispatch))
    delay_2
    rjmp  .Lsprite_store_mode_dispatch
.Lsprite_select_plus_dispatch:
    ldi   r30, lo8(pm(sprite_plus_row_dispatch))
    ldi   r31, hi8(pm(sprite_plus_row_dispatch))
    delay_2
    delay_2
    rjmp  .Lsprite_store_mode_dispatch
.Lsprite_select_self_dispatch:
    ldi   r30, lo8(pm(sprite_self_row_dispatch))
    ldi   r31, hi8(pm(sprite_self_row_dispatch))
    delay_3
.Lsprite_store_mode_dispatch:
    out   GPIOR1, r30
    out   GPIOR2, r31

    ; The setup above occupies the address-low transfer window. Start the first
    ; data-byte transfer with a legal late standard handoff.
    out   SPDR, ZERO
    rjmp  .Lsprite_row_dispatch

; Prepared text-only renderer entry. The glyph reader has already launched the
; image command and reaches this label five cycles later. It also supplies the
; complete clipping/setup state below while the enclosing text call keeps T set:
;   r8          source width
;   r10:r11     source row stride (r11 is zero)
;   r12         source pages remaining after top clipping
;   r13         text drawing mode; dead after first-row dispatch selection
;   r14         framebuffer row advance
;   r15         original final-page height remainder, or zero after bottom clip
;   r16         visible columns
;   r17         call-lifetime text/formatter status, preserved
;   r18         1 << (renderedY & 7)
;   r19         clipped signed destination page
;   r20:r22     complete physical image pointer after top/left clipping
;   r23         TOP and RESEEK flags; reject bit clear
;   r31         framebuffer x during this final setup only
;
; Bottom clipping occupies the rest of the command interval. Address high,
; middle, low, and the first dummy then use exact 18/18/18/17-cycle cadence.
draw_bitmap_seek_prepared_text_func:
    ldi   r24, 8
    sub   r24, r19                  ; maximum visible source rows
    cp    r24, r12
    brsh  .Ltext_prepared_bottom_unclipped
    mov   r12, r24
    clr   r15                       ; original partial final page was removed
.Ltext_prepared_bottom_unclipped:

    ; Complete computation of physical image address.

    add   r20, r11
    adc   r21, r25
    adc   r22, ZERO
    clr   r11                       ; restore 16-bit row stride high byte
    
    add   r20, r27
    adc   r21, ZERO
    adc   r22, ZERO

    out   SPDR, r22                 ; physical address high, command +18

    ; X = framebuffer + pageStart*128 + x. Preserve the vertical shift in r9
    ; while MULSU uses r18 as the signed-page multiplier. r31 is dead afterward.
    mov   r9, r18
    ldi   r24, 128
    mov   r18, r24
    mulsu r19, r18
    mov   r18, r9
    ldi   r26, lo8(data_display)
    ldi   r27, hi8(data_display)
    add   r26, r0
    adc   r27, r1
    add   r26, r31
    adc   r27, ZERO

    mov   r24, r19
    add   r24, r12
    cpi   r24, 8
    brne  .Ltext_prepared_not_bottom
    ori   r23, (1 << SPRITE_FLAG_BOTTOM)
.Ltext_prepared_not_bottom:
    out   SPDR, r21                 ; physical address middle, +18

    ; OVERWRITE alone consumes r15. For a retained partial final page, construct
    ; (1 << remainder) - 1 in fixed time and set PARTIAL.
    tst   r13
    brne  .Ltext_prepared_nonoverwrite_mask
    tst   r15
    breq  .Ltext_prepared_aligned_overwrite_mask

    mov   r24, r15
    ldi   r25, 1
    sbrc  r24, 1
    ldi   r25, 4
    sbrc  r24, 0
    lsl   r25
    sbrc  r24, 2
    swap  r25
    dec   r25
    mov   r15, r25
    ori   r23, (1 << SPRITE_FLAG_PARTIAL)
    delay_2
    out   SPDR, r20                 ; physical address low, +18
    rjmp  .Ltext_prepared_low_overwrite

.Ltext_prepared_aligned_overwrite_mask:
    ser   r25
    mov   r15, r25
    rcall sprite_delay_10
    out   SPDR, r20                 ; physical address low, +18
    rjmp  .Ltext_prepared_low_overwrite

.Ltext_prepared_nonoverwrite_mask:
    rcall sprite_delay_14
    out   SPDR, r20                 ; physical address low, +18
    rjmp  .Ltext_prepared_low_nonoverwrite

.Ltext_prepared_low_overwrite:
    ; Precompute full-row overwrite preserve masks and select its dispatcher.
    ldi   r24, 0xFF
    mul   r24, r18
    com   r0
    com   r1
    mov   r9, r0
    mov   r19, r1
    ldi   r30, lo8(pm(sprite_overwrite_row_dispatch))
    ldi   r31, hi8(pm(sprite_overwrite_row_dispatch))
    out   GPIOR1, r30
    out   GPIOR2, r31
    delay_3
    out   SPDR, ZERO                ; first image byte, +17
    rjmp  .Lsprite_row_dispatch

.Ltext_prepared_low_nonoverwrite:
    ; Valid nonoverwrite text modes differ in bit zero: SELF_MASKED=2, ERASE=3.
    sbrs  r13, 0
    rjmp  .Ltext_prepared_select_self
    ldi   r30, lo8(pm(sprite_erase_row_dispatch))
    ldi   r31, hi8(pm(sprite_erase_row_dispatch))
    rjmp  .Ltext_prepared_store_nonoverwrite_dispatch
.Ltext_prepared_select_self:
    ldi   r30, lo8(pm(sprite_self_row_dispatch))
    ldi   r31, hi8(pm(sprite_self_row_dispatch))
    nop
.Ltext_prepared_store_nonoverwrite_dispatch:
    out   GPIOR1, r30
    out   GPIOR2, r31
    delay_4
    delay_2
    out   SPDR, ZERO                ; first image byte, +17
    rjmp  .Lsprite_row_dispatch

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Sprite row dispatch and streaming loops
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Each selected mode has a compact row-kind dispatcher. OVERWRITE alone
; distinguishes the one possible partial final source row. The other modes
; always use their full-row loops and rely on canonical zero padding.
.macro emit_sprite_overwrite_dispatch label, top_full, top_partial, middle_full, middle_partial, bottom_full, bottom_partial
\label:
    sbrs  r24, SPRITE_FLAG_PARTIAL
    rjmp  .Lsprite_overwrite_kind_\@
    cp    r12, ONE
    brne  .Lsprite_overwrite_kind_\@
    mov   r8, r15
    ori   r24, 0x80
.Lsprite_overwrite_kind_\@:
    sbrc  r24, SPRITE_FLAG_TOP
    rjmp  .Lsprite_overwrite_top_\@
    cp    r12, ONE
    brne  .Lsprite_overwrite_middle_\@
    sbrc  r24, SPRITE_FLAG_BOTTOM
    rjmp  .Lsprite_overwrite_bottom_\@
.Lsprite_overwrite_middle_\@:
    movw  r30, r26
    subi  r30, 0x80
    sbci  r31, 0xFF
    sbrc  r24, 7
    rjmp  \middle_partial
    rjmp  \middle_full
.Lsprite_overwrite_top_\@:
    sbrc  r24, 7
    rjmp  \top_partial
    rjmp  \top_full
.Lsprite_overwrite_bottom_\@:
    sbrc  r24, 7
    rjmp  \bottom_partial
    rjmp  \bottom_full
.endm

.macro emit_sprite_full_dispatch label, top_full, middle_full, bottom_full
\label:
    sbrc  r24, SPRITE_FLAG_TOP
    rjmp  \top_full
    cp    r12, ONE
    brne  .Lsprite_full_middle_\@
    sbrc  r24, SPRITE_FLAG_BOTTOM
    rjmp  \bottom_full
.Lsprite_full_middle_\@:
    movw  r30, r26
    subi  r30, 0x80
    sbci  r31, 0xFF
    rjmp  \middle_full
.endm

emit_sprite_overwrite_dispatch sprite_overwrite_row_dispatch, \
    .Lsprite_top_overwrite_full, .Lsprite_top_overwrite_partial, \
    .Lsprite_middle_overwrite_full, .Lsprite_middle_overwrite_partial, \
    .Lsprite_bottom_overwrite_full, .Lsprite_bottom_overwrite_partial

emit_sprite_full_dispatch sprite_plus_row_dispatch, \
    .Lsprite_top_plus_full, .Lsprite_middle_plus_full, .Lsprite_bottom_plus_full

emit_sprite_full_dispatch sprite_self_row_dispatch, \
    .Lsprite_top_self_full, .Lsprite_middle_self_full, .Lsprite_bottom_self_full

emit_sprite_full_dispatch sprite_erase_row_dispatch, \
    .Lsprite_top_erase_full, .Lsprite_middle_erase_full, .Lsprite_bottom_erase_full

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; OVERWRITE
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Full top and bottom rows use exact 18-cycle standard handoffs.
.Lsprite_top_overwrite_full:
.Lsprite_top_overwrite_full_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    mul   r24, r18
    ld    r25, X
    and   r25, r19
    or    r25, r1
    st    X+, r25
    delay_4
    nop
    dec   r13
    brne  .Lsprite_top_overwrite_full_loop
    rjmp  .Lsprite_top_done

.Lsprite_bottom_overwrite_full:
.Lsprite_bottom_overwrite_full_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    mul   r24, r18
    ld    r25, X
    and   r25, r9
    or    r25, r0
    st    X+, r25
    delay_4
    nop
    dec   r13
    brne  .Lsprite_bottom_overwrite_full_loop
    rjmp  .Lsprite_bottom_done

; Partial top/bottom rows derive their preserve mask once.  The extra source
; mask consumes the cycle otherwise used by the full-row NOP, retaining the
; same exact 18-cycle standard cadence.
.Lsprite_top_overwrite_partial:
    mul   r8, r18
    com   r1
    mov   r19, r1
.Lsprite_top_overwrite_partial_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    and   r24, r8
    mul   r24, r18
    ld    r25, X
    and   r25, r19
    or    r25, r1
    st    X+, r25
    delay_4
    dec   r13
    brne  .Lsprite_top_overwrite_partial_loop
    rjmp  .Lsprite_top_done

.Lsprite_bottom_overwrite_partial:
    mul   r8, r18
    com   r0
    mov   r9, r0
.Lsprite_bottom_overwrite_partial_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    and   r24, r8
    mul   r24, r18
    ld    r25, X
    and   r25, r9
    or    r25, r0
    st    X+, r25
    delay_4
    dec   r13
    brne  .Lsprite_bottom_overwrite_partial_loop
    rjmp  .Lsprite_bottom_done

; Full middle rows are two-column unrolled. The first byte of each pair loads
; both framebuffer pages and preloads the next low-page byte; the second byte
; consumes that preload. Each source-byte OUT-to-OUT interval is exactly 18
; cycles, and odd widths use one correctly aligned prefix column.
.Lsprite_middle_overwrite_full:
    mov   r13, r16
    lsr   r13                        ; pair count
    brcc  .Lsprite_middle_overwrite_pair_loop
    inc   r13
    rjmp  .Lsprite_middle_overwrite_one

.Lsprite_middle_overwrite_pair_loop:
    ; First column of the pair: sixteen cycles after OUT.
    in    r24, SPDR
    out   SPDR, ZERO
    ld    r25, X
    mul   r24, r18
    and   r25, r9
    or    r25, r0
    st    X+, r25
    ld    r25, Z
    and   r25, r19
    or    r25, r1
    st    Z+, r25
.Lsprite_middle_overwrite_one:
    ld    r25, X                    ; preload second low-page byte

    ; Second column: twelve pixel cycles plus NOP/DEC/BRNE = sixteen.
    in    r24, SPDR
    out   SPDR, ZERO
    mul   r24, r18
    and   r25, r9
    or    r25, r0
    st    X+, r25
    ld    r25, Z
    and   r25, r19
    or    r25, r1
    st    Z+, r25
    nop
    dec   r13
    brne  .Lsprite_middle_overwrite_pair_loop
    rjmp  .Lsprite_middle_done

; The single possible partial middle row keeps the compact generic body. With
; the row mask resident in r8 it is 20 cycles/byte rather than the old 21.
.Lsprite_middle_overwrite_partial:
    mul   r8, r18
    com   r0
    com   r1
    mov   r9, r0
    mov   r19, r1
.Lsprite_middle_overwrite_partial_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    and   r24, r8
    mul   r24, r18
    ld    r25, X
    and   r25, r9
    or    r25, r0
    st    X+, r25
    ld    r25, Z
    and   r25, r19
    or    r25, r1
    st    Z+, r25
    dec   r13
    brne  .Lsprite_middle_overwrite_partial_loop
    rjmp  .Lsprite_middle_done

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; PLUS_MASK
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Full top and bottom rows use a standard first image->mask handoff, then the
; proven 17/17 reverse schedule. Each column consumes image then mask.
.Lsprite_top_plus_full:
.Lsprite_top_plus_full_loop:
    cli
    out   SPDR, ZERO                 ; begin mask
    in    r0, SPDR                   ; image
    sei
    mul   r0, r18
    mov   r24, r1
    rcall sprite_delay_10
    cli
    out   SPDR, ZERO                 ; begin next image
    in    r0, SPDR                   ; mask
    sei
    mul   r0, r18
    mov   r25, r1
    ld    r19, X
    com   r25
    and   r19, r25
    or    r19, r24
    st    X+, r19
    dec   r13
    brne  .Lsprite_top_plus_full_loop
    rjmp  .Lsprite_top_done

.Lsprite_bottom_plus_full:
.Lsprite_bottom_plus_full_loop:
    cli
    out   SPDR, ZERO                 ; begin mask
    in    r0, SPDR                   ; image
    sei
    mul   r0, r18
    mov   r24, r0
    rcall sprite_delay_10
    cli
    out   SPDR, ZERO                 ; begin next image
    in    r0, SPDR                   ; mask
    sei
    mul   r0, r18
    mov   r25, r0
    ld    r19, X
    com   r25
    and   r19, r25
    or    r19, r24
    st    X+, r19
    dec   r13
    brne  .Lsprite_bottom_plus_full
    rjmp  .Lsprite_bottom_done

; Full middle rows use 17 cycles from image OUT to mask OUT and 18 cycles from
; mask OUT to the next image OUT after the first standard priming handoff.
.Lsprite_middle_plus_full:
.Lsprite_middle_plus_full_loop:
    cli
    out   SPDR, ZERO                 ; begin mask
    in    r0, SPDR                   ; image
    sei
    mul   r0, r18
    movw  r24, r0
    ld    r9, X
    ld    r19, Z
    rcall sprite_delay_7
    in    r0, SPDR                   ; mask
    out   SPDR, ZERO                 ; begin next image
    mul   r0, r18
    com   r0
    com   r1
    and   r9, r0
    or    r9, r24
    st    X+, r9
    and   r19, r1
    or    r19, r25
    st    Z+, r19
    dec   r13
    brne  .Lsprite_middle_plus_full_loop
    rjmp  .Lsprite_middle_done

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; SELF_MASKED
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Top/bottom rows use exact 18-cycle standard handoffs.
; Middle rows retain their existing 18-cycle streaming bodies.
.Lsprite_top_self_full:
.Lsprite_top_self_full_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    mul   r24, r18
    ld    r25, X
    or    r25, r1
    st    X+, r25
    delay_3
    delay_3
    dec   r13
    brne  .Lsprite_top_self_full_loop
    rjmp  .Lsprite_top_done

.Lsprite_bottom_self_full:
.Lsprite_bottom_self_full_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    mul   r24, r18
    ld    r25, X
    or    r25, r0
    st    X+, r25
    delay_3
    delay_3
    dec   r13
    brne  .Lsprite_bottom_self_full_loop
    rjmp  .Lsprite_bottom_done

; Full middle rows remain 18 cycles/byte with one balancing NOP.
.Lsprite_middle_self_full:
.Lsprite_middle_self_full_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    mul   r24, r18
    ld    r25, X
    or    r25, r0
    st    X+, r25
    ld    r25, Z
    or    r25, r1
    st    Z+, r25
    nop
    dec   r13
    brne  .Lsprite_middle_self_full_loop
    rjmp  .Lsprite_middle_done

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; ERASE
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Top/bottom rows use exact 18-cycle standard handoffs.
; The middle path remains the 19-cycle drawBasicFX schedule.
.Lsprite_top_erase_full:
.Lsprite_top_erase_full_loop:
    cli
    out   SPDR, ZERO
    in    r24, SPDR
    sei
    mul   r24, r18
    com   r1
    ld    r25, X
    and   r25, r1
    st    X+, r25
    delay_2
    dec   r13
    brne  .Lsprite_top_erase_full_loop
    rjmp  .Lsprite_top_done

.Lsprite_bottom_erase_full:
.Lsprite_bottom_erase_full_loop:
    cli
    out   SPDR, ZERO
    in    r24, SPDR
    sei
    mul   r24, r18
    com   r0
    ld    r25, X
    and   r25, r0
    st    X+, r25
    delay_2
    dec   r13
    brne  .Lsprite_bottom_erase_full_loop
    rjmp  .Lsprite_bottom_done

.Lsprite_middle_erase_full:
.Lsprite_middle_erase_full_loop:
    in    r24, SPDR
    out   SPDR, ZERO
    mul   r24, r18
    com   r0
    com   r1
    ld    r25, X
    and   r25, r0
    st    X+, r25
    ld    r25, Z
    and   r25, r1
    st    Z+, r25
    dec   r13
    brne  .Lsprite_middle_erase_full_loop
    rjmp  .Lsprite_middle_done

.Lsprite_row_dispatch:
    ; Preserve this row's top/bottom/overwrite-partial metadata before the
    ; persistent top flag is cleared. Only the overwrite dispatcher interprets
    ; SPRITE_FLAG_PARTIAL or uses r8/r15.
    mov   r24, r23
    mov   r13, r16                    ; visible-column counter

    ; For pageStart==-1, X names one page before the framebuffer. Move it to
    ; page zero for the single top-row high-contribution loop, then clear the
    ; persistent top flag so subsequent rows use the normal page pointer.
    sbrs  r24, SPRITE_FLAG_TOP
    rjmp  .Lsprite_row_pointer_ready
    andi  r23, 0xFE
    subi  r26, 0x80
    sbci  r27, 0xFF
.Lsprite_row_pointer_ready:

    in    r30, GPIOR1
    in    r31, GPIOR2
    ijmp


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Sprite row progression, reseek, and restoration
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

.Lsprite_top_done:
    ; X advanced across page zero. Reset it to the same visible page start for
    ; the following row's low contribution.
    sub   r26, r16
    sbc   r27, ZERO
    rjmp  .Lsprite_row_complete

.Lsprite_middle_done:
    ; X advanced across the visible columns of the low page. Advance to the
    ; same x coordinate on the following framebuffer page.
    mov   r24, r14
    add   r26, r24
    adc   r27, ZERO

.Lsprite_row_complete:
    dec   r12
    breq  .Lsprite_finish

    ; Contiguous full-width rows continue directly in the existing transaction.
    ; Only clipped rows retain and advance r20:r21:r22 for a fresh seek.
    sbrs  r23, SPRITE_FLAG_RESEEK
    rjmp  .Lsprite_row_dispatch

; Start streaming at the following visible source row without disturbing X.
; This helper is used only when SPRITE_FLAG_RESEEK indicates horizontal
; clipping. It advances the retained physical row pointer after launching
; SFC_READ, hiding the four pointer-update cycles in the command interval.
; r24:r25 are scratch; the first data byte is in flight on return.
    fx_disable
    ldi   r24, SFC_READ
    fx_enable
    out   SPDR, r24

    ; Advance to the same visible x position in the following source row.
    ; The retained pointer is already physical for both generic sprites and
    ; prepared text, so no data-page translation is performed here.
    movw  r24, r10
    add   r20, r24
    adc   r21, r25
    adc   r22, ZERO

    mov   r25, r21

    ; Five useful setup cycles after command launch plus this complete
    ; twelve-cycle delay place address high at the exact cycle-18 handoff.
    rcall sprite_delay_12
    out   SPDR, r22

    ; Remaining meaningful bytes use exact 18-cycle standard handoffs.
    rcall sprite_delay_17
    out   SPDR, r25
    rcall sprite_delay_17
    out   SPDR, r20
    rcall sprite_delay_16
    out   SPDR, ZERO
    rjmp  .Lsprite_row_dispatch

.Lsprite_bottom_done:
    ; Bottom is necessarily the last visible source row.

.Lsprite_finish:
    brts  .Lsprite_finish_text
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    pop   r19
    pop   r18
    pop   r17
    pop   r16
    pop   r15
    pop   r14
    pop   r13
    pop   r12
    pop   r11
    pop   r10
    pop   r9
    pop   r8
    fx_disable
    ret

.Lsprite_finish_text:
    fx_disable
    jmp   .Ltext_emit_char_restore


; Local complete-cycle delay ladder. Each entry is the total cycle count from
; the calling RCALL through the returning RET. NOP-only fallthrough entries do
; not clobber MUL results or renderer state.
sprite_delay_17:
    nop
sprite_delay_16:
    nop
sprite_delay_15:
    nop
sprite_delay_14:
    nop
sprite_delay_13:
    nop
sprite_delay_12:
    nop
sprite_delay_11:
    nop
sprite_delay_10:
    nop
sprite_delay_9:
    nop
sprite_delay_8:
    nop
sprite_delay_7:
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; SYS filled-rectangle drawing services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; ABI (architectural registers):
;   draw_filled_rect_white(x=r4, y=r5, w=r6, h=r7)
;   draw_filled_rect_black(x=r4, y=r5, w=r6, h=r7)
;
; x and y are signed 16-bit coordinates. Width and height are unsigned bytes
; carried in low8(r6) and low8(r7); their high bytes are ignored. Both services
; preserve all architectural registers, VM_FLAGS, VM_PC, and VM_SP. The SYS
; decoder has already launched the following primary-opcode transfer, so this
; SRAM-only service leaves that byte buffered and returns through the late
; standard dispatch tail. It never touches SPDR or either SPI chip select.
;
; After the visibility tests, native r16-r23 (architectural r4-r7) are saved on
; the AVR hardware stack and reused as follows:
;   r16  clipped x
;   r17  first-page fill mask
;   r18  first framebuffer page
;   r19  last-page fill mask
;   r20  clipped visible width
;   r21  framebuffer page count / middle-page count
;   r22  last framebuffer page
;   r23  row advance (128-width)
;   r0   complete-page fill byte (0xFF white, 0x00 black)
;   r1   framebuffer byte scratch
;   r24  current edge mask
;   r25  column/block counter
;   X    current framebuffer pointer
;   Z    visibility-test scratch
;   T    color: one=white, zero=black
;
; Complete pages use eight-byte unrolled stores. Partial first/last pages use
; read-modify-write loops specialized by T: white ORs the fill mask, while
; black ANDs its complement.

sys_draw_filled_rect_start:
sys_draw_filled_rect_impl:
    ; Service 0x27 is odd (white); service 0x28 is even (black). Native T is
    ; preserved by the timer ISR and by all arithmetic below.
    bst   PRIMARY_OPCODE, 0

    ; Empty rectangles are no-ops. Width/height high bytes are intentionally
    ; ignored under the uint8_t service ABI.
    tst   VM_R6L
    breq  .Lsys_rect_reject_unpushed
    tst   VM_R7L
    breq  .Lsys_rect_reject_unpushed

    ; Reject origins already beyond the right or bottom edge. These are signed
    ; comparisons because x and y are int16_t.
    cpi   VM_R4L, 128
    cpc   VM_R4H, ZERO
    brge  .Lsys_rect_reject_unpushed
    cpi   VM_R5L, 64
    cpc   VM_R5H, ZERO
    brge  .Lsys_rect_reject_unpushed

    ; Reject rectangles whose right/bottom exclusive edge is nonpositive.
    ; The preceding upper-bound checks make both additions overflow-safe.
    movw  r30, VM_R4
    add   r30, VM_R6L
    adc   r31, ZERO
    cp    ZERO, r30
    cpc   ZERO, r31
    brge  .Lsys_rect_reject_unpushed

    movw  r30, VM_R5
    add   r30, VM_R7L
    adc   r31, ZERO
    cp    ZERO, r30
    cpc   ZERO, r31
    brlt  .Lsys_rect_visible

.Lsys_rect_reject_unpushed:
    jmp   cluster_tail_18

.Lsys_rect_visible:
    ; Preserve exactly the architectural inputs that will become workspace.
    push  r16
    push  r17
    push  r18
    push  r19
    push  r20
    push  r21
    push  r22
    push  r23

    ; Clip a negative left edge. The visibility test guarantees that the
    ; modulo-eight-bit addition computes a nonzero visible width correctly.
    sbrs  r17, 7
    rjmp  .Lsys_rect_x_nonnegative
    add   r20, r16
    clr   r16
.Lsys_rect_x_nonnegative:

    ; Clip a negative top edge in the same way.
    sbrs  r19, 7
    rjmp  .Lsys_rect_y_nonnegative
    add   r22, r18
    clr   r18
.Lsys_rect_y_nonnegative:

    ; Clamp the right edge to x=128.
    ldi   r24, 128
    sub   r24, r16
    cp    r20, r24
    brlo  .Lsys_rect_width_clipped
    mov   r20, r24
.Lsys_rect_width_clipped:

    ; Clamp the bottom edge to y=64.
    ldi   r24, 64
    sub   r24, r18
    cp    r22, r24
    brlo  .Lsys_rect_height_clipped
    mov   r22, r24
.Lsys_rect_height_clipped:

    ; Form the exclusive bottom coordinate before reusing r22 as lastPage.
    add   r22, r18

    ; r17 = 0xFF << (clippedY & 7), the bits changed in the first page.
    ldi   r17, 1
    sbrc  r18, 1
    ldi   r17, 4
    sbrc  r18, 0
    lsl   r17
    sbrc  r18, 2
    swap  r17
    neg   r17

    ; Initially form 0xFF << (endExclusive & 7). For an unaligned end, its
    ; complement is the fill mask below the edge. For an aligned end, the last
    ; included page is complete and therefore uses 0xFF rather than zero.
    ldi   r19, 1
    sbrc  r22, 1
    ldi   r19, 4
    sbrc  r22, 0
    lsl   r19
    sbrc  r22, 2
    swap  r19
    neg   r19
    sbrc  r19, 0
    rjmp  .Lsys_rect_last_mask_ready
    com   r19
.Lsys_rect_last_mask_ready:

    ; Convert y and endExclusive-1 to inclusive framebuffer page indices.
    dec   r22
    lsr   r18
    lsr   r18
    lsr   r18
    lsr   r22
    lsr   r22
    lsr   r22

    ; Inclusive page count, in the range 1..8.
    mov   r21, r22
    sub   r21, r18
    inc   r21

    ; X = data_display + firstPage*128 + clippedX.
    ; r23 is then retained as the page-to-page correction after width stores.
    ldi   r23, 128
    mul   r18, r23
    movw  r26, r0
    subi  r26, lo8(-data_display)
    sbci  r27, hi8(-data_display)
    add   r26, r16
    adc   r27, ZERO
    sub   r23, r20

    ; Construct the complete-page byte without a color branch.
    clr   r0
    bld   r0, 0
    neg   r0

    ; A one-page rectangle needs the intersection of its two edge masks.
    cpi   r21, 1
    brne  .Lsys_rect_multiple_pages
    mov   r24, r17
    and   r24, r19
    rcall .Lsys_rect_apply_mask_row
    rjmp  .Lsys_rect_finish

.Lsys_rect_multiple_pages:
    ; First page: use its edge mask, or the full-row fast path when aligned.
    mov   r24, r17
    rcall .Lsys_rect_apply_mask_row
    add   r26, r23
    adc   r27, ZERO

    ; Exclude the already-rendered first page and the separately-rendered last
    ; page. Any remaining pages are complete and use unrolled stores.
    subi  r21, 2
    breq  .Lsys_rect_last_page

.Lsys_rect_middle_page:
    rcall .Lsys_rect_fill_row
    add   r26, r23
    adc   r27, ZERO
    dec   r21
    brne  .Lsys_rect_middle_page

.Lsys_rect_last_page:
    mov   r24, r19
    rcall .Lsys_rect_apply_mask_row

.Lsys_rect_finish:
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    pop   r19
    pop   r18
    pop   r17
    pop   r16
    jmp   cluster_tail_18

; Apply the fill mask in r24 across one framebuffer row. A full mask bypasses
; read-modify-write and enters the unrolled complete-row store directly.
.Lsys_rect_apply_mask_row:
    cpi   r24, 0xFF
    breq  .Lsys_rect_fill_row
    brts  .Lsys_rect_or_row

    ; Black: preserve bits outside the rectangle and clear bits inside it.
    com   r24
    mov   r25, r20
.Lsys_rect_and_loop:
    ld    r1, X
    and   r1, r24
    st    X+, r1
    dec   r25
    brne  .Lsys_rect_and_loop
    ret

    ; White: preserve bits outside the rectangle and set bits inside it.
.Lsys_rect_or_row:
    mov   r25, r20
.Lsys_rect_or_loop:
    ld    r1, X
    or    r1, r24
    st    X+, r1
    dec   r25
    brne  .Lsys_rect_or_loop
    ret

; Store r0 across one complete framebuffer page row. Handle the 0..7-byte
; remainder once, then emit eight bytes per loop iteration.
.Lsys_rect_fill_row:
    mov   r25, r20
    andi  r25, 7
    breq  .Lsys_rect_fill_blocks_setup
.Lsys_rect_fill_remainder:
    st    X+, r0
    dec   r25
    brne  .Lsys_rect_fill_remainder

.Lsys_rect_fill_blocks_setup:
    mov   r25, r20
    andi  r25, 0xF8
    breq  .Lsys_rect_fill_done
.Lsys_rect_fill_block:
    st    X+, r0
    st    X+, r0
    st    X+, r0
    st    X+, r0
    st    X+, r0
    st    X+, r0
    st    X+, r0
    st    X+, r0
    subi  r25, 8
    brne  .Lsys_rect_fill_block
.Lsys_rect_fill_done:
    ret

sys_draw_filled_rect_end:
.if (sys_draw_filled_rect_end - sys_draw_filled_rect_start) != 318
    .error "filled-rectangle SYS implementation must occupy exactly 159 AVR words"
.endif


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Display commands and system configuration SYS services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Raw RAM command stream: r4 = data pointer, r5 = unsigned 16-bit byte count.
; All guest registers, flags, SP, and RAM are preserved. A zero count does not
; read the pointer or disturb the OLED. Nonempty streams borrow the shared SPI
; bus only after draining the speculative instruction fetch.
sys_send_display_command_impl:
    movw  r24, VM_R5
    mov   r26, r24
    or    r26, r25
    brne  1f
    jmp   cluster_tail_18
1:
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
2:
    in    r26, SPSR
    sbrs  r26, SPIF
    rjmp  2b
    in    r26, SPDR
    fx_disable

    movw  r30, VM_R4
    display_command_mode
    display_enable
3:
    ld    r26, Z+
    call  oled_spi_transfer_blocking_func
    sbiw  r24, 1
    brne  3b
    ; The blocking helper acknowledges the final completed transfer as well.
    display_disable
    display_data_mode
    jmp   seek_and_dispatch_func

; Immutable configuration queries share a dispatcher and the normal fetch
; tail. Width/height are logical visible pixels, not controller RAM geometry.
; Return the complete zero-extended result in r4; preserve all other state.
sys_system_info_impl:
    ldi   VM_R4H, 0
    ldi   VM_R4L, 128
    cpi   PRIMARY_OPCODE, SYS_GET_SYSTEM_WIDTH
    breq  1f
    ldi   VM_R4L, 64
    cpi   PRIMARY_OPCODE, SYS_GET_SYSTEM_HEIGHT
    breq  1f
#if defined(AVM_DISPLAY_SSD1306)
    ldi   VM_R4L, 1
#elif defined(AVM_DISPLAY_SSD1309)
    ldi   VM_R4L, 2
#elif defined(AVM_DISPLAY_SH1106)
    ldi   VM_R4L, 3
#else
    ldi   VM_R4L, 0
#endif
1:
    jmp   cluster_tail_18

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Platform and persistent-storage SYS services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Save records occupy the selected 4 KiB save sector as an append-only log:
;
;   uint16_t saveSize, little-endian
;   uint8_t  data[saveSize]
;
; Records are valid only when their size equals the current image header's
; saveSize. The final two sector bytes remain erased. SAVE appends a record,
; erasing the sector first when the next record does not fit or the first
; nonmatching header is not erased. LOAD walks all matching records and leaves
; the newest one in data_globals. SAVE_EXISTS tests only the first header.
;
; The long services terminate the speculative bytecode SPI transfer, perform
; blocking flash transactions, then restart the bytecode stream at VM_PC.
sys_platform_dispatch_impl:
    subi  PRIMARY_OPCODE, SYS_BUTTONS
    ldi   r30, lo8(pm(sys_platform_dispatch_table))
    ldi   r31, hi8(pm(sys_platform_dispatch_table))
    add   r30, PRIMARY_OPCODE
    adc   r31, ZERO
    ijmp

sys_platform_dispatch_table:
    rjmp  sys_buttons_impl
    rjmp  sys_idle_impl
    rjmp  sys_generate_random_seed_impl
    rjmp  sys_persistence_begin_func
    rjmp  sys_persistence_begin_func
    rjmp  sys_persistence_begin_func
sys_platform_dispatch_table_end:
.if (sys_platform_dispatch_table_end - sys_platform_dispatch_table) != 12
    .error "platform SYS dispatch table must contain six one-word entries"
.endif

; uint8_t buttons(void), returned as a zero-extended value in r4.
; Canonical Arduboy mask: U=0x80, R=0x40, L=0x20, D=0x10, A=0x08, B=0x04.
sys_buttons_impl:
    clr   VM_R4L
    clr   VM_R4H
    sbis  AVM_BUTTON_UP_PIN, AVM_BUTTON_UP_BIT
    ori   VM_R4L, 0x80
    sbis  AVM_BUTTON_RIGHT_PIN, AVM_BUTTON_RIGHT_BIT
    ori   VM_R4L, 0x40
    sbis  AVM_BUTTON_LEFT_PIN, AVM_BUTTON_LEFT_BIT
    ori   VM_R4L, 0x20
    sbis  AVM_BUTTON_DOWN_PIN, AVM_BUTTON_DOWN_BIT
    ori   VM_R4L, 0x10
    sbis  AVM_BUTTON_A_PIN, AVM_BUTTON_A_BIT
    ori   VM_R4L, 0x08
    sbis  AVM_BUTTON_B_PIN, AVM_BUTTON_B_BIT
    ori   VM_R4L, 0x04
    jmp   cluster_tail_18

; Enter AVR idle sleep until an enabled interrupt, normally Timer0 compare A,
; wakes the CPU. The completed speculative opcode remains pending in SPDR and
; is consumed by the standard tail after wakeup.
sys_idle_impl:
    ldi   r24, _BV(SE)
    out   SMCR, r24
    sleep
    out   SMCR, ZERO
    lds   r24, data_audio_ticks_pending
    tst   r24
    brne 1f
    jmp   cluster_tail_18
1:
    ; The regular tail advances from the SYS service byte to the next opcode.
    ; Seeking for audio service bypasses that tail, so advance explicitly;
    ; otherwise SYS_IDLE's 0x2A operand executes as SUB r6,r6 after wakeup.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO
    jmp   seek_and_dispatch_func

; uint16_t generate_random_seed(void): one ADC1 conversion plus TCNT0.
; Restore the prior ADC mux and power-reduction state after the conversion.
sys_generate_random_seed_impl:
    lds   r25, PRR0
    mov   r24, r25
    andi  r24, (0xFF ^ _BV(PRADC))
    sts   PRR0, r24

    lds   r26, ADMUX
    ldi   r27, (_BV(REFS0) | _BV(REFS1) | _BV(MUX0))
    sts   ADMUX, r27

    ldi   r27, (_BV(ADEN) | _BV(ADPS2) | _BV(ADPS1) | _BV(ADPS0))
    sts   ADCSRA, r27
    ori   r27, _BV(ADSC)
    sts   ADCSRA, r27
1:
    lds   r27, ADCSRA
    sbrc  r27, ADSC
    rjmp  1b

    ; ADCL must be read before ADCH.
    lds   VM_R4L, ADCL
    lds   VM_R4H, ADCH
    in    r27, TCNT0
    add   VM_R4L, r27
    adc   VM_R4H, ZERO

    sts   ADCSRA, ZERO
    sts   ADMUX, r26
    sts   PRR0, r25
    jmp   cluster_tail_18

; Terminate the speculative following-primary transfer launched by SYS decode,
; advance VM_PC from the service byte to that primary opcode, and dispatch the
; selected persistence implementation.
;
; Relative to the SYS decoder's final OUT SPDR,ZERO:
;   cycles  0-20  SYS and platform dispatch, including the service bounds check
;   cycles 21-22  platform-table RJMP to this common entry
;   cycle      23  CBI begins; FX is deselected when it completes on cycle 24
;
; An SPI byte is available to read on cycle 17, so this fixed deselection is
; safely after completion. No SPSR/SPIF polling is needed. The completed
; speculative byte is deliberately discarded; the bytecode stream is restarted
; from VM_PC after the persistence operation.
sys_persistence_begin_func:
    fx_disable
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; PRIMARY_OPCODE was normalized by sys_platform_dispatch_impl to 3=save,
    ; 4=load, or 5=save_exists. Convert it to a zero-based table index.
    subi  PRIMARY_OPCODE, 3
    ldi   r30, lo8(pm(sys_persistence_dispatch_table))
    ldi   r31, hi8(pm(sys_persistence_dispatch_table))
    add   r30, PRIMARY_OPCODE
    adc   r31, ZERO
    ijmp

sys_persistence_dispatch_table:
    rjmp  sys_save_impl
    rjmp  sys_load_impl
    rjmp  sys_save_exists_impl
sys_persistence_dispatch_table_end:
.if (sys_persistence_dispatch_table_end - sys_persistence_dispatch_table) != 6
    .error "persistence SYS dispatch table must contain three one-word entries"
.endif

; Persistence services use only native scratch registers r0:r1 and r24-r31.
; They therefore do not need to save any architectural registers. load() and
; save_exists() use VM_R4 only for their specified return value.

save_fx_transfer:
    out   SPDR, r30
    rcall sprite_delay_16
    in    r30, SPDR
    ret

; Read the image header's little-endian saveSize at image-relative offset 0x0A.
; Output: r1:r0. Clobbers r24, r26, r27, r30, r31.
fx_read_image_save_size_func:
    ldi   r26, AVM_HEADER_SAVE_SIZE_OFFSET
    lds   r27, data_page_data+0
    lds   r24, data_page_data+1

    fx_disable
    fx_enable
    ldi   r30, SFC_READ
    rcall save_fx_transfer
    mov   r30, r24
    rcall save_fx_transfer
    mov   r30, r27
    rcall save_fx_transfer
    mov   r30, r26
    rcall save_fx_transfer

    rcall save_fx_transfer
    mov   r0, r30
    rcall save_fx_transfer
    mov   r1, r30
    fx_disable
    ret

; Begin a blocking command at save-sector byte offset r25:r24.
; Input command: r30. Preserves r0:r1 and r24:r27.
; Clobbers only r30 and r31.
fx_save_begin_command_func:
    fx_disable
    fx_enable
    rcall save_fx_transfer

    ; Compute the high byte and carry before sending it. The middle byte
    ; is then recomputed, avoiding any need to preserve it across SPI.
    lds   r31, data_page_save+0
    add   r31, r25
    lds   r30, data_page_save+1
    adc   r30, ZERO
    rcall save_fx_transfer

    lds   r30, data_page_save+0
    add   r30, r25
    rcall save_fx_transfer
    mov   r30, r24
    rjmp  save_fx_transfer

fx_save_write_enable_func:
    fx_disable
    fx_enable
    ldi   r30, SFC_WRITE_ENABLE
    rcall save_fx_transfer
    fx_disable
    ret

fx_save_wait_busy_func:
    fx_disable
    fx_enable
    ldi   r30, SFC_READSTATUS1
    rcall save_fx_transfer
1:
    mov   r30, ZERO
    rcall save_fx_transfer
    sbrc  r30, 0
    rjmp  1b
    fx_disable
    ret

; Erase the selected 4 KiB save sector and wait for completion.
; Returns r25:r24 = 0.
fx_save_erase_sector_func:
    rcall fx_save_write_enable_func
    clr   r24
    clr   r25
    ldi   r30, SFC_ERASE
    rcall fx_save_begin_command_func
    fx_disable
    rjmp  fx_save_wait_busy_func

; Open a page-program command at save-sector offset r25:r24.
fx_save_begin_program_page_func:
    rcall fx_save_write_enable_func
    ldi   r30, SFC_WRITE
    rjmp  fx_save_begin_command_func

; Compute end-exclusive record offset: r27:r26 = offset + 2 + saveSize.
; Inputs: offset r25:r24, saveSize r1:r0.
fx_save_record_end_func:
    movw  r26, r24
    add   r26, r0
    adc   r27, r1
    adiw  r26, 2
    ret

; C=1 when r27:r26 exceeds 4094; C=0 when the record fits.
fx_save_record_fits_func:
    ldi   r30, lo8(4094)
    ldi   r31, hi8(4094)
    cp    r30, r26
    cpc   r31, r27
    ret

; void save(void)
;
; Register allocation:
;   r1:r0    saveSize, then remaining payload bytes
;   r25:r24  current save-sector offset
;   r27:r26  header/end/count, then SRAM source pointer X
;   r30:r31  blocking SPI scratch
sys_save_impl:

    lds   r24, data_startup_flags
    sbrs  r24, STARTUP_SAVE_PAGE_VALID
    rjmp   .Lsys_save_done

    rcall fx_read_image_save_size_func
    mov   r24, r0
    or    r24, r1
    brne  .Lsys_save_have_size
    rjmp   .Lsys_save_done
.Lsys_save_have_size:

    ; Scan the append log sequentially from sector offset zero.
    clr   r24
    clr   r25
    ldi   r30, SFC_READ
    rcall fx_save_begin_command_func

.Lsys_save_scan_header:
    rcall save_fx_transfer
    mov   r26, r30                 ; little-endian size low byte
    rcall save_fx_transfer
    mov   r27, r30                 ; little-endian size high byte

    cp    r26, r0
    cpc   r27, r1
    brne  .Lsys_save_scan_mismatch

    rcall fx_save_record_end_func
    rcall fx_save_record_fits_func
    brcs  .Lsys_save_erase
    movw  r24, r26

    ; Skip the existing payload; the read stream then names the next header.
    movw  r26, r0
.Lsys_save_skip_payload:
    rcall save_fx_transfer
    sbiw  r26, 1
    brne  .Lsys_save_skip_payload

    ; A new two-byte header must begin no later than offset 4092.
    ldi   r26, lo8(4092)
    ldi   r27, hi8(4092)
    cp    r26, r24
    cpc   r27, r25
    brsh  .Lsys_save_scan_header
    rjmp  .Lsys_save_erase

.Lsys_save_scan_mismatch:
    ; Only an erased 0xFFFF header marks appendable free space.
    cpi   r26, 0xFF
    brne  .Lsys_save_erase
    cpi   r27, 0xFF
    brne  .Lsys_save_erase

    rcall fx_save_record_end_func
    rcall fx_save_record_fits_func
    brcc  .Lsys_save_append

.Lsys_save_erase:
    fx_disable
    rcall fx_save_erase_sector_func

.Lsys_save_append:
    fx_disable

    ; Write the two-byte little-endian size header before repurposing r1:r0 as
    ; the payload counter. Reopen the page if either header byte lands at 0xFF.
    ldi   r26, lo8(data_globals)
    ldi   r27, hi8(data_globals)
    rcall fx_save_begin_program_page_func

    mov   r30, r0
    rcall save_fx_transfer
    inc   r24
    brne  .Lsys_save_write_size_high
    inc   r25
    fx_disable
    rcall fx_save_wait_busy_func
    rcall fx_save_begin_program_page_func

.Lsys_save_write_size_high:
    mov   r30, r1
    rcall save_fx_transfer
    inc   r24
    brne  .Lsys_save_write_payload
    inc   r25
    fx_disable
    rcall fx_save_wait_busy_func
    rcall fx_save_begin_program_page_func

.Lsys_save_write_payload:
    ld    r30, X+
    rcall save_fx_transfer
    sub   r0, ONE
    sbc   r1, ZERO
    inc   r24
    brne  1f
    inc   r25
1:
    mov   r30, r0
    or    r30, r1
    breq  .Lsys_save_finish_page
    tst   r24
    brne  .Lsys_save_write_payload

    ; The next payload byte begins a new flash page.
    fx_disable
    rcall fx_save_wait_busy_func
    rcall fx_save_begin_program_page_func
    rjmp  .Lsys_save_write_payload

.Lsys_save_finish_page:
    fx_disable
    rcall fx_save_wait_busy_func

.Lsys_save_done:
    fx_disable
    jmp   seek_and_dispatch_func_disabled

; bool load(void), returned canonically as 0 or 1 in r4.
;
; Register allocation:
;   r1:r0    saveSize
;   r25:r24  current save-sector offset
;   r27:r26  header/end, then SRAM destination pointer X
;   r17:r16  payload count and final result register
;   SREG.T   whether at least one complete record was loaded
sys_load_impl:
    clt

    lds   r24, data_startup_flags
    sbrs  r24, STARTUP_SAVE_PAGE_VALID
    rjmp  .Lsys_load_done

    rcall fx_read_image_save_size_func
    mov   r24, r0
    or    r24, r1
    breq  .Lsys_load_done

    clr   r24
    clr   r25
    ldi   r30, SFC_READ
    rcall fx_save_begin_command_func

.Lsys_load_header:
    rcall save_fx_transfer
    mov   r26, r30
    rcall save_fx_transfer
    mov   r27, r30
    cp    r26, r0
    cpc   r27, r1
    brne  .Lsys_load_done

    rcall fx_save_record_end_func
    rcall fx_save_record_fits_func
    brcs  .Lsys_load_done
    movw  r24, r26

    ; Every matching record overwrites the saved prefix, leaving the newest.
    ldi   r26, lo8(data_globals)
    ldi   r27, hi8(data_globals)
    movw  r16, r0
.Lsys_load_payload:
    rcall save_fx_transfer
    st    X+, r30
    sub   r16, ONE
    sbc   r17, ZERO
    brne  .Lsys_load_payload
    set

    ; Stop if there is no room for another complete two-byte header.
    ldi   r26, lo8(4092)
    ldi   r27, hi8(4092)
    cp    r26, r24
    cpc   r27, r25
    brsh  .Lsys_load_header

.Lsys_load_done:
    fx_disable
    clr   VM_R4L
    bld   VM_R4L, 0
    clr   VM_R4H
    jmp   seek_and_dispatch_func_disabled

; bool save_exists(void), returned canonically as 0 or 1 in r4.
;
; Register allocation:
;   r1:r0    saveSize
;   r25:r24  save-sector offset zero
;   r17:r16  first record header and final result register
;   SREG.T   comparison result
sys_save_exists_impl:
    clt

    lds   r24, data_startup_flags
    sbrs  r24, STARTUP_SAVE_PAGE_VALID
    rjmp  .Lsys_save_exists_done

    rcall fx_read_image_save_size_func
    mov   r24, r0
    or    r24, r1
    breq  .Lsys_save_exists_done

    clr   r24
    clr   r25
    ldi   r30, SFC_READ
    rcall fx_save_begin_command_func
    rcall save_fx_transfer
    mov   VM_R4L, r30
    rcall save_fx_transfer
    mov   VM_R4H, r30

    cp    VM_R4L, r0
    cpc   VM_R4H, r1
    brne  .Lsys_save_exists_done
    set

.Lsys_save_exists_done:
    fx_disable
    clr   VM_R4L
    bld   VM_R4L, 0
    clr   VM_R4H
    jmp   seek_and_dispatch_func_disabled


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Native formatting SYS services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Buffer service ABI:
;   r4 = destination data pointer / signed result
;   r5 = destination size (preserved)
;   r2 = va_list data pointer (preserved)
;   q3 = format pointer container (preserved)
;
; Text-formatted entry ABI:
;   r4 = initial x / final x
;   r5 = initial baseline y / final baseline y
;   r2 = va_list data pointer (preserved)
;   r6 or q3 = RAM or program-space format pointer (preserved)
;
; Debug-formatted entry ABI:
;   q3 = program-space format pointer (preserved)
;   r2 = va_list data pointer (preserved)
;   r4 = signed produced-byte count or -1
;
; SYS_VSNPRINTF and draw_textfv use r6 as a data-space format pointer.
; SYS_VSNPRINTF_P, draw_textfv_P, and debug_printfv_P use q3[23:0] and ignore
; q3[31:24]. All formatted services abandon the speculative following-opcode
; fetch, own the FX stream for the complete call, and restart bytecode dispatch
; unconditionally.
;
; Working register allocation while formatting:
;   r8:r9    produced byte count (modulo 2^16; overflow status is sticky)
;   r10:r11  remaining writable bytes, excluding the final NUL
;   r12:r13  field width
;   r14:r15  precision
;   r18      per-conversion flags
;   r19      length state, then digit-loop scratch
;   r20:r23  integer magnitude and conversion scratch
;   Y        bounded-buffer destination, or current text cursor x
;
; The local va_list cursor and all format/program pointers are held in the
; temporary workspace beginning at data_end_private. The dedicated formatter
; FX reader may therefore use X, Z, and r24-r27 freely.

sys_format_impl:
    ; Preserve the source/sink status before SPDR replaces PRIMARY_OPCODE.
    ; Initialize only the selected source while all architectural argument
    ; registers still contain their incoming values.
    mov   r27, PRIMARY_OPCODE       ; retain source/sink status through setup
    sbrc  r27, FORMAT_STATUS_SOURCE_PROGRAM
    rjmp  .Lformat_init_program_source
    sts   data_format_ram_ptr+0, VM_R6L
    sts   data_format_ram_ptr+1, VM_R6H
    rjmp  .Lformat_source_initialized
.Lformat_init_program_source:
    sts   data_format_program_next+0, VM_R6L
    sts   data_format_program_next+1, VM_R6H
    sts   data_format_program_next+2, VM_R7L
    sts   data_format_cache_index, ZERO
    sts   data_format_cache_length, ZERO
.Lformat_source_initialized:

    ; The fixed SYS path reaches this entry after the speculative following-
    ; opcode byte is complete. Consume it, deselect FX, and take ownership of
    ; the bytecode stream. Formatter-launched transfers use open-loop delays.
    in    r24, SPDR
    fx_disable

    ; VM_PC currently identifies the service byte. The stream restart at exit
    ; must begin at the following primary opcode.
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; Preserve architectural registers outside the selected result. Text output
    ; returns q2 and therefore need not preserve incoming r5 (native r18:r19).
    ; Buffer formatting still preserves it exactly as before. Native Y becomes
    ; either the bounded destination or the current text cursor x.
    push  r8
    push  r9
    push  r10
    push  r11
    push  r12
    push  r13
    push  r14
    push  r15
    sbrc  r27, FORMAT_STATUS_SINK_TEXT
    rjmp  .Lformat_r5_save_done
    push  r18
    push  r19
.Lformat_r5_save_done:
    push  r20
    push  r21
    push  r22
    push  r23
    push  r28
    push  r29

    ; Preserve the explicit va_list cursor in call-lifetime workspace. Text
    ; formatting deliberately uses the same r2 ABI as vsnprintf.
    sts   data_format_arg_ptr+0, VM_R2L
    sts   data_format_arg_ptr+1, VM_R2H

    sbrc  r27, FORMAT_STATUS_SINK_TEXT
    rjmp  .Lformat_text_setup
    sbrc  r27, FORMAT_STATUS_SINK_DEBUG
    rjmp  .Lformat_debug_setup

    ; Bounded-buffer sink setup. Consume the incoming r4 pointer before r17
    ; becomes the call-lifetime status register. T remains clear for buffers.
    movw  r28, VM_R4
    clt
    clr   r8
    clr   r9
    movw  r10, VM_R5

    ; Retain only source mode, then reserve one byte for the final NUL when the
    ; original destination size is nonzero.
    mov   r24, r27
    andi  r24, (1 << FORMAT_STATUS_SOURCE_PROGRAM)
    mov   r25, r10
    or    r25, r11
    breq  .Lformat_size_zero
    ori   r24, (1 << FORMAT_STATUS_SIZE_NONZERO)
    sub   r10, ONE
    sbc   r11, ZERO
.Lformat_size_zero:
    mov   r17, r24
    rjmp  format_core

.Lformat_debug_setup:
    ; Debug output has no destination capacity. Keep T clear so text-only
    ; renderer paths remain unreachable, initialize the produced-byte count,
    ; and retain source/debug status in the call-lifetime status register.
    clt
    clr   r8
    clr   r9
    mov   r17, r27
    rjmp  format_core

.Lformat_text_setup:
    ; Text output keeps current x in native Y after preserving the architectural
    ; VM stack pointer. Initial x and current baseline y remain in private SRAM.
    ; line_height==0 avoids parsing or consuming arguments.
    sts   data_text_initial_x+0, VM_R4L
    sts   data_text_initial_x+1, VM_R4H
    movw  r28, VM_R4
    mov   r17, r27                  ; status may now replace incoming r4 high
    set                              ; text sink/renderer contract for full call
    sts   data_text_current_y+0, VM_R5L
    sts   data_text_current_y+1, VM_R5H
    ; r8:r11 are buffer-only count/capacity state and are not read by text sinks.
    lds   r24, data_text_line_height
    tst   r24
    brne  1f
    rjmp   text_finish
1:
    rjmp  format_core

; Common normal/error finish. Preserve generated output and always terminate a
; nonzero-size destination. FX is unconditionally closed and bytecode fetch is
; restarted from the already-advanced VM_PC.
format_finish:
    brtc  .Lformat_finish_nontext
    rjmp  text_finish
.Lformat_finish_nontext:
    ; Debug output has no bounded destination or terminator.
    sbrc  r17, FORMAT_STATUS_SINK_DEBUG
    rjmp  .Lformat_finish_result
    sbrs  r17, FORMAT_STATUS_SIZE_NONZERO
    rjmp  .Lformat_finish_result
    st    Y, ZERO

.Lformat_finish_result:
    sbrc  r17, FORMAT_STATUS_FATAL_ERROR
    rjmp  .Lformat_finish_error
    sbrc  r17, FORMAT_STATUS_COUNT_OVERFLOW
    rjmp  .Lformat_finish_error
    sbrc  r9, 7
    rjmp  .Lformat_finish_error
    movw  r24, r8
    rjmp  .Lformat_finish_restore

.Lformat_finish_error:
    ser   r24
    ser   r25

.Lformat_finish_restore:
    fx_disable
    pop   r29
    pop   r28
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    pop   r19
    pop   r18
    pop   r15
    pop   r14
    pop   r13
    pop   r12
    pop   r11
    pop   r10
    pop   r9
    pop   r8
    movw  VM_R4, r24
    jmp   seek_and_dispatch_func_disabled

format_unexpected_character:
    ori   r17, (1 << FORMAT_STATUS_FATAL_ERROR)
    rjmp  format_finish

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Output sink
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Add logical output count r25:r24 to produced. Overflow is sticky once the
; true count is not representable as a nonnegative AVM int.
format_add_count:
    add   r8, r24
    adc   r9, r25
    brcs  .Lformat_add_count_overflow
    sbrc  r9, 7
    rjmp  .Lformat_add_count_overflow
    ret
.Lformat_add_count_overflow:
    ori   r17, (1 << FORMAT_STATUS_COUNT_OVERFLOW)
    ret

; Inputs r25:r24=count, r0=byte. Add complete logical count, then store only
; min(count,write_remaining) bytes.
format_emit_repeat:
    sbrc  r17, FORMAT_STATUS_SINK_DEBUG
    rjmp  .Lformat_emit_repeat_debug
    brtc  .Lformat_emit_repeat_buffer
    rjmp  text_emit_repeat
.Lformat_emit_repeat_debug:
    rcall format_add_count
    mov   r26, r24
    or    r26, r25
    breq  .Lformat_emit_repeat_done
.Lformat_emit_repeat_debug_loop:
    sts   UEDATX, r0
    sbiw  r24, 1
    brne  .Lformat_emit_repeat_debug_loop
    ret
.Lformat_emit_repeat_buffer:
    rcall format_add_count

    cp    r10, r24
    cpc   r11, r25
    brsh  .Lformat_emit_repeat_fits
    movw  r24, r10
    clr   r10
    clr   r11
    rjmp  .Lformat_emit_repeat_copy
.Lformat_emit_repeat_fits:
    sub   r10, r24
    sbc   r11, r25
.Lformat_emit_repeat_copy:
    mov   r26, r24
    or    r26, r25
    breq  .Lformat_emit_repeat_done
.Lformat_emit_repeat_loop:
    st    Y+, r0
    sbiw  r24, 1
    brne  .Lformat_emit_repeat_loop
.Lformat_emit_repeat_done:
    ret

; Inputs Z=RAM source and r25:r24=count. Logical count is always added; source
; bytes are loaded only for the portion that fits in the destination.
format_emit_ram_span:
    sbrc  r17, FORMAT_STATUS_SINK_DEBUG
    rjmp  .Lformat_emit_ram_span_debug
    brtc  .Lformat_emit_ram_span_buffer
    rjmp  text_emit_ram_span
.Lformat_emit_ram_span_debug:
    rcall format_add_count
    mov   r26, r24
    or    r26, r25
    breq  .Lformat_emit_span_done
.Lformat_emit_ram_span_debug_loop:
    ld    r0, Z+
    sts   UEDATX, r0
    sbiw  r24, 1
    brne  .Lformat_emit_ram_span_debug_loop
    ret
.Lformat_emit_ram_span_buffer:
    rcall format_add_count

    cp    r10, r24
    cpc   r11, r25
    brsh  .Lformat_emit_span_fits
    movw  r24, r10
    clr   r10
    clr   r11
    rjmp  .Lformat_emit_span_copy
.Lformat_emit_span_fits:
    sub   r10, r24
    sbc   r11, r25
.Lformat_emit_span_copy:
    mov   r26, r24
    or    r26, r25
    breq  .Lformat_emit_span_done
.Lformat_emit_span_loop:
    ld    r0, Z+
    st    Y+, r0
    sbiw  r24, 1
    brne  .Lformat_emit_span_loop
.Lformat_emit_span_done:
    ret

; Input r25:r24=content length. Store max(width-content,0).
format_compute_padding:
    movw  r20, r12
    sub   r20, r24
    sbc   r21, r25
    brcc  .Lformat_compute_padding_store
    clr   r20
    clr   r21
.Lformat_compute_padding_store:
    sts   data_format_padding+0, r20
    sts   data_format_padding+1, r21
    ret

format_emit_padding_spaces:
    lds   r24, data_format_padding+0
    lds   r25, data_format_padding+1
    ldi   r16, ' '
    mov   r0, r16
    rjmp  format_emit_repeat

format_emit_pre_padding:
    sbrs  r18, FORMAT_FLAG_LEFT
    rjmp  format_emit_padding_spaces
    ret

format_emit_post_padding:
    sbrc  r18, FORMAT_FLAG_LEFT
    rjmp  format_emit_padding_spaces
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Dedicated formatter program-memory reader
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; Open-loop delay ladder. The named delay includes the calling RCALL and RET.
; Calling format_spi_delay_16 immediately after OUT SPDR places the following
; IN SPDR on cycle 17. Interrupts can extend but cannot shorten the interval.
format_spi_delay_16:
    delay_4
    nop
format_spi_delay_11:
    delay_4
format_spi_delay_7:
    ret

; Input r26:r25:r24=image-relative logical address. Start the first data-byte
; transfer. X, Y, and Z are untouched; r24-r27 are clobbered.
format_fx_begin_read:
    lds   r27, data_page_data+0
    add   r25, r27
    lds   r27, data_page_data+1
    adc   r26, r27

    fx_enable
    ldi   r27, SFC_READ
    out   SPDR, r27
    rcall format_spi_delay_16
    in    r27, SPDR

    out   SPDR, r26
    rcall format_spi_delay_16
    in    r27, SPDR

    out   SPDR, r25
    rcall format_spi_delay_16
    in    r27, SPDR

    out   SPDR, r24
    rcall format_spi_delay_16
    in    r27, SPDR

    out   SPDR, ZERO
    ret

; Copy a short program-space chunk through the formatter-owned reader.
;
; Inputs:
;   r26:r25:r24 = logical source
;   Z           = destination
;   r20         = nonzero maximum byte count (<=16)
;   r21         = zero for fixed count, nonzero to stop after NUL
; Outputs:
;   r26:r25:r24 = source advanced by copied count modulo 2^24
;   r22         = copied count (includes copied NUL)
;   r23         = 1 iff a NUL stopped the copy
format_read_program_chunk:
    sts   data_format_read_source+0, r24
    sts   data_format_read_source+1, r25
    sts   data_format_read_source+2, r26

    rcall format_fx_begin_read
    clr   r22
    clr   r23

.Lformat_read_program_chunk_loop:
    rcall format_spi_delay_16
    in    r27, SPDR
    st    Z+, r27
    inc   r22

    tst   r21
    breq  .Lformat_read_program_chunk_count
    tst   r27
    brne  .Lformat_read_program_chunk_count
    ldi   r23, 1
    rjmp  .Lformat_read_program_chunk_done

.Lformat_read_program_chunk_count:
    cp    r22, r20
    brsh  .Lformat_read_program_chunk_done
    out   SPDR, ZERO
    rjmp  .Lformat_read_program_chunk_loop

.Lformat_read_program_chunk_done:
    fx_disable
    lds   r24, data_format_read_source+0
    lds   r25, data_format_read_source+1
    lds   r26, data_format_read_source+2
    add   r24, r22
    adc   r25, ZERO
    adc   r26, ZERO
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Unified format source
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; The parser obtains every format byte through this routine.
; Output r24=next byte.
format_get_char:
    sbrc  r17, FORMAT_STATUS_SOURCE_PROGRAM
    rjmp  .Lformat_get_char_program

    lds   r30, data_format_ram_ptr+0
    lds   r31, data_format_ram_ptr+1
    ld    r24, Z+
    sts   data_format_ram_ptr+0, r30
    sts   data_format_ram_ptr+1, r31
    ret

.Lformat_get_char_program:
    lds   r25, data_format_cache_index
    lds   r26, data_format_cache_length
    cp    r25, r26
    brlo  .Lformat_get_char_cached
    rcall format_refill_program_cache
    clr   r25
.Lformat_get_char_cached:
    ldi   r30, lo8(data_format_program_cache)
    ldi   r31, hi8(data_format_program_cache)
    add   r30, r25
    adc   r31, ZERO
    ld    r24, Z
    inc   r25
    sts   data_format_cache_index, r25
    ret

format_refill_program_cache:
    lds   r24, data_format_program_next+0
    lds   r25, data_format_program_next+1
    lds   r26, data_format_program_next+2
    ldi   r30, lo8(data_format_program_cache)
    ldi   r31, hi8(data_format_program_cache)
    ldi   r20, 16
    ldi   r21, 1
    rcall format_read_program_chunk
    sts   data_format_program_next+0, r24
    sts   data_format_program_next+1, r25
    sts   data_format_program_next+2, r26
    sts   data_format_cache_length, r22
    sts   data_format_cache_index, ZERO
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Variadic argument readers
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

format_arg_u16:
    lds   r30, data_format_arg_ptr+0
    lds   r31, data_format_arg_ptr+1
    ld    r24, Z+
    ld    r25, Z+
    sts   data_format_arg_ptr+0, r30
    sts   data_format_arg_ptr+1, r31
    ret

format_arg_u32:
    lds   r30, data_format_arg_ptr+0
    lds   r31, data_format_arg_ptr+1
    ld    r20, Z+
    ld    r21, Z+
    ld    r22, Z+
    ld    r23, Z+
    sts   data_format_arg_ptr+0, r30
    sts   data_format_arg_ptr+1, r31
    ret

format_arg_program_pointer:
    lds   r30, data_format_arg_ptr+0
    lds   r31, data_format_arg_ptr+1
    ld    r24, Z+
    ld    r25, Z+
    ld    r26, Z+
    sts   data_format_arg_ptr+0, r30
    sts   data_format_arg_ptr+1, r31
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Parser
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

; X = min(65535, X*10+r24), where r24 is a decimal digit (0..9).
; Width and precision share this cold path. Clobbers r20:r21 and native SREG;
; the formatter's T bit and architectural flags are preserved.
format_accumulate_decimal_digit:
    cpi   r27, 0x19
    brlo  .Lformat_decimal_multiply
    brne  .Lformat_decimal_saturate
    cpi   r26, 0x99
    brlo  .Lformat_decimal_multiply
    brne  .Lformat_decimal_saturate
    cpi   r24, 6
    brsh  .Lformat_decimal_saturate
.Lformat_decimal_multiply:
    lsl   r26
    rol   r27
    movw  r20, r26
    lsl   r26
    rol   r27
    lsl   r26
    rol   r27
    add   r26, r20
    adc   r27, r21
    add   r26, r24
    adc   r27, ZERO
    ret
.Lformat_decimal_saturate:
    ser   r26
    ser   r27
    ret

format_core:
.Lformat_main_loop:
    rcall format_get_char
    tst   r24
    brne  1f
    rjmp  format_finish
1:
    cpi   r24, '%'
    breq  .Lformat_conversion_begin
    rcall format_emit_char
    rjmp  .Lformat_main_loop

.Lformat_conversion_begin:
    clr   r18
    clr   r12
    clr   r13
    clr   r14
    clr   r15
    ldi   r19, FORMAT_LENGTH_DEFAULT
    rcall format_get_char

.Lformat_parse_flags:
    cpi   r24, '-'
    brne  1f
    ori   r18, (1 << FORMAT_FLAG_LEFT)
    rcall format_get_char
    rjmp  .Lformat_parse_flags
1:
    cpi   r24, '+'
    brne  2f
    ori   r18, (1 << FORMAT_FLAG_PLUS)
    rcall format_get_char
    rjmp  .Lformat_parse_flags
2:
    cpi   r24, ' '
    brne  3f
    ori   r18, (1 << FORMAT_FLAG_SPACE)
    rcall format_get_char
    rjmp  .Lformat_parse_flags
3:
    cpi   r24, '#'
    brne  4f
    ori   r18, (1 << FORMAT_FLAG_ALT)
    rcall format_get_char
    rjmp  .Lformat_parse_flags
4:
    cpi   r24, '0'
    brne  .Lformat_parse_width
    ori   r18, (1 << FORMAT_FLAG_ZERO)
    rcall format_get_char
    rjmp  .Lformat_parse_flags

.Lformat_parse_width:
    cpi   r24, '*'
    brne  .Lformat_parse_width_digits_entry
    ori   r18, (1 << FORMAT_FLAG_WIDTH_STAR)
    rcall format_arg_u16
    movw  r12, r24
    sbrs  r13, 7
    rjmp  .Lformat_width_star_ready
    com   r12
    com   r13
    add   r12, ONE
    adc   r13, ZERO
    ori   r18, (1 << FORMAT_FLAG_LEFT)
.Lformat_width_star_ready:
    rcall format_get_char
    rjmp  .Lformat_parse_precision

.Lformat_parse_width_digits_entry:
    cpi   r24, '1'
    brlo  .Lformat_parse_precision
    cpi   r24, '9'+1
    brsh  .Lformat_parse_precision
.Lformat_parse_width_digits:
    subi  r24, '0'
    movw  r26, r12
    rcall format_accumulate_decimal_digit
    movw  r12, r26
    rcall format_get_char
    cpi   r24, '0'
    brlo  .Lformat_parse_precision
    cpi   r24, '9'+1
    brlo  .Lformat_parse_width_digits

.Lformat_parse_precision:
    cpi   r24, '.'
    brne  .Lformat_parse_length
    ori   r18, (1 << FORMAT_FLAG_PRECISION)
    clr   r14
    clr   r15
    rcall format_get_char
    cpi   r24, '*'
    brne  .Lformat_parse_precision_digits_entry
    ori   r18, (1 << FORMAT_FLAG_PRECISION_STAR)
    rcall format_arg_u16
    sbrc  r25, 7
    rjmp  .Lformat_precision_star_negative
    movw  r14, r24
    rcall format_get_char
    rjmp  .Lformat_parse_length
.Lformat_precision_star_negative:
    andi  r18, 0xDF
    rcall format_get_char
    rjmp  .Lformat_parse_length

.Lformat_parse_precision_digits_entry:
    cpi   r24, '0'
    brlo  .Lformat_parse_length
    cpi   r24, '9'+1
    brsh  .Lformat_parse_length
.Lformat_parse_precision_digits:
    subi  r24, '0'
    movw  r26, r14
    rcall format_accumulate_decimal_digit
    movw  r14, r26
    rcall format_get_char
    cpi   r24, '0'
    brlo  .Lformat_parse_length
    cpi   r24, '9'+1
    brlo  .Lformat_parse_precision_digits

.Lformat_parse_length:
    cpi   r24, 'h'
    brne  .Lformat_length_not_h
    ldi   r19, FORMAT_LENGTH_H
    rcall format_get_char
    cpi   r24, 'h'
    brne  .Lformat_dispatch_conversion
    ldi   r19, FORMAT_LENGTH_HH
    rcall format_get_char
    rjmp  .Lformat_dispatch_conversion
.Lformat_length_not_h:
    cpi   r24, 'l'
    brne  1f
    ldi   r19, FORMAT_LENGTH_L
    rcall format_get_char
    rjmp  .Lformat_dispatch_conversion
1:
    cpi   r24, 'z'
    brne  2f
    ldi   r19, FORMAT_LENGTH_Z
    rcall format_get_char
    rjmp  .Lformat_dispatch_conversion
2:
    cpi   r24, 't'
    brne  .Lformat_dispatch_conversion
    ldi   r19, FORMAT_LENGTH_T
    rcall format_get_char

.Lformat_dispatch_conversion:
    sts   data_format_conversion, r24
    cpi   r24, '%'
    breq  format_conversion_percent
1:
    cpi   r24, 'c'
    breq  format_conversion_char
2:
    cpi   r24, 's'
    brne  3f
    rjmp  format_conversion_string
3:
    cpi   r24, 'S'
    brne  4f
    rjmp  format_conversion_program_string
4:
    cpi   r24, 'P'
    brne  5f
    rjmp  format_conversion_program_pointer
5:
    cpi   r24, 'p'
    brne  6f
    rjmp  format_conversion_pointer
6:
    cpi   r24, 'd'
    breq  .Lformat_integer_dispatch
    cpi   r24, 'i'
    breq  .Lformat_integer_dispatch
    cpi   r24, 'u'
    breq  .Lformat_integer_dispatch
    cpi   r24, 'o'
    breq  .Lformat_integer_dispatch
    cpi   r24, 'x'
    breq  .Lformat_integer_dispatch
    cpi   r24, 'X'
    breq  .Lformat_integer_dispatch
    cpi   r24, 'f'
    breq  .Lformat_float_dispatch
    cpi   r24, 'e'
    breq  .Lformat_float_dispatch
    cpi   r24, 'E'
    breq  .Lformat_float_dispatch
    cpi   r24, 'g'
    breq  .Lformat_float_dispatch
    cpi   r24, 'G'
    breq  .Lformat_float_dispatch
    cpi   r24, 'a'
    breq  .Lformat_float_dispatch
    cpi   r24, 'A'
    breq  .Lformat_float_dispatch
    rjmp  format_unexpected_character
.Lformat_integer_dispatch:
    rjmp  format_conversion_integer
.Lformat_float_dispatch:
    rjmp   format_conversion_float

; Require no length modifier for noninteger conversions.
format_validate_default_length:
    ; Return Z=1 for the accepted default length and Z=0 otherwise. RCALL/RET
    ; preserve SREG, so callers can branch immediately without leaking the
    ; helper's return address on an error path.
    tst   r19
    ret

format_conversion_percent:
    rcall format_validate_default_length
    breq  1f
    rjmp  format_unexpected_character
1:
    tst   r18
    breq  1f
    rjmp  format_unexpected_character
1:
    mov   r24, r12
    or    r24, r13
    breq  2f
    rjmp  format_unexpected_character
2:
    ldi   r24, '%'
    rcall format_emit_char
    rjmp  .Lformat_main_loop

format_conversion_char:
    rcall format_validate_default_length
    breq  1f
    rjmp  format_unexpected_character
1:
    sbrc  r18, FORMAT_FLAG_PRECISION
    rjmp  format_unexpected_character
    rcall format_arg_u16
    sts   data_format_conversion, r24
    ldi   r24, 1
    clr   r25
    rcall format_compute_padding
    rcall format_emit_pre_padding
    lds   r24, data_format_conversion
    rcall format_emit_char
    rcall format_emit_post_padding
    rjmp  .Lformat_main_loop

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; String conversions
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

format_conversion_string:
    rcall format_validate_default_length
    breq  1f
    rjmp  format_unexpected_character
1:
    rcall format_arg_u16
    sts   data_format_string_original+0, r24
    sts   data_format_string_original+1, r25

    clr   r20
    clr   r21
    sbrs  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_string_measure_unbounded
    mov   r26, r14
    or    r26, r15
    breq  .Lformat_string_measured
.Lformat_string_measure_bounded:
    cp    r20, r14
    cpc   r21, r15
    brsh  .Lformat_string_measured
    movw  r30, r24
    add   r30, r20
    adc   r31, r21
    ld    r26, Z
    tst   r26
    breq  .Lformat_string_measured
    inc   r20
    brne  .Lformat_string_measure_bounded
    inc   r21
    rjmp  .Lformat_string_measure_bounded
.Lformat_string_measure_unbounded:
    movw  r30, r24
.Lformat_string_measure_unbounded_loop:
    ld    r26, Z+
    tst   r26
    breq  .Lformat_string_measured
    inc   r20
    brne  .Lformat_string_measure_unbounded_loop
    inc   r21
    rjmp  .Lformat_string_measure_unbounded_loop
.Lformat_string_measured:
    sts   data_format_string_length+0, r20
    sts   data_format_string_length+1, r21
    movw  r24, r20
    rcall format_compute_padding
    rcall format_emit_pre_padding
    lds   r30, data_format_string_original+0
    lds   r31, data_format_string_original+1
    lds   r24, data_format_string_length+0
    lds   r25, data_format_string_length+1
    rcall format_emit_ram_span
    rcall format_emit_post_padding
    rjmp  .Lformat_main_loop

format_conversion_program_string:
    rcall format_validate_default_length
    breq  1f
    rjmp  format_unexpected_character
1:
    rcall format_arg_program_pointer
    sts   data_format_progstr_original+0, r24
    sts   data_format_progstr_original+1, r25
    sts   data_format_progstr_original+2, r26
    sts   data_format_progstr_cursor+0, r24
    sts   data_format_progstr_cursor+1, r25
    sts   data_format_progstr_cursor+2, r26
    sts   data_format_string_length+0, ZERO
    sts   data_format_string_length+1, ZERO

    ; Precision zero reads no program byte.
    sbrs  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_program_string_measure_loop
    mov   r24, r14
    or    r24, r15
    breq  .Lformat_program_string_measured
1:

.Lformat_program_string_measure_loop:
    ; Stop when bounded precision has already been reached.
    sbrs  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_program_string_measure_choose
    lds   r24, data_format_string_length+0
    lds   r25, data_format_string_length+1
    cp    r24, r14
    cpc   r25, r15
    brsh  .Lformat_program_string_measured
.Lformat_program_string_measure_choose:
    ldi   r20, 12
    sbrs  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_program_string_measure_read
    movw  r24, r14
    lds   r26, data_format_string_length+0
    lds   r27, data_format_string_length+1
    sub   r24, r26
    sbc   r25, r27
    tst   r25
    brne  .Lformat_program_string_measure_read
    cpi   r24, 12
    brsh  .Lformat_program_string_measure_read
    mov   r20, r24
.Lformat_program_string_measure_read:
    lds   r24, data_format_progstr_cursor+0
    lds   r25, data_format_progstr_cursor+1
    lds   r26, data_format_progstr_cursor+2
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    ldi   r21, 1
    rcall format_read_program_chunk
    sts   data_format_progstr_cursor+0, r24
    sts   data_format_progstr_cursor+1, r25
    sts   data_format_progstr_cursor+2, r26

    mov   r24, r22
    clr   r25
    tst   r23
    breq  .Lformat_program_string_measure_add
    dec   r24
.Lformat_program_string_measure_add:
    lds   r26, data_format_string_length+0
    lds   r27, data_format_string_length+1
    add   r26, r24
    adc   r27, r25
    brcc  .Lformat_program_string_measure_store
    ser   r26
    ser   r27
    ori   r17, (1 << FORMAT_STATUS_COUNT_OVERFLOW)
.Lformat_program_string_measure_store:
    sts   data_format_string_length+0, r26
    sts   data_format_string_length+1, r27
    tst   r23
    breq  .Lformat_program_string_measure_loop
1:

.Lformat_program_string_measured:
    lds   r24, data_format_string_length+0
    lds   r25, data_format_string_length+1
    rcall format_compute_padding
    rcall format_emit_pre_padding

    lds   r24, data_format_progstr_original+0
    lds   r25, data_format_progstr_original+1
    lds   r26, data_format_progstr_original+2
    sts   data_format_progstr_cursor+0, r24
    sts   data_format_progstr_cursor+1, r25
    sts   data_format_progstr_cursor+2, r26
    lds   r12, data_format_string_length+0
    lds   r13, data_format_string_length+1

.Lformat_program_string_emit_loop:
    mov   r24, r12
    or    r24, r13
    breq  .Lformat_program_string_emit_done
    ldi   r20, 12
    tst   r13
    brne  .Lformat_program_string_emit_read
    mov   r24, r12
    cpi   r24, 12
    brsh  .Lformat_program_string_emit_read
    mov   r20, r12
.Lformat_program_string_emit_read:
    lds   r24, data_format_progstr_cursor+0
    lds   r25, data_format_progstr_cursor+1
    lds   r26, data_format_progstr_cursor+2
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    clr   r21
    rcall format_read_program_chunk
    sts   data_format_progstr_cursor+0, r24
    sts   data_format_progstr_cursor+1, r25
    sts   data_format_progstr_cursor+2, r26
    sub   r12, r22
    sbc   r13, ZERO
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    mov   r24, r22
    clr   r25
    rcall format_emit_ram_span
    rjmp  .Lformat_program_string_emit_loop
.Lformat_program_string_emit_done:
    rcall format_emit_post_padding
    rjmp  .Lformat_main_loop

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Pointer conversion
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

format_conversion_pointer:
    rcall format_validate_default_length
    breq  1f
    rjmp  format_unexpected_character
1:
    rcall format_arg_u16
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    ldi   r22, 4
    rjmp  .Lformat_pointer_store_low16

format_conversion_program_pointer:
    rcall format_validate_default_length
    breq  1f
    rjmp  format_unexpected_character
1:
    ; Program pointers occupy exactly three packed little-endian bytes in the
    ; variadic area. No fourth register-container padding byte is consumed.
    rcall format_arg_program_pointer
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    mov   r0, r26
    mov   r26, r0
    swap  r26
    andi  r26, 0x0f
    rcall format_hex_nibble_to_char
    st    Z+, r26
    mov   r26, r0
    andi  r26, 0x0f
    rcall format_hex_nibble_to_char
    st    Z+, r26
    ldi   r22, 6

.Lformat_pointer_store_low16:
    ; Append the low 16 bits in forward hexadecimal order.
    mov   r26, r25
    swap  r26
    andi  r26, 0x0f
    rcall format_hex_nibble_to_char
    st    Z+, r26
    mov   r26, r25
    andi  r26, 0x0f
    rcall format_hex_nibble_to_char
    st    Z+, r26
    mov   r26, r24
    swap  r26
    andi  r26, 0x0f
    rcall format_hex_nibble_to_char
    st    Z+, r26
    mov   r26, r24
    andi  r26, 0x0f
    rcall format_hex_nibble_to_char
    st    Z, r26

    ; Both forms include the two-byte lower-case 0x prefix.
    mov   r24, r22
    subi  r24, -2
    clr   r25
    rcall format_compute_padding
    rcall format_emit_pre_padding
    ldi   r24, '0'
    rcall format_emit_char
    ldi   r24, 'x'
    rcall format_emit_char
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    mov   r24, r22
    clr   r25
    rcall format_emit_ram_span
    rcall format_emit_post_padding
    rjmp  .Lformat_main_loop

format_hex_nibble_to_char:
    cpi   r26, 10
    brlo  1f
    subi  r26, -87
    ret
1:
    subi  r26, -'0'
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Integer conversion
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

format_conversion_integer:
    ; All recognized integer lengths fit the implemented 8/16/32-bit paths.
    cpi   r19, FORMAT_LENGTH_L
    breq  .Lformat_integer_load_long
    rcall format_arg_u16
    mov   r20, r24
    mov   r21, r25
    clr   r22
    clr   r23
    cpi   r19, FORMAT_LENGTH_HH
    brne  .Lformat_integer_loaded
    clr   r21
    rjmp  .Lformat_integer_loaded
.Lformat_integer_load_long:
    rcall format_arg_u32
.Lformat_integer_loaded:
    lds   r24, data_format_conversion

    clr   r26
    cpi   r24, 'd'
    breq  .Lformat_integer_signed
    cpi   r24, 'i'
    brne  .Lformat_integer_unsigned
.Lformat_integer_signed:
    ori   r26, (1 << FORMAT_INT_SIGNED_BIT)
.Lformat_integer_unsigned:
    cpi   r24, 'o'
    brne  1f
    ori   r26, FORMAT_INT_BASE_OCT
    rjmp  .Lformat_integer_mode_ready
1:
    cpi   r24, 'x'
    breq  2f
    cpi   r24, 'X'
    brne  .Lformat_integer_decimal_mode
2:
    ori   r26, FORMAT_INT_BASE_HEX
    cpi   r24, 'X'
    brne  .Lformat_integer_mode_ready
    ori   r26, (1 << FORMAT_INT_UPPER_BIT)
    rjmp  .Lformat_integer_mode_ready
.Lformat_integer_decimal_mode:
    ori   r26, FORMAT_INT_BASE_DEC
.Lformat_integer_mode_ready:
    sts   data_format_integer_mode, r26
    sts   data_format_sign, ZERO

    ; Sign-extend signed 8- and 16-bit values into the common 32-bit
    ; magnitude container. A long value already occupies all four bytes.
    sbrs  r26, FORMAT_INT_SIGNED_BIT
    rjmp  .Lformat_integer_magnitude_ready
    cpi   r19, FORMAT_LENGTH_L
    breq  .Lformat_integer_test_sign
    cpi   r19, FORMAT_LENGTH_HH
    brne  .Lformat_integer_sign_extend_16
    sbrs  r20, 7
    rjmp  .Lformat_integer_test_sign
    ser   r21
    ser   r22
    ser   r23
    rjmp  .Lformat_integer_test_sign
.Lformat_integer_sign_extend_16:
    sbrs  r21, 7
    rjmp  .Lformat_integer_test_sign
    ser   r22
    ser   r23
.Lformat_integer_test_sign:
    sbrs  r23, 7
    rjmp  .Lformat_integer_positive_sign
    ldi   r24, '-'
    sts   data_format_sign, r24
    com   r20
    com   r21
    com   r22
    com   r23
    add   r20, ONE
    adc   r21, ZERO
    adc   r22, ZERO
    adc   r23, ZERO
    rjmp  .Lformat_integer_magnitude_ready
.Lformat_integer_positive_sign:
    sbrc  r18, FORMAT_FLAG_PLUS
    rjmp  .Lformat_integer_plus_sign
    sbrs  r18, FORMAT_FLAG_SPACE
    rjmp  .Lformat_integer_magnitude_ready
    ldi   r24, ' '
    sts   data_format_sign, r24
    rjmp  .Lformat_integer_magnitude_ready
.Lformat_integer_plus_sign:
    ldi   r24, '+'
    sts   data_format_sign, r24

.Lformat_integer_magnitude_ready:
    mov   r24, r20
    or    r24, r21
    or    r24, r22
    or    r24, r23
    sts   data_format_value_nonzero, r24
    rcall format_generate_integer_digits
    rcall format_prepare_integer_field
    rcall format_emit_integer_field
    rjmp  .Lformat_main_loop

; Generate reverse-order digits in data_format_digit_buffer and store count.
format_generate_integer_digits:
    sts   data_format_digit_count, ZERO
    lds   r24, data_format_value_nonzero
    tst   r24
    brne  .Lformat_generate_digits_loop

    ; Integer precision zero suppresses the ordinary zero digit.
    sbrs  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_generate_zero_digit
    mov   r24, r14
    or    r24, r15
    brne  1f
    rjmp  .Lformat_generate_digits_done
1:
.Lformat_generate_zero_digit:
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    ldi   r24, '0'
    st    Z, r24
    ldi   r24, 1
    sts   data_format_digit_count, r24
    rjmp  .Lformat_generate_digits_done

.Lformat_generate_digits_loop:
    lds   r26, data_format_integer_mode
    mov   r27, r26
    andi  r27, FORMAT_INT_BASE_MASK
    cpi   r27, FORMAT_INT_BASE_HEX
    breq  .Lformat_generate_hex_digit
    cpi   r27, FORMAT_INT_BASE_OCT
    breq  .Lformat_generate_octal_digit

    rcall format_divide_u32_by_10
    mov   r26, r24
    subi  r26, -'0'
    rjmp  .Lformat_store_generated_digit

.Lformat_generate_hex_digit:
    mov   r26, r20
    andi  r26, 0x0f
    lds   r27, data_format_integer_mode
    sbrs  r27, FORMAT_INT_UPPER_BIT
    rjmp  .Lformat_hex_lower_digit
    cpi   r26, 10
    brlo  .Lformat_hex_numeric_digit
    subi  r26, -55
    rjmp  .Lformat_hex_digit_ready
.Lformat_hex_lower_digit:
    cpi   r26, 10
    brlo  .Lformat_hex_numeric_digit
    subi  r26, -87
    rjmp  .Lformat_hex_digit_ready
.Lformat_hex_numeric_digit:
    subi  r26, -'0'
.Lformat_hex_digit_ready:
    lsr   r23
    ror   r22
    ror   r21
    ror   r20
    lsr   r23
    ror   r22
    ror   r21
    ror   r20
    lsr   r23
    ror   r22
    ror   r21
    ror   r20
    lsr   r23
    ror   r22
    ror   r21
    ror   r20
    rjmp  .Lformat_store_generated_digit

.Lformat_generate_octal_digit:
    mov   r26, r20
    andi  r26, 0x07
    subi  r26, -'0'
    lsr   r23
    ror   r22
    ror   r21
    ror   r20
    lsr   r23
    ror   r22
    ror   r21
    ror   r20
    lsr   r23
    ror   r22
    ror   r21
    ror   r20

.Lformat_store_generated_digit:
    lds   r24, data_format_digit_count
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    add   r30, r24
    adc   r31, ZERO
    st    Z, r26
    inc   r24
    sts   data_format_digit_count, r24
    mov   r25, r20
    or    r25, r21
    or    r25, r22
    or    r25, r23
    breq  1f
    rjmp  .Lformat_generate_digits_loop
1:
.Lformat_generate_digits_done:
    ret

; Divide r23:r20 by 10 in place; return remainder in r24.
format_divide_u32_by_10:
    clr   r24
    mov   r25, r23
    rcall format_divide_byte_by_10
    mov   r23, r25
    mov   r25, r22
    rcall format_divide_byte_by_10
    mov   r22, r25
    mov   r25, r21
    rcall format_divide_byte_by_10
    mov   r21, r25
    mov   r25, r20
    rcall format_divide_byte_by_10
    mov   r20, r25
    ret

; Input r24=remainder 0..9, r25=next dividend byte. Output r24=new remainder,
; r25=quotient byte. Shift eight dividend bits through the remainder, setting
; each quotient bit after at most one subtraction. Small leading bytes skip
; the loop. The remainder never exceeds 19, and the formatter's T flag survives.
format_divide_byte_by_10:
    tst   r24
    brne  .Lformat_divide_byte_bits
    cpi   r25, 10
    brsh  .Lformat_divide_byte_bits
    mov   r24, r25
    clr   r25
    ret
.Lformat_divide_byte_bits:
    ldi   r26, 8
.Lformat_divide_byte_loop:
    lsl   r25
    rol   r24
    cpi   r24, 10
    brlo  .Lformat_divide_byte_next
    subi  r24, 10
    ori   r25, 1
.Lformat_divide_byte_next:
    dec   r26
    brne  .Lformat_divide_byte_loop
    ret

; Compute precision zeroes, prefix, content length, and width padding.
format_prepare_integer_field:
    sts   data_format_precision_zeroes+0, ZERO
    sts   data_format_precision_zeroes+1, ZERO
    sts   data_format_prefix, ZERO

    lds   r24, data_format_digit_count
    clr   r25
    sbrs  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_integer_precision_ready
    cp    r14, r24
    cpc   r15, r25
    brlo  .Lformat_integer_precision_ready
    movw  r26, r14
    sub   r26, r24
    sbc   r27, r25
    sts   data_format_precision_zeroes+0, r26
    sts   data_format_precision_zeroes+1, r27
.Lformat_integer_precision_ready:

    lds   r26, data_format_integer_mode
    mov   r27, r26
    andi  r27, FORMAT_INT_BASE_MASK
    sbrs  r18, FORMAT_FLAG_ALT
    rjmp  .Lformat_integer_prefix_ready
    cpi   r27, FORMAT_INT_BASE_HEX
    brne  .Lformat_integer_check_octal_prefix
    lds   r24, data_format_value_nonzero
    tst   r24
    breq  .Lformat_integer_prefix_ready
    sbrs  r26, FORMAT_INT_UPPER_BIT
    rjmp  .Lformat_integer_hex_lower_prefix
    ldi   r24, FORMAT_PREFIX_HEX_UPPER
    sts   data_format_prefix, r24
    rjmp  .Lformat_integer_prefix_ready
.Lformat_integer_hex_lower_prefix:
    ldi   r24, FORMAT_PREFIX_HEX_LOWER
    sts   data_format_prefix, r24
    rjmp  .Lformat_integer_prefix_ready
.Lformat_integer_check_octal_prefix:
    cpi   r27, FORMAT_INT_BASE_OCT
    brne  .Lformat_integer_prefix_ready
    lds   r24, data_format_precision_zeroes+0
    lds   r25, data_format_precision_zeroes+1
    or    r24, r25
    brne  .Lformat_integer_prefix_ready
    lds   r24, data_format_value_nonzero
    tst   r24
    brne  .Lformat_integer_set_octal_prefix
    lds   r24, data_format_digit_count
    tst   r24
    brne  .Lformat_integer_prefix_ready
.Lformat_integer_set_octal_prefix:
    ldi   r24, FORMAT_PREFIX_OCTAL
    sts   data_format_prefix, r24
.Lformat_integer_prefix_ready:

    ; content = digit count + precision zeroes + sign + prefix, saturating.
    lds   r24, data_format_digit_count
    clr   r25
    lds   r26, data_format_precision_zeroes+0
    lds   r27, data_format_precision_zeroes+1
    add   r24, r26
    adc   r25, r27
    brcs  .Lformat_integer_content_saturate
    lds   r26, data_format_sign
    tst   r26
    breq  1f
    adiw  r24, 1
    breq  .Lformat_integer_content_saturate
1:
    lds   r26, data_format_prefix
    tst   r26
    breq  .Lformat_integer_content_ready
    cpi   r26, FORMAT_PREFIX_OCTAL
    breq  2f
    adiw  r24, 2
    brcs  .Lformat_integer_content_saturate
    rjmp  .Lformat_integer_content_ready
2:
    adiw  r24, 1
    brne  .Lformat_integer_content_ready
.Lformat_integer_content_saturate:
    ser   r24
    ser   r25
    ori   r17, (1 << FORMAT_STATUS_COUNT_OVERFLOW)
.Lformat_integer_content_ready:
    rjmp  format_compute_padding

format_emit_integer_field:
    ; Width zero padding is active only when not left-adjusted and no explicit
    ; integer precision was supplied. r19 remains stable across sink calls.
    clr   r19
    sbrc  r18, FORMAT_FLAG_LEFT
    rjmp  .Lformat_integer_emit_spaces
    sbrc  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_integer_emit_spaces
    sbrs  r18, FORMAT_FLAG_ZERO
    rjmp  .Lformat_integer_emit_spaces
    ldi   r19, 1
    rjmp  .Lformat_integer_emit_sign
.Lformat_integer_emit_spaces:
    rcall format_emit_pre_padding

.Lformat_integer_emit_sign:
    lds   r24, data_format_sign
    tst   r24
    breq  .Lformat_integer_emit_prefix
    rcall format_emit_char

.Lformat_integer_emit_prefix:
    lds   r26, data_format_prefix
    tst   r26
    breq  .Lformat_integer_emit_width_zeroes
    ldi   r24, '0'
    rcall format_emit_char
    lds   r26, data_format_prefix
    cpi   r26, FORMAT_PREFIX_OCTAL
    breq  .Lformat_integer_emit_width_zeroes
    cpi   r26, FORMAT_PREFIX_HEX_UPPER
    breq  1f
    ldi   r24, 'x'
    rjmp  2f
1:
    ldi   r24, 'X'
2:
    rcall format_emit_char

.Lformat_integer_emit_width_zeroes:
    tst   r19
    breq  .Lformat_integer_emit_precision_zeroes
    lds   r24, data_format_padding+0
    lds   r25, data_format_padding+1
    ldi   r16, '0'
    mov   r0, r16
    rcall format_emit_repeat

.Lformat_integer_emit_precision_zeroes:
    lds   r24, data_format_precision_zeroes+0
    lds   r25, data_format_precision_zeroes+1
    ldi   r16, '0'
    mov   r0, r16
    rcall format_emit_repeat

    sts   data_format_conversion, r19
    lds   r19, data_format_digit_count
    tst   r19
    breq  .Lformat_integer_emit_post
.Lformat_integer_emit_digits_loop:
    dec   r19
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    add   r30, r19
    adc   r31, ZERO
    ld    r24, Z
    rcall format_emit_char
    tst   r19
    brne  .Lformat_integer_emit_digits_loop
.Lformat_integer_emit_post:
    lds   r19, data_format_conversion
    tst   r19
    brne  .Lformat_integer_emit_done
    rcall format_emit_post_padding
.Lformat_integer_emit_done:
    ret


;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Native font and text drawing SYS services
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Persistent state stores only the selected glyph-table base, three header
; bytes, and renderer mode. Glyph image offsets are relative to the cached
; glyph-table base, so image addresses require only a 24-bit addition. A zero
; line_height is the sole no-font sentinel.
;
; Drawing ABIs:
;   draw_text:       r4=x, r5=baseline y, r6=RAM string
;   draw_text_P:     r4=x, r5=baseline y, q3=program string
;   draw_textfv:     r4=x, r5=baseline y, r6=RAM format, r2=va_list
;   draw_textfv_P:   r4=x, r5=baseline y, q3=program format, r2=va_list
;
; All four return final x in r4 and final baseline y in r5. Only '\n' has
; special treatment. Every other emitted byte, including '\r' and formatted
; NUL from %c, undergoes ordinary glyph lookup. Raw source terminators are
; consumed by their source loops and never delivered to the glyph sink.
;
; All FX access remains open-loop. Font headers use the shared fixed-count
; reader; glyph records use a dedicated inline seven-byte transaction whose
; transfer slack performs record addressing, register preservation, coordinate
; setup, cursor advance, image addressing, and visibility rejection. Program
; strings/formats use the formatter's 16-byte cache; visible glyph images enter
; the shared bitmap renderer through its text-only no-preservation contract. No
; path polls SPSR/SPIF.

; q2 contains the image-relative font address. A null logical pointer merely
; clears line_height and preserves the speculative bytecode transaction. For a
; nonnull font, cache the physical address of font+3 and read the three-byte header directly into
; persistent state. q2[31:24] is ignored and the complete q2 is preserved.
sys_set_text_font_impl:
    movw  r24, VM_R4
    mov   r26, VM_R5L
    mov   r27, r24
    or    r27, r25
    or    r27, r26
    brne  .Lsys_set_text_font_nonnull
    sts   data_text_line_height, ZERO
    jmp   cluster_tail_18

.Lsys_set_text_font_nonnull:
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    adiw  r24, 3
    adc   r26, ZERO
    ; Cache the physical glyph-table base once. All record and image offsets
    ; are relative to this base, so ordinary glyph drawing no longer reloads
    ; or adds data_page_data.
    lds   r27, data_page_data+0
    add   r25, r27
    lds   r27, data_page_data+1
    adc   r26, r27
    sts   data_text_glyph_table+0, r24
    sts   data_text_glyph_table+1, r25
    sts   data_text_glyph_table+2, r26

    movw  r24, VM_R4
    mov   r26, VM_R5L
    ; The three persistent header bytes have the same order as the font
    ; header, so the fixed-count reader can write them in place. Text services
    ; are nonreentrant; no staging/commit copy is required.
    ldi   r30, lo8(data_text_line_height)
    ldi   r31, hi8(data_text_line_height)
    ldi   r27, 3
    mov   r0, r27
    mov   r1, ZERO
    call  fx_read_program_bytes_func
    jmp   seek_and_dispatch_func_disabled

; Values 0, 2, and 3 map directly to the raw sprite renderer's overwrite,
; self-masked (transparent white), and erase (transparent black) modes.
; Invalid values are deliberately ignored and leave the prior mode unchanged.
sys_set_text_mode_impl:
    mov   r24, VM_R4L
    cpi   r24, 4
    brsh  .Lsys_set_text_mode_done
    cpi   r24, SPRITE_MODE_PLUS_MASK
    breq  .Lsys_set_text_mode_done
    sts   data_text_mode, r24
.Lsys_set_text_mode_done:
    jmp   cluster_tail_18

; Raw RAM/program string entry. Raw and formatted text share the reduced
; text-only save contract and text_finish. VM_PC is advanced once,
; and the speculative following byte is discarded before any independent FX
; transaction begins.
sys_text_raw_impl:
    ; Retain source/text status in scratch until incoming r4 has been copied;
    ; r17 is VM_R4H and must still contain the high byte of initial x here.
    mov   r27, PRIMARY_OPCODE
    sbrc  r27, FORMAT_STATUS_SOURCE_PROGRAM
    rjmp  .Ltext_raw_init_program_source
    sts   data_format_ram_ptr+0, VM_R6L
    sts   data_format_ram_ptr+1, VM_R6H
    rjmp  .Ltext_raw_source_initialized
.Ltext_raw_init_program_source:
    sts   data_format_program_next+0, VM_R6L
    sts   data_format_program_next+1, VM_R6H
    sts   data_format_program_next+2, VM_R7L
    sts   data_format_cache_index, ZERO
    sts   data_format_cache_length, ZERO
.Ltext_raw_source_initialized:

    in    r24, SPDR
    fx_disable
    add   VM_PCL, ONE
    adc   VM_PCM, ZERO
    adc   VM_PCH, ZERO

    ; Text returns q2, so incoming r5 is not part of the preservation contract.
    ; This stack layout matches the formatted-text path and text_finish.
    push  r8
    push  r9
    push  r10
    push  r11
    push  r12
    push  r13
    push  r14
    push  r15
    push  r20
    push  r21
    push  r22
    push  r23
    push  r28
    push  r29

    sts   data_text_initial_x+0, VM_R4L
    sts   data_text_initial_x+1, VM_R4H
    movw  r28, VM_R4
    mov   r17, r27                  ; register-resident source/text status
    set                              ; text sink/renderer contract for full call
    sts   data_text_current_y+0, VM_R5L
    sts   data_text_current_y+1, VM_R5H

    lds   r24, data_text_line_height
    tst   r24
    breq  text_finish

.Lsys_text_raw_loop:
    rcall format_get_char
    tst   r24
    breq  text_finish
    rcall text_emit_char_raw
    rjmp  .Lsys_text_raw_loop

; Shared completion for raw and formatted text. The current cursor is captured
; before restoring the architectural register file, then installed as q2 after
; restoration. r6/r7, r2, CC, and SP therefore retain their input values;
; incoming r5 is intentionally replaced as the high half of the q2 result.
text_finish:
    ; Capture and install q2 before restoring the outer text frame. The
    ; bytecode SFC_READ command is launched first, allowing every pop to
    ; overlap the command/address phase.
    movw  r24, r28
    lds   r26, data_text_current_y+0
    lds   r27, data_text_current_y+1
    movw  VM_R4, r24
    movw  VM_R5, r26

    ldi   r30, SFC_READ
    fx_enable
    out   SPDR, r30

    ; Restore six registers while forming physical PC high/middle. This is a
    ; legal late meaningful-byte handoff and is still much earlier than the
    ; former post-restoration command launch.
    pop   r29
    pop   r28
    pop   r23
    pop   r22
    pop   r21
    pop   r20
    lds   r26, data_page_data+0
    add   r26, VM_PCM
    lds   r27, data_page_data+1
    adc   r27, VM_PCH
    out   SPDR, r27

    ; Eight pops plus one NOP provide the 18-cycle meaningful-byte interval.
    pop   r15
    pop   r14
    pop   r13
    pop   r12
    pop   r11
    pop   r10
    pop   r9
    pop   r8
    nop
    out   SPDR, r26

    rcall .Ltext_restart_delay_17
    out   SPDR, VM_PCL
    rcall .Ltext_restart_delay_16
    out   SPDR, ZERO
    rcall .Ltext_restart_delay_15
    cli
    out   SPDR, ZERO
    in    PRIMARY_OPCODE, SPDR
    sei
    mul   PRIMARY_OPCODE, FOUR
    movw  r30, r0
    subi  r31, hi8(-(pm(primary_table)))
    ijmp

; Compact complete-cycle delay ladder for the only restart delays used.
.Ltext_restart_delay_17:
    nop
.Ltext_restart_delay_16:
    nop
.Ltext_restart_delay_15:
    delay_4
    delay_4
    ret

; Text repeated-byte sink. The per-glyph fixed-reader union preserves both the
; formatter and the count/byte loop state, so no outer save frame is required.
text_emit_repeat:
    ; The fixed glyph reader preserves the complete union of direct/repeat/span
    ; live registers around every valid glyph. Original r12:r15 values are dead
    ; once padding/zero emission begins, so no sink-level save frame is needed.
    movw  r12, r24
    mov   r14, r0
.Ltext_emit_repeat_loop:
    mov   r24, r12
    or    r24, r13
    breq  .Ltext_emit_repeat_done
    sub   r12, ONE
    sbc   r13, ZERO
    mov   r24, r14
    rcall text_emit_char_repeat
    rjmp  .Ltext_emit_repeat_loop
.Ltext_emit_repeat_done:
    ret

; Text RAM-span sink. Preserve the caller's outer r12:r13 once; the per-glyph
; fixed-reader union preserves the evolving source-pointer/count loop state.
text_emit_ram_span:
    ; Program-string chunking keeps an outer remaining count in r12:r13, so
    ; restore that pair after the complete span. The fixed glyph reader preserves
    ; the evolving r12:r15 loop state and formatter-live r18 around every glyph.
    push  r12
    push  r13
    movw  r12, r24
    movw  r14, r30
.Ltext_emit_ram_span_loop:
    mov   r24, r12
    or    r24, r13
    breq  .Ltext_emit_ram_span_done
    sub   r12, ONE
    sbc   r13, ZERO
    movw  r30, r14
    ld    r24, Z+
    movw  r14, r30
    rcall text_emit_char_span
    rjmp  .Ltext_emit_ram_span_loop
.Ltext_emit_ram_span_done:
    pop   r13
    pop   r12
    ret

.Ltext_newline_char:
    lds   r28, data_text_initial_x+0
    lds   r29, data_text_initial_x+1
    lds   r24, data_text_current_y+0
    lds   r25, data_text_current_y+1
    lds   r26, data_text_line_height
    add   r24, r26
    adc   r25, ZERO
    sts   data_text_current_y+0, r24
    sts   data_text_current_y+1, r25
.Ltext_emit_char_lookup_out_of_range:
    ret

.Lformat_emit_char_debug:
    sts   UEDATX, r24
    ldi   r24, 1
    clr   r25
    rjmp  format_add_count
.Lformat_emit_char_buffer_or_debug:
    sbrc  r17, FORMAT_STATUS_SINK_DEBUG
    rjmp  .Lformat_emit_char_debug
    mov   r0, r24
    ldi   r24, 1
    clr   r25
    rjmp  format_emit_repeat

; Input r24=byte.
format_emit_char:
    brtc  .Lformat_emit_char_buffer_or_debug

; Emit one logical text byte. Only newline is special. Missing glyphs have no
; framebuffer effect and zero advance. Available records are seven bytes in an
; order chosen to expose renderer dependencies as early as possible:
;   h, yoff, w, xoff, imageOffset[15:0], xadv.
; xoff/yoff are signed. y is the baseline, so glyph top is baseline+yoff.
;
; All four entries share one preservation contract. Once range checking proves
; that a record exists, the fixed transaction unconditionally saves the union
; of registers live at any direct/repeat/span emission point:
;   r12:r15, r18:r19, r22.
; Newline and missing glyphs return before opening a transaction or pushing.
; Empty and clipped valid glyphs consume the record, apply xadv, restore the
; union, and return without opening the image transaction.
;
; The reordered fields pipeline renderer setup through the seven record bytes:
; height/page count, rendered y and visibility, width/stride/vertical shift,
; rendered x and visibility, top clipping, horizontal clipping, and source-row
; adjustment. A visible glyph then enters draw_bitmap_seek_prepared_text_func,
; which schedules the remaining setup inside the image command/address phase.
text_emit_char:
text_emit_char_repeat:
text_emit_char_span:
text_emit_char_raw:
    cpi   r24, '\n'
    breq  .Ltext_newline_char

.Ltext_emit_char_lookup:
    lds   r25, data_text_glyph_first
    sub   r24, r25
    lds   r25, data_text_num_glyphs
    cp    r24, r25
    brsh  .Ltext_emit_char_lookup_out_of_range

    ; Fixed seven-byte record transaction. The physical record address and all
    ; seven live-register pushes are hidden in the command/address phase.
    fx_enable
    ldi   r30, SFC_READ
    out   SPDR, r30                 ; command OUT, cycle 0

    ldi   r27, 7
    mul   r24, r27
    lds   r24, data_text_glyph_table+0
    lds   r25, data_text_glyph_table+1
    lds   r26, data_text_glyph_table+2
    add   r24, r0
    adc   r25, r1
    adc   r26, ZERO
    delay_4
    nop
    out   SPDR, r26                 ; physical record address high, +18

    ; Preserve the union live at direct/repeat/span emission points. r17 is the
    ; call-lifetime status register and is never touched by the renderer.
    push  r12
    push  r13
    push  r14
    push  r15
    push  r18
    push  r19
    push  r22
    delay_2
    nop
    out   SPDR, r25                 ; physical record address middle, +18

    ; Install mode, baseline, and physical image base while middle transfers.
    lds   r13, data_text_mode
    lds   r18, data_text_current_y+0
    lds   r19, data_text_current_y+1
    clr   r26                       ; top source-page skip
    clr   r27                       ; horizontal source-column skip
    clr   r11
    clr   r23                       ; renderer flags/reject accumulator
    lds   r20, data_text_glyph_table+0
    lds   r21, data_text_glyph_table+1
    lds   r22, data_text_glyph_table+2
    nop
    out   SPDR, r24                 ; physical record address low, +18

    rcall .Ltext_record_delay_16
    out   SPDR, ZERO                ; begin h, +17

    rcall .Ltext_record_delay_16
    in    r1, SPDR                  ; unsigned h
    out   SPDR, ZERO                ; begin signed yoff

    tst   r1
    brne  .Ltext_height_nonzero
    ori   r23, (1 << TEXT_GLYPH_FLAG_REJECT)
.Ltext_height_nonzero:
    mov   r12, r1
    lsr   r12
    lsr   r12
    lsr   r12
    mov   r30, r1
    andi  r30, 0x07
    mov   r15, r30
    cpse  r15, ZERO
    inc   r12
    delay_4
    in    r30, SPDR                 ; signed yoff
    out   SPDR, ZERO                ; begin w

    ; renderedY = baseline + sign_extend(yoff), plus complete vertical reject.
    clr   r31
    sbrc  r30, 7
    com   r31
    add   r18, r30
    adc   r19, r31
    cpi   r18, 64
    cpc   r19, ZERO
    brlt  .Ltext_y_below_bottom_edge
    ori   r23, (1 << TEXT_GLYPH_FLAG_REJECT)
.Ltext_y_below_bottom_edge:
    movw  r30, r18
    add   r30, r1
    adc   r31, ZERO
    cp    ZERO, r30
    cpc   ZERO, r31
    brlt  .Ltext_y_extent_visible
    ori   r23, (1 << TEXT_GLYPH_FLAG_REJECT)
.Ltext_y_extent_visible:
    in    r0, SPDR                  ; unsigned w
    out   SPDR, ZERO                ; begin signed xoff

    ; Width/stride, vertical shift, and arithmetic destination page.
    mov   r8, r0
    tst   r8
    brne  .Ltext_width_nonzero
    ori   r23, (1 << TEXT_GLYPH_FLAG_REJECT)
.Ltext_width_nonzero:
    mov   r10, r8

    mov   r11, ONE
    sbrc  r18, 1
    mov   r11, FOUR
    sbrc  r18, 0
    lsl   r11
    sbrc  r18, 2
    swap  r11

    mov   r30, r18
    asr   r19
    ror   r30
    asr   r30
    asr   r30
    mov   r19, r30
    mov   r18, r11
    in    r30, SPDR                 ; signed xoff
    out   SPDR, ZERO                ; begin image offset low

    ; renderedX = cursor + sign_extend(xoff), plus horizontal reject.
    movw  r24, r28
    clr   r31
    sbrc  r30, 7
    com   r31
    add   r24, r30
    adc   r25, r31
    cpi   r24, 128
    cpc   r25, ZERO
    brlt  .Ltext_x_below_right_edge
    ori   r23, (1 << TEXT_GLYPH_FLAG_REJECT)
.Ltext_x_below_right_edge:
    mov   r27, r25                  ; preserve rendered-x high across offsets
    movw  r30, r24
    add   r30, r8
    adc   r31, ZERO
    cp    ZERO, r30
    cpc   ZERO, r31

    in    r11, SPDR                 ; image offset low
    out   SPDR, ZERO                ; begin image offset high

    brlt  .Ltext_x_extent_visible
    ori   r23, (1 << TEXT_GLYPH_FLAG_REJECT)
.Ltext_x_extent_visible:

    ; Top clipping. r26 retains the source-page skip for pointer adjustment.
    mov   r26, r19
    neg   r26
    cpi   r18, 1
    breq  .Ltext_top_skip_aligned
    sub   r26, ONE
.Ltext_top_skip_aligned:
    sbrc  r26, 7
    clr   r26
    sub   r12, r26
    add   r19, r26
    cpi   r19, 0xFF
    mov   r30, r24
    nop
    brne  .Ltext_not_top_row
    ori   r23, (1 << SPRITE_FLAG_TOP)
.Ltext_not_top_row:
    in    r25, SPDR                 ; image offset high
    out   SPDR, ZERO                ; begin xadv

    ; Horizontal clipping. r27 initially carries rendered-x high, then
    ; becomes leftSkip; r31 becomes framebuffer x.
    sbrs  r27, 7
    rjmp  .Ltext_x_nonnegative
    neg   r30
    mov   r27, r30
    mov   r16, r8
    sub   r16, r30
    clr   r31
    rjmp  .Ltext_clip_right
.Ltext_x_nonnegative:
    mov   r31, r30
    clr   r27                       ; leftSkip = 0
    mov   r16, r8
.Ltext_clip_right:
    ldi   r30, 128
    sub   r30, r31
    cp    r30, r16
    brsh  .Ltext_right_clip_done
    mov   r16, r30
.Ltext_right_clip_done:
    cpse  r16, r8
    ori   r23, (1 << SPRITE_FLAG_RESEEK)
    ldi   r30, 128
    mov   r14, r30
    sub   r14, r16

    ; The horizontal setup above exactly fills the final 17-cycle record-byte
    ; interval. Read xadv before doing image-only pointer work so empty or fully
    ; clipped glyphs do not pay for an image address they will never use.
    in    r24, SPDR                 ; unsigned xadv, final record byte

    sbrc  r23, TEXT_GLYPH_FLAG_REJECT
    rjmp  .Ltext_emit_char_rejected

    ; physicalImage = physicalGlyphBase + imageOffset16
    ;               + topSkip*stride + leftSkip.
    ; Compute this after the record byte is available but before launching the
    ; image command. The command transfer then again overlaps cursor advance and
    ; the tail jump, preserving the exact command+18 address-high handoff.
    
    mul   r26, r10
    add   r20, r0
    adc   r21, r1
    adc   r22, ZERO

    ; The computation is completed inside draw_bitmap_seek_prepared_text_func.

    fx_disable
    ldi   r30, SFC_READ
    fx_enable
    out   SPDR, r30
    add   r28, r24
    adc   r29, ZERO
    jmp   draw_bitmap_seek_prepared_text_func

.Ltext_emit_char_rejected:
    add   r28, r24
    adc   r29, ZERO
    fx_disable
    rjmp  .Ltext_emit_char_restore

.Ltext_emit_char_restore:
    pop   r22
    pop   r19
    pop   r18
    pop   r15
    pop   r14
    pop   r13
    pop   r12
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Local complete-cycle delays for the inlined record transaction.
.Ltext_record_delay_16:
    nop
.Ltext_record_delay_15:
    delay_4
    nop
.Ltext_record_delay_10:
    nop
    delay_2
.Ltext_record_delay_7:
    ret

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Floating-point conversions
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Decimal conversions use a formatter-local adaptation of avr-libc's
; __ftoa_engine. It produces at most eight rounded significant decimal digits
; plus a signed decimal exponent. Requested precision beyond those meaningful
; digits is honored by emitting zero runs through the common sink.
;
; Hexadecimal conversion is independent of the decimal engine. It normalizes
; the binary32 significand, rounds explicit precisions to nearest-even, and
; emits all six fraction nibbles (or a shorter exact default form) directly.

; Only the two helpers beyond direct RCALL reach retain local veneers.
; Their RJMPs preserve the caller's return address, so each helper RET returns
; directly to the float routine. All other calls target shared helpers directly.
format_float_veneer_emit_post_padding:
    rjmp   format_emit_post_padding
format_float_veneer_emit_ram_span:
    rjmp   format_emit_ram_span

format_conversion_float:
    rcall format_validate_default_length
    breq  1f
    rjmp  format_unexpected_character
1:
    rcall format_arg_u32
    sts   data_format_float_value+0, r20
    sts   data_format_float_value+1, r21
    sts   data_format_float_value+2, r22
    sts   data_format_float_value+3, r23

    lds   r24, data_format_conversion
    cpi   r24, 'a'
    breq  1f
    cpi   r24, 'A'
    brne  2f
1:
    rjmp   format_conversion_float_hex
2:
    rjmp  format_conversion_float_decimal

; Establish the sign character from the shared FTOA classification flags.
; NaN does not inherit its payload sign; + and space still apply.
format_float_set_sign:
    sts   data_format_sign, ZERO
    lds   r24, data_format_float_flags
    sbrs  r24, 0                    ; FTOA_MINUS
    rjmp  .Lformat_float_positive_sign
    sbrc  r24, 3                    ; FTOA_NAN
    rjmp  .Lformat_float_positive_sign
    ldi   r24, '-'
    sts   data_format_sign, r24
    ret
.Lformat_float_positive_sign:
    sbrc  r18, FORMAT_FLAG_PLUS
    rjmp  .Lformat_float_plus_sign
    sbrs  r18, FORMAT_FLAG_SPACE
    ret
    ldi   r24, ' '
    sts   data_format_sign, r24
    ret
.Lformat_float_plus_sign:
    ldi   r24, '+'
    sts   data_format_sign, r24
    ret

format_float_emit_sign:
    lds   r24, data_format_sign
    tst   r24
    breq  1f
    rcall format_emit_char
1:
    ret

; Add the unsigned byte in r26 to content length r25:r24. Saturate and mark
; count overflow if the logical field length no longer fits in 16 bits.
format_float_content_add_u8:
    add   r24, r26
    adc   r25, ZERO
    brcc  1f
    ser   r24
    ser   r25
    ori   r17, (1 << FORMAT_STATUS_COUNT_OVERFLOW)
1:
    ret

; Decimal fields place zero width padding after the sign. Special values use a
; separate all-space path.
format_float_begin_decimal_field:
    rcall format_compute_padding
    sbrc  r18, FORMAT_FLAG_LEFT
    rjmp  .Lformat_float_decimal_sign
    sbrc  r18, FORMAT_FLAG_ZERO
    rjmp  .Lformat_float_decimal_sign
    rcall format_emit_pre_padding
.Lformat_float_decimal_sign:
    rcall format_float_emit_sign
    sbrc  r18, FORMAT_FLAG_LEFT
    ret
    sbrs  r18, FORMAT_FLAG_ZERO
    ret
    lds   r24, data_format_padding+0
    lds   r25, data_format_padding+1
    ldi   r16, '0'
    mov   r0, r16
    rjmp   format_emit_repeat

; Hex fields place zero width padding after the sign and 0x/0X prefix.
format_float_begin_hex_field:
    rcall format_compute_padding
    sbrc  r18, FORMAT_FLAG_LEFT
    rjmp  .Lformat_float_hex_sign
    sbrc  r18, FORMAT_FLAG_ZERO
    rjmp  .Lformat_float_hex_sign
    rcall format_emit_pre_padding
.Lformat_float_hex_sign:
    rcall format_float_emit_sign
    ldi   r24, '0'
    rcall format_emit_char
    lds   r24, data_format_conversion
    sbrs  r24, 5
    rjmp  .Lformat_float_hex_prefix_upper
    ldi   r24, 'x'
    rjmp  .Lformat_float_hex_prefix_emit
.Lformat_float_hex_prefix_upper:
    ldi   r24, 'X'
.Lformat_float_hex_prefix_emit:
    rcall format_emit_char
    sbrc  r18, FORMAT_FLAG_LEFT
    ret
    sbrs  r18, FORMAT_FLAG_ZERO
    ret
    lds   r24, data_format_padding+0
    lds   r25, data_format_padding+1
    ldi   r16, '0'
    mov   r0, r16
    rjmp   format_emit_repeat

format_float_emit_zeroes:
    ldi   r16, '0'
    mov   r0, r16
    rjmp   format_emit_repeat

format_float_store_precision:
    sts   data_format_float_precision+0, r14
    sts   data_format_float_precision+1, r15
    ret

format_float_emit_point_if_needed:
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    or    r24, r25
    brne  .Lformat_float_emit_point
    sbrs  r18, FORMAT_FLAG_ALT
    ret
.Lformat_float_emit_point:
    ldi   r24, '.'
    rjmp   format_emit_char

; Emit a finite/special spelling after all-space width padding. The conversion
; character selects case for E/G/A forms.
format_float_emit_special:
    ldi   r24, 3
    clr   r25
    lds   r26, data_format_sign
    tst   r26
    breq  1f
    adiw  r24, 1
1:
    rcall format_compute_padding
    rcall format_emit_pre_padding
    rcall format_float_emit_sign

    lds   r26, data_format_float_flags
    sbrc  r26, 3                    ; FTOA_NAN
    rjmp  .Lformat_float_emit_nan
    ldi   r20, 'i'
    ldi   r21, 'n'
    ldi   r22, 'f'
    rjmp  .Lformat_float_special_case
.Lformat_float_emit_nan:
    ldi   r20, 'n'
    ldi   r21, 'a'
    ldi   r22, 'n'
.Lformat_float_special_case:
    lds   r26, data_format_conversion
    sbrc  r26, 5
    rjmp  .Lformat_float_special_store
    subi  r20, 32
    subi  r21, 32
    subi  r22, 32
.Lformat_float_special_store:
    sts   data_format_digit_buffer+0, r20
    sts   data_format_digit_buffer+1, r21
    sts   data_format_digit_buffer+2, r22
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    ldi   r24, 3
    clr   r25
    rcall format_float_veneer_emit_ram_span
    rcall format_float_veneer_emit_post_padding
    rjmp   .Lformat_main_loop

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Decimal f/e/g conversion
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

format_conversion_float_decimal:
    ; All decimal forms default to precision six. %g precision zero means one
    ; significant digit.
    sbrc  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_float_decimal_precision_ready
    ldi   r24, 6
    mov   r14, r24
    clr   r15
.Lformat_float_decimal_precision_ready:
    lds   r24, data_format_conversion
    cpi   r24, 'g'
    breq  .Lformat_float_decimal_g_precision
    cpi   r24, 'G'
    brne  .Lformat_float_decimal_choose_engine
.Lformat_float_decimal_g_precision:
    mov   r24, r14
    or    r24, r15
    brne  .Lformat_float_decimal_choose_engine
    mov   r14, ONE
    clr   r15

.Lformat_float_decimal_choose_engine:
    lds   r26, data_format_conversion
    cpi   r26, 'f'
    breq  .Lformat_float_decimal_engine_f
    cpi   r26, 'e'
    breq  .Lformat_float_decimal_engine_e
    cpi   r26, 'E'
    breq  .Lformat_float_decimal_engine_e

    ; %g/%G: engine precision is min(significantPrecision-1, 7).
    ldi   r24, 7
    tst   r15
    brne  .Lformat_float_decimal_engine_g_ready
    mov   r24, r14
    dec   r24
    cpi   r24, 8
    brlo  .Lformat_float_decimal_engine_g_ready
    ldi   r24, 7
.Lformat_float_decimal_engine_g_ready:
    clr   r25                         ; no fixed max-digits restriction
    rcall format_float_call_decimal_engine
    mov   r26, r24
    inc   r26                         ; generated significant digit count
    sts   data_format_float_ndigits, r26
    rjmp  .Lformat_float_decimal_after_engine

.Lformat_float_decimal_engine_e:
    ldi   r24, 7
    tst   r15
    brne  .Lformat_float_decimal_engine_e_ready
    cp    r14, r24
    brsh  .Lformat_float_decimal_engine_e_ready
    mov   r24, r14
.Lformat_float_decimal_engine_e_ready:
    clr   r25
    rcall format_float_call_decimal_engine
    mov   r26, r24
    inc   r26
    sts   data_format_float_ndigits, r26
    rjmp  .Lformat_float_decimal_after_engine

.Lformat_float_decimal_engine_f:
    ; Fixed output asks the engine for eight meaningful digits and limits the
    ; useful digit horizon to min(precision+1, 60), matching avr-libc.
    ldi   r24, 7
    ldi   r25, 60
    tst   r15
    brne  .Lformat_float_decimal_engine_f_ready
    mov   r26, r14
    cpi   r26, 59
    brsh  .Lformat_float_decimal_engine_f_ready
    mov   r25, r14
    inc   r25
.Lformat_float_decimal_engine_f_ready:
    rcall format_float_call_decimal_engine

    ; ndigits = clamp(maxdgs + exp10 - carryAdjustment, 1, 8).
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    add   r20, r16
    adc   r21, ZERO
    lds   r26, data_format_float_flags
    sbrs  r26, 4                    ; FTOA_CARRY
    rjmp  .Lformat_float_f_ndigits_clamp
    lds   r26, data_format_digit_buffer+1
    cpi   r26, '1'
    brne  .Lformat_float_f_ndigits_clamp
    subi  r20, 1
    sbci  r21, 0
.Lformat_float_f_ndigits_clamp:
    tst   r21
    brmi  .Lformat_float_f_ndigits_one
    brne  .Lformat_float_f_ndigits_eight
    tst   r20
    breq  .Lformat_float_f_ndigits_one
    cpi   r20, 9
    brsh  .Lformat_float_f_ndigits_eight
    sts   data_format_float_ndigits, r20
    rjmp  .Lformat_float_decimal_after_engine
.Lformat_float_f_ndigits_one:
    sts   data_format_float_ndigits, ONE
    rjmp  .Lformat_float_decimal_after_engine
.Lformat_float_f_ndigits_eight:
    ldi   r26, 8
    sts   data_format_float_ndigits, r26

.Lformat_float_decimal_after_engine:
    rcall format_float_set_sign
    lds   r24, data_format_float_flags
    andi  r24, (FORMAT_FTOA_INF | FORMAT_FTOA_NAN)
    breq  1f
    rjmp  format_float_emit_special
1:
    lds   r24, data_format_conversion
    cpi   r24, 'f'
    breq  format_float_emit_fixed
    cpi   r24, 'e'
    breq  1f
    cpi   r24, 'E'
    brne  2f
1:
    rjmp   format_float_emit_exponential
2:
    rjmp  format_float_emit_general

; Inputs r24=engine precision (0-7), r25=fixed maxdgs (0 or 1-60).
; Return r24 unchanged for callers that need enginePrecision+1. Formatter flags
; in r18 and SREG.T are restored exactly. The engine itself preserves r14-r17
; and Y, including the formatter's precision, status, and selected sink state.
format_float_call_decimal_engine:
    push  r24                         ; retain the already bounded precision
    push  r18
    in    r0, SREG
    push  r0
    mov   r18, r24
    mov   r16, r25
    ldi   r20, lo8(data_format_digit_buffer)
    ldi   r21, hi8(data_format_digit_buffer)
    lds   r22, data_format_float_value+0
    lds   r23, data_format_float_value+1
    lds   r24, data_format_float_value+2
    lds   r25, data_format_float_value+3
    clr   r1
    rcall format_ftoa_engine
    sts   data_format_float_exponent+0, r24
    sts   data_format_float_exponent+1, r25
    lds   r24, data_format_digit_buffer+0
    sts   data_format_float_flags, r24
    pop   r0
    out   SREG, r0
    pop   r18

    pop   r24
    ret

; Render finite fixed form with precision r15:r14 and generated decimal digits
; described by data_format_float_exponent/data_format_float_ndigits.
format_float_emit_fixed:
    rcall format_float_store_precision
    ; content = max(exp10+1,1) + precision + optional point + sign.
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    tst   r21
    brmi  .Lformat_float_fixed_content_one_integer
    mov   r26, r20
    inc   r26
    rcall format_float_content_add_u8
    rjmp  .Lformat_float_fixed_content_point
.Lformat_float_fixed_content_one_integer:
    mov   r26, ONE
    rcall format_float_content_add_u8
.Lformat_float_fixed_content_point:
    lds   r26, data_format_float_precision+0
    lds   r27, data_format_float_precision+1
    or    r26, r27
    brne  .Lformat_float_fixed_content_has_point
    sbrs  r18, FORMAT_FLAG_ALT
    rjmp  .Lformat_float_fixed_content_sign
.Lformat_float_fixed_content_has_point:
    mov   r26, ONE
    rcall format_float_content_add_u8
.Lformat_float_fixed_content_sign:
    lds   r26, data_format_sign
    tst   r26
    breq  1f
    mov   r26, ONE
    rcall format_float_content_add_u8
1:
    rcall format_float_begin_decimal_field

    ; Integer portion.
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    tst   r21
    brpl  .Lformat_float_fixed_integer_nonnegative
    ldi   r24, '0'
    rcall format_emit_char
    rjmp  .Lformat_float_fixed_after_integer

.Lformat_float_fixed_integer_nonnegative:
    mov   r23, r20
    inc   r23                         ; total integer digits, <=39
    lds   r22, data_format_float_ndigits
    cp    r22, r23
    brlo  1f
    mov   r22, r23
1:
    mov   r19, r23
    sub   r19, r22                    ; trailing integer zero count
    ldi   r30, lo8(data_format_digit_buffer+1)
    ldi   r31, hi8(data_format_digit_buffer+1)
    mov   r24, r22
    clr   r25
    rcall format_float_veneer_emit_ram_span
    mov   r24, r19
    clr   r25
    rcall format_float_emit_zeroes

.Lformat_float_fixed_after_integer:
    rcall format_float_emit_point_if_needed

    ; Fractional portion. Precision zero has no bytes after the optional point.
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    or    r24, r25
    brne  1f
    rjmp   .Lformat_float_fixed_done
1:
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    tst   r21
    brmi  .Lformat_float_fixed_fraction_negative_exp

    ; Generated fractional digits begin at significant index exp10+1.
    mov   r22, r20
    inc   r22
    lds   r23, data_format_float_ndigits
    cp    r22, r23
    brsh  .Lformat_float_fixed_fraction_all_zero
    sub   r23, r22                    ; available meaningful fraction digits
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    tst   r25
    brne  1f
    cp    r24, r23
    brlo  2f
1:
    mov   r24, r23
    clr   r25
2:
    ldi   r30, lo8(data_format_digit_buffer+1)
    ldi   r31, hi8(data_format_digit_buffer+1)
    add   r30, r22
    adc   r31, ZERO
    mov   r19, r24                    ; preserved meaningful count, <=8
    rcall format_float_veneer_emit_ram_span
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    sub   r24, r19
    sbc   r25, ZERO
    rcall format_float_emit_zeroes
    rjmp  .Lformat_float_fixed_done

.Lformat_float_fixed_fraction_all_zero:
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    rcall format_float_emit_zeroes
    rjmp  .Lformat_float_fixed_done

.Lformat_float_fixed_fraction_negative_exp:
    ; Leading fractional zeros = -exp10-1, capped by precision.
    movw  r22, r20
    com   r22
    com   r23
    add   r22, ONE
    adc   r23, ZERO
    sub   r22, ONE
    sbc   r23, ZERO
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    cp    r24, r22
    cpc   r25, r23
    brsh  1f
    movw  r22, r24
1:
    ; Sink calls may repurpose r12-r15 and r20-r23. Preserve the leading
    ; zero count in the formatter workspace before emitting it.
    sts   data_format_precision_zeroes+0, r22
    sts   data_format_precision_zeroes+1, r23
    movw  r24, r22
    rcall format_float_emit_zeroes

    ; remaining = precision-leading. Compute both the meaningful digit count
    ; and the trailing synthetic-zero count before the span sink, then retain
    ; the latter in SRAM across text rendering.
    lds   r20, data_format_float_precision+0
    lds   r21, data_format_float_precision+1
    lds   r26, data_format_precision_zeroes+0
    lds   r27, data_format_precision_zeroes+1
    sub   r20, r26
    sbc   r21, r27
    mov   r24, r20
    or    r24, r21
    breq  .Lformat_float_fixed_done
    lds   r23, data_format_float_ndigits
    movw  r24, r20
    tst   r25
    brne  2f
    cp    r24, r23
    brlo  3f
2:
    mov   r24, r23
    clr   r25
3:
    movw  r26, r20
    sub   r26, r24
    sbc   r27, r25
    sts   data_format_precision_zeroes+0, r26
    sts   data_format_precision_zeroes+1, r27
    ldi   r30, lo8(data_format_digit_buffer+1)
    ldi   r31, hi8(data_format_digit_buffer+1)
    rcall format_float_veneer_emit_ram_span
    lds   r24, data_format_precision_zeroes+0
    lds   r25, data_format_precision_zeroes+1
    rcall format_float_emit_zeroes

.Lformat_float_fixed_done:
    rcall format_float_veneer_emit_post_padding
    rjmp   .Lformat_main_loop

; Render finite scientific form. r15:r14 is the requested number of digits
; after the radix point; generated digits beyond the first are followed by
; synthetic zeros as necessary.
format_float_emit_exponential:
    rcall format_float_store_precision
    ; content = precision + 5 (lead digit, exponent marker/sign/two digits)
    ; plus optional point and optional value sign.
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    ldi   r26, 5
    rcall format_float_content_add_u8
    lds   r26, data_format_float_precision+0
    lds   r27, data_format_float_precision+1
    or    r26, r27
    brne  .Lformat_float_exp_content_point
    sbrs  r18, FORMAT_FLAG_ALT
    rjmp  .Lformat_float_exp_content_sign
.Lformat_float_exp_content_point:
    mov   r26, ONE
    rcall format_float_content_add_u8
.Lformat_float_exp_content_sign:
    lds   r26, data_format_sign
    tst   r26
    breq  1f
    mov   r26, ONE
    rcall format_float_content_add_u8
1:
    rcall format_float_begin_decimal_field

    lds   r24, data_format_digit_buffer+1
    rcall format_emit_char
    rcall format_float_emit_point_if_needed

    lds   r20, data_format_float_precision+0
    lds   r21, data_format_float_precision+1
    mov   r24, r20
    or    r24, r21
    breq  .Lformat_float_exp_after_fraction
    lds   r23, data_format_float_ndigits
    dec   r23
    movw  r24, r20
    tst   r25
    brne  1f
    cp    r24, r23
    brlo  2f
1:
    mov   r24, r23
    clr   r25
2:
    mov   r19, r24
    ldi   r30, lo8(data_format_digit_buffer+2)
    ldi   r31, hi8(data_format_digit_buffer+2)
    rcall format_float_veneer_emit_ram_span
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    sub   r24, r19
    sbc   r25, ZERO
    rcall format_float_emit_zeroes

.Lformat_float_exp_after_fraction:
    lds   r24, data_format_conversion
    sbrs  r24, 5
    rjmp  .Lformat_float_exp_marker_upper
    ldi   r24, 'e'
    rjmp  .Lformat_float_exp_marker_emit
.Lformat_float_exp_marker_upper:
    ldi   r24, 'E'
.Lformat_float_exp_marker_emit:
    rcall format_emit_char
    rcall format_float_emit_decimal_exponent_two
    rcall format_float_veneer_emit_post_padding
    rjmp   .Lformat_main_loop

; Choose %g fixed/scientific style after rounding. Style selection uses the
; original significant precision; trimming only changes the rendered tail.
format_float_emit_general:
    ; r23 = effective significant digits after optional trailing-zero trim.
    lds   r23, data_format_float_ndigits
    sbrc  r18, FORMAT_FLAG_ALT
    rjmp  .Lformat_float_general_digits_ready
    ldi   r30, lo8(data_format_digit_buffer+1)
    ldi   r31, hi8(data_format_digit_buffer+1)
    add   r30, r23
    adc   r31, ZERO
.Lformat_float_general_trim_loop:
    cpi   r23, 1
    breq  .Lformat_float_general_digits_ready
    ld    r24, -Z
    cpi   r24, '0'
    brne  .Lformat_float_general_digits_ready
    dec   r23
    rjmp  .Lformat_float_general_trim_loop

.Lformat_float_general_digits_ready:
    ; Scientific iff exp10 < -4 or exp10 >= significant precision.
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    tst   r21
    brpl  .Lformat_float_general_nonnegative_exp
    cpi   r20, 0xfc
    ldi   r24, 0xff
    cpc   r21, r24
    brlt  .Lformat_float_general_scientific
    rjmp  .Lformat_float_general_fixed
.Lformat_float_general_nonnegative_exp:
    tst   r15
    brne  .Lformat_float_general_fixed
    cp    r20, r14
    brsh  .Lformat_float_general_scientific

.Lformat_float_general_fixed:
    ; Target fractional precision is significantDigits-(exp+1), floored at 0.
    ; Alternate form uses the full requested significant precision, including
    ; synthetic zeros beyond the engine's eight meaningful digits.
    sbrc  r18, FORMAT_FLAG_ALT
    rjmp  .Lformat_float_general_fixed_alt
    mov   r24, r23
    clr   r25
    rjmp  .Lformat_float_general_fixed_compute
.Lformat_float_general_fixed_alt:
    movw  r24, r14
.Lformat_float_general_fixed_compute:
    tst   r21
    brmi  .Lformat_float_general_fixed_negative_exp
    mov   r26, r20
    inc   r26
    sub   r24, r26
    sbc   r25, ZERO
    brcc  .Lformat_float_general_fixed_precision_ready
    clr   r24
    clr   r25
    rjmp  .Lformat_float_general_fixed_precision_ready
.Lformat_float_general_fixed_negative_exp:
    ; precision = significantDigits + (-exp-1), saturating.
    movw  r26, r20
    com   r26
    com   r27
    add   r26, ONE
    adc   r27, ZERO
    sub   r26, ONE
    sbc   r27, ZERO
    add   r24, r26
    adc   r25, r27
    brcc  .Lformat_float_general_fixed_precision_ready
    ser   r24
    ser   r25
    ori   r17, (1 << FORMAT_STATUS_COUNT_OVERFLOW)
.Lformat_float_general_fixed_precision_ready:
    movw  r14, r24
    rjmp  format_float_emit_fixed

.Lformat_float_general_scientific:
    sbrc  r18, FORMAT_FLAG_ALT
    rjmp  .Lformat_float_general_scientific_alt
    mov   r14, r23
    clr   r15
    rjmp  .Lformat_float_general_scientific_decrement
.Lformat_float_general_scientific_alt:
    ; r14:r15 already holds requested significant precision.
.Lformat_float_general_scientific_decrement:
    sub   r14, ONE
    sbc   r15, ZERO
    rjmp  format_float_emit_exponential

; Emit e/E exponent sign and exactly two digits. avr-libc retains a negative
; zero exponent when rounding carried a value from below one to 1.x.
format_float_emit_decimal_exponent_two:
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    tst   r21
    brmi  .Lformat_float_exp_two_negative
    mov   r24, r20
    or    r24, r21
    brne  .Lformat_float_exp_two_positive
    lds   r24, data_format_float_flags
    sbrs  r24, 4                    ; FTOA_CARRY
    rjmp  .Lformat_float_exp_two_positive
    lds   r24, data_format_digit_buffer+1
    cpi   r24, '1'
    brne  .Lformat_float_exp_two_positive
.Lformat_float_exp_two_negative:
    com   r20
    com   r21
    add   r20, ONE
    adc   r21, ZERO
    ldi   r26, '-'
    rjmp  .Lformat_float_exp_two_prepare
.Lformat_float_exp_two_positive:
    ldi   r26, '+'
.Lformat_float_exp_two_prepare:
    sts   data_format_prefix, r26
    ldi   r22, '0'
.Lformat_float_exp_two_tens_loop:
    cpi   r20, 10
    brlo  .Lformat_float_exp_two_digits_ready
    subi  r20, 10
    inc   r22
    rjmp  .Lformat_float_exp_two_tens_loop
.Lformat_float_exp_two_digits_ready:
    sts   data_format_digit_buffer+0, r22
    subi  r20, -'0'
    sts   data_format_digit_buffer+1, r20

    ; Compute the complete exponent spelling before the first sink call: text
    ; output is permitted to clobber all ordinary formatter scratch registers.
    lds   r24, data_format_prefix
    rcall format_emit_char
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    ldi   r24, 2
    clr   r25
    rjmp   format_float_veneer_emit_ram_span

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Exact hexadecimal a/A conversion
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;

format_conversion_float_hex:
    ; Decode sign, exponent, and fraction directly from the binary32 bits.
    lds   r20, data_format_float_value+0
    lds   r21, data_format_float_value+1
    lds   r22, data_format_float_value+2
    lds   r23, data_format_float_value+3
    clr   r24
    sbrc  r23, 7
    ori   r24, FORMAT_FTOA_MINUS

    mov   r25, r23
    lsl   r25
    sbrc  r22, 7
    ori   r25, 1                    ; complete exponent field
    mov   r26, r22
    andi  r26, 0x7f
    or    r26, r21
    or    r26, r20                  ; complete fraction nonzero test

    cpi   r25, 0xff
    brne  .Lformat_float_hex_not_special
    tst   r26
    breq  .Lformat_float_hex_inf
    ori   r24, FORMAT_FTOA_NAN
    rjmp  .Lformat_float_hex_special_store
.Lformat_float_hex_inf:
    ori   r24, FORMAT_FTOA_INF
.Lformat_float_hex_special_store:
    sts   data_format_float_flags, r24
    rcall format_float_set_sign
    rjmp  format_float_emit_special

.Lformat_float_hex_not_special:
    tst   r25
    brne  .Lformat_float_hex_normal
    tst   r26
    brne  .Lformat_float_hex_subnormal

    ; Signed zero uses leading digit zero and exponent +0.
    ori   r24, FORMAT_FTOA_ZERO
    sts   data_format_float_flags, r24
    sts   data_format_value_nonzero, ZERO
    sts   data_format_float_exponent+0, ZERO
    sts   data_format_float_exponent+1, ZERO
    sts   data_format_float_value+0, ZERO
    sts   data_format_float_value+1, ZERO
    sts   data_format_float_value+2, ZERO
    rjmp  .Lformat_float_hex_normalized

.Lformat_float_hex_normal:
    ; M = 1.fraction as a 24-bit integer; exponent = field-127.
    andi  r22, 0x7f
    ori   r22, 0x80
    mov   r26, r25
    subi  r26, 127
    clr   r27
    sbrc  r26, 7
    com   r27
    sts   data_format_value_nonzero, ONE
    rjmp  .Lformat_float_hex_store_normalized

.Lformat_float_hex_subnormal:
    ; Normalize the nonzero 23-bit fraction and decrement exponent from -126
    ; for each left shift needed to place the leading one in bit 23.
    andi  r22, 0x7f
    ldi   r26, 0x82
    ldi   r27, 0xff
.Lformat_float_hex_subnormal_loop:
    sbrc  r22, 7
    rjmp  .Lformat_float_hex_subnormal_ready
    lsl   r20
    rol   r21
    rol   r22
    subi  r26, 1
    sbci  r27, 0
    rjmp  .Lformat_float_hex_subnormal_loop
.Lformat_float_hex_subnormal_ready:
    sts   data_format_value_nonzero, ONE

.Lformat_float_hex_store_normalized:
    sts   data_format_float_value+0, r20
    sts   data_format_float_value+1, r21
    sts   data_format_float_value+2, r22
    sts   data_format_float_exponent+0, r26
    sts   data_format_float_exponent+1, r27
    sts   data_format_float_flags, r24

.Lformat_float_hex_normalized:
    rcall format_float_set_sign

    ; Explicit precisions below six round the normalized significand to a
    ; hexadecimal digit boundary. Six or more fraction digits are exact.
    sbrs  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_float_hex_generate_digits
    tst   r15
    brne  .Lformat_float_hex_generate_digits
    mov   r24, r14
    cpi   r24, 6
    brsh  .Lformat_float_hex_generate_digits
    lds   r24, data_format_value_nonzero
    tst   r24
    breq  .Lformat_float_hex_generate_digits
    rcall format_float_hex_round

.Lformat_float_hex_generate_digits:
    rcall format_float_hex_generate_six

    ; Omitted precision uses the shortest fraction-nibble suffix that still
    ; represents the rounded binary32 value exactly.
    sbrc  r18, FORMAT_FLAG_PRECISION
    rjmp  .Lformat_float_hex_precision_ready
    ldi   r24, 6
    mov   r14, r24
    clr   r15
    ldi   r30, lo8(data_format_digit_buffer+6)
    ldi   r31, hi8(data_format_digit_buffer+6)
.Lformat_float_hex_trim_loop:
    tst   r14
    breq  .Lformat_float_hex_precision_ready
    ld    r24, -Z
    cpi   r24, '0'
    brne  .Lformat_float_hex_precision_ready
    dec   r14
    rjmp  .Lformat_float_hex_trim_loop

.Lformat_float_hex_precision_ready:
    rcall format_float_store_precision
    ; Exponent digit count is one to three for binary32 (-149..+127).
    rcall format_float_hex_exponent_digit_count
    mov   r23, r24

    ; content = precision + 5 (0x, leading digit, p, exponent sign)
    ; + exponent digits + optional point + optional value sign.
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    ldi   r26, 5
    rcall format_float_content_add_u8
    mov   r26, r23
    rcall format_float_content_add_u8
    lds   r26, data_format_float_precision+0
    lds   r27, data_format_float_precision+1
    or    r26, r27
    brne  .Lformat_float_hex_content_point
    sbrs  r18, FORMAT_FLAG_ALT
    rjmp  .Lformat_float_hex_content_sign
.Lformat_float_hex_content_point:
    mov   r26, ONE
    rcall format_float_content_add_u8
.Lformat_float_hex_content_sign:
    lds   r26, data_format_sign
    tst   r26
    breq  1f
    mov   r26, ONE
    rcall format_float_content_add_u8
1:
    rcall format_float_begin_hex_field

    lds   r24, data_format_value_nonzero
    tst   r24
    breq  .Lformat_float_hex_emit_zero_lead
    ldi   r24, '1'
    rjmp  .Lformat_float_hex_emit_lead
.Lformat_float_hex_emit_zero_lead:
    ldi   r24, '0'
.Lformat_float_hex_emit_lead:
    rcall format_emit_char
    rcall format_float_emit_point_if_needed

    ; Emit up to the six exact fraction nibbles, then synthesize any explicit
    ; precision beyond the binary32 significand.
    lds   r20, data_format_float_precision+0
    lds   r21, data_format_float_precision+1
    mov   r24, r20
    or    r24, r21
    breq  .Lformat_float_hex_after_fraction
    ldi   r22, 6
    movw  r24, r20
    tst   r25
    brne  1f
    cp    r24, r22
    brlo  2f
1:
    mov   r24, r22
    clr   r25
2:
    mov   r19, r24
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    rcall format_float_veneer_emit_ram_span
    lds   r24, data_format_float_precision+0
    lds   r25, data_format_float_precision+1
    sub   r24, r19
    sbc   r25, ZERO
    rcall format_float_emit_zeroes

.Lformat_float_hex_after_fraction:
    lds   r24, data_format_conversion
    sbrs  r24, 5
    rjmp  .Lformat_float_hex_marker_upper
    ldi   r24, 'p'
    rjmp  .Lformat_float_hex_marker_emit
.Lformat_float_hex_marker_upper:
    ldi   r24, 'P'
.Lformat_float_hex_marker_emit:
    rcall format_emit_char
    rcall format_float_emit_hex_exponent
    rcall format_float_veneer_emit_post_padding
    jmp   .Lformat_main_loop

; Round normalized 24-bit significand at data_format_float_value to explicit
; hexadecimal precision r14 (0-5), ties to even. A carry renormalizes to 1.0
; and increments the stored binary exponent.
format_float_hex_round:
    lds   r20, data_format_float_value+0
    lds   r21, data_format_float_value+1
    lds   r22, data_format_float_value+2
    mov   r24, r14
    lsl   r24
    lsl   r24
    ldi   r25, 23
    sub   r25, r24                    ; discarded low-bit count
    mov   r23, r25                    ; retain for realignment
    clr   r26                         ; sticky
.Lformat_float_hex_round_shift_right:
    lsr   r22
    ror   r21
    ror   r20
    dec   r25
    breq  .Lformat_float_hex_round_guard
    brcc  .Lformat_float_hex_round_shift_right
    mov   r26, ONE
    rjmp  .Lformat_float_hex_round_shift_right
.Lformat_float_hex_round_guard:
    clr   r27
    brcc  .Lformat_float_hex_round_decide
    mov   r27, ONE                    ; guard
.Lformat_float_hex_round_decide:
    tst   r27
    breq  .Lformat_float_hex_round_realign
    tst   r26
    brne  .Lformat_float_hex_round_up
    sbrs  r20, 0                      ; ties to even
    rjmp  .Lformat_float_hex_round_realign
.Lformat_float_hex_round_up:
    add   r20, ONE
    adc   r21, ZERO
    adc   r22, ZERO

.Lformat_float_hex_round_realign:
    clr   r27                         ; overflow beyond bit 23
    mov   r25, r23
.Lformat_float_hex_round_shift_left:
    lsl   r20
    rol   r21
    rol   r22
    brcc  1f
    mov   r27, ONE
1:
    dec   r25
    brne  .Lformat_float_hex_round_shift_left
    tst   r27
    breq  .Lformat_float_hex_round_store
    clr   r20
    clr   r21
    ldi   r22, 0x80
    lds   r24, data_format_float_exponent+0
    lds   r25, data_format_float_exponent+1
    add   r24, ONE
    adc   r25, ZERO
    sts   data_format_float_exponent+0, r24
    sts   data_format_float_exponent+1, r25
.Lformat_float_hex_round_store:
    sts   data_format_float_value+0, r20
    sts   data_format_float_value+1, r21
    sts   data_format_float_value+2, r22
    ret

; Convert the 23 fraction bits, padded with one low zero, into six forward hex
; digits in data_format_digit_buffer. Shift out the implicit leading bit once,
; then emit two nibbles from each of the three bytes. r20-r23 are scratch.
format_float_hex_generate_six:
    lds   r20, data_format_float_value+0
    lds   r21, data_format_float_value+1
    lds   r22, data_format_float_value+2
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)

    lsl   r20
    rol   r21
    rol   r22
    ldi   r23, 3
.Lformat_float_hex_byte_loop:
    mov   r26, r22
    swap  r26
    andi  r26, 0x0f
    rcall format_float_hex_nibble_to_char
    st    Z+, r26

    mov   r26, r22
    andi  r26, 0x0f
    rcall format_float_hex_nibble_to_char
    st    Z+, r26
    mov   r22, r21
    mov   r21, r20
    dec   r23
    brne  .Lformat_float_hex_byte_loop
    ret
format_float_hex_generate_six_end:
.if (format_float_hex_generate_six_end - format_float_hex_generate_six) != 52
    .error "hexadecimal fraction digit generator must occupy twenty-six AVR words"
.endif

format_float_hex_nibble_to_char:
    cpi   r26, 10
    brlo  .Lformat_float_hex_numeric_nibble
    lds   r24, data_format_conversion
    sbrs  r24, 5
    rjmp  .Lformat_float_hex_upper_nibble
    subi  r26, -87
    ret
.Lformat_float_hex_upper_nibble:
    subi  r26, -55
    ret
.Lformat_float_hex_numeric_nibble:
    subi  r26, -'0'
    ret

; Return exponent decimal digit count (1-3) in r24.
format_float_hex_exponent_digit_count:
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    tst   r21
    brpl  1f
    com   r20
    com   r21
    add   r20, ONE
    adc   r21, ZERO
1:
    ldi   r24, 1
    cpi   r20, 10
    brlo  2f
    inc   r24
    cpi   r20, 100
    brlo  2f
    inc   r24
2:
    ret

; Emit p/P exponent sign and the minimal one-to-three decimal digits.
format_float_emit_hex_exponent:
    lds   r20, data_format_float_exponent+0
    lds   r21, data_format_float_exponent+1
    tst   r21
    brpl  .Lformat_float_hex_exp_positive
    com   r20
    com   r21
    add   r20, ONE
    adc   r21, ZERO
    ldi   r26, '-'
    rjmp  .Lformat_float_hex_exp_prepare
.Lformat_float_hex_exp_positive:
    ldi   r26, '+'
.Lformat_float_hex_exp_prepare:
    sts   data_format_prefix, r26
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    clr   r23                         ; generated exponent digit count

    clr   r22                         ; hundreds digit
.Lformat_float_hex_exp_hundreds_loop:
    cpi   r20, 100
    brlo  .Lformat_float_hex_exp_hundreds_done
    subi  r20, 100
    inc   r22
    rjmp  .Lformat_float_hex_exp_hundreds_loop
.Lformat_float_hex_exp_hundreds_done:
    tst   r22
    breq  .Lformat_float_hex_exp_tens_prepare
    subi  r22, -'0'
    st    Z+, r22
    inc   r23
    ldi   r22, 1                      ; force a tens digit after hundreds
    rjmp  .Lformat_float_hex_exp_tens_init
.Lformat_float_hex_exp_tens_prepare:
    clr   r22                         ; no higher digit yet
.Lformat_float_hex_exp_tens_init:
    clr   r26                         ; numeric tens digit
.Lformat_float_hex_exp_tens_loop:
    cpi   r20, 10
    brlo  .Lformat_float_hex_exp_tens_done
    subi  r20, 10
    inc   r26
    rjmp  .Lformat_float_hex_exp_tens_loop
.Lformat_float_hex_exp_tens_done:
    tst   r22
    brne  .Lformat_float_hex_exp_store_tens
    tst   r26
    breq  .Lformat_float_hex_exp_store_ones
.Lformat_float_hex_exp_store_tens:
    subi  r26, -'0'
    st    Z+, r26
    inc   r23
.Lformat_float_hex_exp_store_ones:
    subi  r20, -'0'
    st    Z, r20
    inc   r23
    sts   data_format_float_ndigits, r23

    ; The exponent bytes are fully materialized before entering the sink. The
    ; digit count is retained in SRAM because a text glyph may clobber r20-r23.
    lds   r24, data_format_prefix
    rcall format_emit_char
    ldi   r30, lo8(data_format_digit_buffer)
    ldi   r31, hi8(data_format_digit_buffer)
    lds   r24, data_format_float_ndigits
    clr   r25
    rjmp   format_float_veneer_emit_ram_span

;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Formatter-local avr-libc decimal digit engine
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
;
; Adapted from avr-libc libc/stdlib/ftoa_engine.S (Dmitry Xmelkov, 2005).
; Input ABI is unchanged:
;   r22-r25 binary32, r20:r21 output buffer, r18 precision-1, r16 maxdgs.
; The routine returns signed decimal exponent in r25:r24 and writes a flags byte
; followed by up to eight digits. Native r1 is zero on entry and exit.

.macro format_ftoa_lpm_zplus reg
    lpm   \reg, Z+
.endm

.macro format_ftoa_lpm_z reg
    lpm   \reg, Z
.endm

format_ftoa_engine:
    cpi   r18, 8
    brlo  .Lformat_ftoa_precision_ready
    ldi   r18, 7
.Lformat_ftoa_precision_ready:
    clr   r19
    movw  r26, r20
    lsl   r25
    adc   r19, r1
    sbrc  r24, 7
    ori   r25, 1
    adiw  r24, 0
    cpc   r22, r1
    cpc   r23, r1
    brne  .Lformat_ftoa_nonzero

    ori   r19, FORMAT_FTOA_ZERO
    subi  r18, -2
.Lformat_ftoa_zero_loop:
    st    X+, r19
    ldi   r19, '0'
    dec   r18
    brne  .Lformat_ftoa_zero_loop
    ret

.Lformat_ftoa_nonzero:
    cpi   r25, 0xff
    brlo  .Lformat_ftoa_class_ready
    cpi   r24, 0x80
    cpc   r23, r1
    cpc   r22, r1
    breq  .Lformat_ftoa_inf
    subi  r19, -FORMAT_FTOA_INF       ; NAN = 2*INF
.Lformat_ftoa_inf:
    subi  r19, -FORMAT_FTOA_INF
.Lformat_ftoa_class_ready:
    st    X+, r19
    cpi   r25, 1
    brlo  1f
    ori   r24, 0x80
1:
    adc   r25, r1
    push  r29
    push  r28
    push  r17
    push  r16
    push  r15
    push  r14

    mov   r17, r25
    andi  r25, 0xf8
    lsr   r25
    mov   r30, r25
    lsr   r25
    lsr   r25
    add   r30, r25
    clr   r31
    subi  r30, lo8(-(format_ftoa_base10))
    sbci  r31, hi8(-(format_ftoa_base10))
    clr   r25
    clr   r19
    clr   r14
    clr   r15
    movw  r20, r14
    movw  r28, r14

    format_ftoa_lpm_zplus r0
    sec
    ror   r0
.Lformat_ftoa_mul_byte0:
    brcc  1f
    add   r19, r22
    adc   r14, r23
    adc   r15, r24
    adc   r20, r25
    adc   r21, r1
1:
    lsl   r22
    rol   r23
    rol   r24
    rol   r25
    lsr   r0
    brne  .Lformat_ftoa_mul_byte0

    format_ftoa_lpm_zplus r0
    sec
    ror   r0
.Lformat_ftoa_mul_byte1:
    brcc  1f
    add   r14, r23
    adc   r15, r24
    adc   r20, r25
    adc   r21, r22
    adc   r28, r1
1:
    lsl   r23
    rol   r24
    rol   r25
    rol   r22
    lsr   r0
    brne  .Lformat_ftoa_mul_byte1

    format_ftoa_lpm_zplus r0
    sec
    ror   r0
.Lformat_ftoa_mul_byte2:
    brcc  1f
    add   r15, r24
    adc   r20, r25
    adc   r21, r22
    adc   r28, r23
    adc   r29, r1
1:
    lsl   r24
    rol   r25
    rol   r22
    rol   r23
    lsr   r0
    brne  .Lformat_ftoa_mul_byte2

    format_ftoa_lpm_zplus r0
    sec
    ror   r0
.Lformat_ftoa_mul_byte3:
    brcc  1f
    add   r20, r25
    adc   r21, r22
    adc   r28, r23
    adc   r29, r24
1:
    lsl   r25
    rol   r22
    rol   r23
    rol   r24
    lsr   r0
    brne  .Lformat_ftoa_mul_byte3

    format_ftoa_lpm_z r24
    com   r17
    andi  r17, 7
    breq  .Lformat_ftoa_scaled
.Lformat_ftoa_scale_loop:
    lsr   r29
    ror   r28
    ror   r21
    ror   r20
    ror   r15
    ror   r14
    dec   r17
    brne  .Lformat_ftoa_scale_loop
.Lformat_ftoa_scaled:

    ldi   r30, lo8(format_ftoa_powr10)
    ldi   r31, hi8(format_ftoa_powr10)
    set
.Lformat_ftoa_digit:
    format_ftoa_lpm_zplus r1
    format_ftoa_lpm_zplus r17
    format_ftoa_lpm_zplus r19
    format_ftoa_lpm_zplus r22
    format_ftoa_lpm_zplus r25
    format_ftoa_lpm_zplus r0
    ldi   r23, '0'-1
.Lformat_ftoa_subtract_digit:
    inc   r23
    sub   r14, r1
    sbc   r15, r17
    sbc   r20, r19
    sbc   r21, r22
    sbc   r28, r25
    sbc   r29, r0
    brsh  .Lformat_ftoa_subtract_digit
    add   r14, r1
    adc   r15, r17
    adc   r20, r19
    adc   r21, r22
    adc   r28, r25
    adc   r29, r0
    brtc  .Lformat_ftoa_store_digit
    cpi   r23, '0'
    brne  .Lformat_ftoa_first_digit
    dec   r24
    rjmp  .Lformat_ftoa_digit
.Lformat_ftoa_first_digit:
    clt
    subi  r16, 1
    brlo  .Lformat_ftoa_digit_count_ready
    add   r16, r24
    brpl  1f
    clr   r16
1:
    cp    r16, r18
    brsh  .Lformat_ftoa_digit_count_ready
    mov   r18, r16
.Lformat_ftoa_digit_count_ready:
    inc   r18
    mov   r16, r18

.Lformat_ftoa_store_digit:
    cpi   r23, '0'+10
    brlo  .Lformat_ftoa_write_digit
    ldi   r23, '9'
.Lformat_ftoa_fill_nines:
    st    X+, r23
    dec   r18
    brne  .Lformat_ftoa_fill_nines
    rjmp  .Lformat_ftoa_round_up
.Lformat_ftoa_write_digit:
    st    X+, r23
    dec   r18
    brne  .Lformat_ftoa_digit

    ; Round against half the final power-of-ten element.
    lsr   r0
    ror   r25
    ror   r22
    ror   r19
    ror   r17
    ror   r1
    sub   r14, r1
    sbc   r15, r17
    sbc   r20, r19
    sbc   r21, r22
    sbc   r28, r25
    sbc   r29, r0
    brlo  .Lformat_ftoa_restore

.Lformat_ftoa_round_up:
    inc   r18
.Lformat_ftoa_round_loop:
    ld    r23, -X
    inc   r23
    cpi   r23, '9'+1
    brlo  1f
    ldi   r23, '0'
1:
    st    X, r23
    cpse  r18, r16
    brsh  .Lformat_ftoa_round_up
    ld    r23, -X
    ori   r23, FORMAT_FTOA_CARRY
    st    X+, r23
    brlo  .Lformat_ftoa_restore
    inc   r24
    ldi   r23, '1'
.Lformat_ftoa_round_overflow_fill:
    st    X+, r23
    ldi   r23, '0'
    dec   r18
    brne  .Lformat_ftoa_round_overflow_fill

.Lformat_ftoa_restore:
    clr   r1
    pop   r14
    pop   r15
    pop   r16
    pop   r17
    pop   r28
    pop   r29
    clr   r25
    sbrc  r24, 7
    com   r25
    ret

; Powers used by the decimal digit extractor. Keep powr10 first for subnormal
; rounding stability, as in avr-libc.
format_ftoa_powr10:
    .byte 0, 64, 122, 16, 243, 90
    .byte 0, 160, 114, 78, 24, 9
    .byte 0, 16, 165, 212, 232, 0
    .byte 0, 232, 118, 72, 23, 0
    .byte 0, 228, 11, 84, 2, 0
    .byte 0, 202, 154, 59, 0, 0
    .byte 0, 225, 245, 5, 0, 0
    .byte 128, 150, 152, 0, 0, 0
    .byte 64, 66, 15, 0, 0, 0
    .byte 160, 134, 1, 0, 0, 0
    .byte 16, 39, 0, 0, 0, 0
    .byte 232, 3, 0, 0, 0, 0
    .byte 100, 0, 0, 0, 0, 0
    .byte 10, 0, 0, 0, 0, 0
    .byte 1, 0, 0, 0, 0, 0

format_ftoa_base10:
    .byte 44, 118, 216, 136, -36
    .byte 103, 79, 8, 35, -33
    .byte 193, 223, 174, 89, -31
    .byte 177, 183, 150, 229, -29
    .byte 228, 83, 198, 58, -26
    .byte 81, 153, 118, 150, -24
    .byte 230, 194, 132, 38, -21
    .byte 137, 140, 155, 98, -19
    .byte 64, 124, 111, 252, -17
    .byte 188, 156, 159, 64, -14
    .byte 186, 165, 111, 165, -12
    .byte 144, 5, 90, 42, -9
    .byte 92, 147, 107, 108, -7
    .byte 103, 109, 193, 27, -4
    .byte 224, 228, 13, 71, -2
    .byte 245, 32, 230, 181, 0
    .byte 208, 237, 144, 46, 3
    .byte 0, 148, 53, 119, 5
    .byte 0, 128, 132, 30, 8
    .byte 0, 0, 32, 78, 10
    .byte 0, 0, 0, 200, 12
    .byte 51, 51, 51, 51, 15
    .byte 152, 110, 18, 131, 17
    .byte 65, 239, 141, 33, 20
    .byte 137, 59, 230, 85, 22
    .byte 207, 254, 230, 219, 24
    .byte 209, 132, 75, 56, 27
    .byte 247, 124, 29, 144, 29
    .byte 164, 187, 228, 36, 32
    .byte 50, 132, 114, 94, 34
    .byte 129, 0, 201, 241, 36
    .byte 236, 161, 229, 61, 39
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
; Mixed one/two-bit music. Only the foreground touches FX; the interrupt
; consumes compressed bytes, never a decoded PCM queue. Each frame restarts
; from its signed seed and contains at most 256 output samples.
;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;;
.macro audio_save
    push r16
    push r17
    push r18
    push r19
    push r20
    push r21
    push r22
    push r23
.endm
.macro audio_restore
    pop r23
    pop r22
    pop r21
    pop r20
    pop r19
    pop r18
    pop r17
    pop r16
.endm

audio_service_func:
    sts  data_audio_ticks_pending, ZERO
    lds  r24, data_audio_status
    tst  r24
    breq 1f
    audio_save
    rcall audio_refill
    audio_restore
1:
    ret

; Single producer; publish head only after all bytes have arrived. Interrupts
; stay enabled through the shared SPI reader. Never read past the payload.
audio_refill:
    lds  r16, data_audio_write
    lds  r24, data_audio_read
    mov  r17, r16
    sub  r17, r24
    ldi  r18, 64
    sub  r18, r17
    brne 9f
    rjmp .Laudio_refill_done
9:
    cpi  r18, 33
    brlo 1f
    ldi  r18, 32
1:
    mov  r17, r16
    andi r17, 63
    ldi  r24, 64
    sub  r24, r17
    cp   r18, r24
    brlo 1f
    mov  r18, r24
1:
    lds  r19, data_audio_bytes
    lds  r20, data_audio_bytes+1
    lds  r21, data_audio_bytes+2
    mov  r24, r19
    or   r24, r20
    or   r24, r21
    brne .Laudio_refill_length
    lds  r24, data_audio_flags
    sbrs r24, 0
    rjmp .Laudio_refill_done
    lds  r19, data_audio_length
    lds  r20, data_audio_length+1
    lds  r21, data_audio_length+2
    lds  r24, data_audio_start
    lds  r25, data_audio_start+1
    lds  r26, data_audio_start+2
    sts  data_audio_cursor, r24
    sts  data_audio_cursor+1, r25
    sts  data_audio_cursor+2, r26
.Laudio_refill_length:
    tst  r20
    brne 1f
    tst  r21
    brne 1f
    cp   r18, r19
    brlo 1f
    mov  r18, r19
1:
    sub  r19, r18
    sbc  r20, ZERO
    sbc  r21, ZERO
    sts  data_audio_bytes, r19
    sts  data_audio_bytes+1, r20
    sts  data_audio_bytes+2, r21
    lds  r24, data_audio_cursor
    lds  r25, data_audio_cursor+1
    lds  r26, data_audio_cursor+2
    mov  r19, r24
    mov  r20, r25
    mov  r21, r26
    add  r19, r18
    adc  r20, ZERO
    adc  r21, ZERO
    sts  data_audio_cursor, r19
    sts  data_audio_cursor+1, r20
    sts  data_audio_cursor+2, r21
    ldi  r30, lo8(data_audio_ring)
    ldi  r31, hi8(data_audio_ring)
    add  r30, r17
    mov  r0, r18
    mov  r1, ZERO
    call fx_read_program_bytes_func
    add  r16, r18
    sts  data_audio_write, r16
    rjmp audio_refill
.Laudio_refill_done:
    ret

; SYS 0x38. Legacy SFX/tone/rate command numbers are reserved and ignored.
; PLAY expects AVM1: magic[4], payload_bytes:u24, flags:u8 (bit0 loop),
; sample_count:u32, then unchanged AVAX mixed-256 frame payload.
sys_audio_impl:
    fx_disable
    audio_save
    mov  r24, VM_R7L
    tst  r24
    brne 9f
    rjmp .Laudio_play
9:
    cpi  r24, 2
    breq .Laudio_stop
    cpi  r24, 3
    breq .Laudio_pause
    cpi  r24, 4
    breq .Laudio_resume
    cpi  r24, 5
    breq .Laudio_volume
    cpi  r24, 11
    breq .Laudio_volume
    cpi  r24, 6
    breq .Laudio_enable_command
    cpi  r24, 7
    breq .Laudio_disable
    cpi  r24, 9
    breq .Laudio_status
    rjmp .Laudio_command_done
.Laudio_stop:
    sts  data_audio_status, ZERO
    sts  data_audio_ticks_pending, ZERO
    rjmp .Laudio_silence
.Laudio_pause:
    lds  r24, data_audio_status
    cpi  r24, 1
    brne .Laudio_command_done
    ldi  r24, 2
    sts  data_audio_status, r24
    rjmp .Laudio_silence
.Laudio_resume:
    lds  r24, data_audio_status
    cpi  r24, 2
    brne .Laudio_command_done
    sts  data_audio_status, ONE
    rjmp .Laudio_command_done
.Laudio_volume:
    sts  data_audio_volume, VM_R4L
    rjmp .Laudio_command_done
.Laudio_enable_command:
    rcall audio_enable
    rjmp .Laudio_command_done
.Laudio_disable:
    sts  data_audio_status, ZERO
    sts  data_audio_ticks_pending, ZERO
    in   r25, SREG
    cli
    sts  TIMSK1, ZERO
    sts  TCCR1B, ZERO
    sts  TCCR4A, ZERO
    sts  TCCR4B, ZERO
    cbi  PORTC, 6
    cbi  PORTC, 7
    out  SREG, r25
.Laudio_silence:
    ldi  r24, 128
    sts  data_audio_sample, r24
    rjmp .Laudio_command_done
.Laudio_status:
    lds  r24, data_audio_status
    audio_restore
    mov  VM_R4L, r24
    mov  VM_R4H, ZERO
    jmp seek_and_dispatch_func_disabled
.Laudio_command_done:
    audio_restore
    jmp seek_and_dispatch_func_disabled

.Laudio_play:
    sts  data_audio_status, ZERO ; ISR cannot see partially installed state
    mov  r24, VM_R4L
    mov  r25, VM_R4H
    mov  r26, VM_R5L
    subi r16, lo8(-12)
    sbci r17, hi8(-12)
    sbci r18, hlo8(-12)
    sts  data_audio_start, r16
    sts  data_audio_start+1, r17
    sts  data_audio_start+2, r18
    sts  data_audio_cursor, r16
    sts  data_audio_cursor+1, r17
    sts  data_audio_cursor+2, r18
    ldi  r30, lo8(data_audio_header)
    ldi  r31, hi8(data_audio_header)
    ldi  r16, 12
    mov  r0, r16
    mov  r1, ZERO
    call fx_read_program_bytes_func
    ldi  r30, lo8(data_audio_header)
    ldi  r31, hi8(data_audio_header)
    ld   r24, Z+
    cpi  r24, 'A'
    breq 9f
    rjmp .Laudio_bad_header
9:
    ld   r24, Z+
    cpi  r24, 'V'
    breq 9f
    rjmp .Laudio_bad_header
9:
    ld   r24, Z+
    cpi  r24, 'M'
    breq 9f
    rjmp .Laudio_bad_header
9:
    ld   r24, Z+
    cpi  r24, '1'
    breq 9f
    rjmp .Laudio_bad_header
9:
    clr  r25
    .set audio_i, 0
    .rept 3
        ld   r24, Z+
        sts  data_audio_bytes+audio_i, r24
        sts  data_audio_length+audio_i, r24
        or   r25, r24
        .set audio_i, audio_i+1
    .endr
    tst  r25
    brne 9f
    rjmp .Laudio_bad_header
9:
    ld   r24, Z+
    cpi  r24, 2
    brlo 9f
    rjmp .Laudio_bad_header
9:
    sts  data_audio_flags, r24
    clr  r25
    .set audio_i, 0
    .rept 4
        ld   r24, Z+
        sts  data_audio_remaining+audio_i, r24
        sts  data_audio_total+audio_i, r24
        or   r25, r24
        .set audio_i, audio_i+1
    .endr
    tst  r25
    brne 9f
    rjmp .Laudio_bad_header
9:
    sts  data_audio_read, ZERO
    sts  data_audio_write, ZERO
    sts  data_audio_frame_left, ZERO
    sts  data_audio_bits, ZERO
    sts  data_audio_bit_count, ZERO
    sts  data_audio_underruns, ZERO
    sts  data_audio_ticks_pending, ZERO
    ldi  r24, 128
    sts  data_audio_sample, r24
    rcall audio_refill
    sts  data_audio_status, ONE
    rcall audio_enable
    rjmp .Laudio_command_done
.Laudio_bad_header:
    rjmp .Laudio_stop

audio_enable:
    lds  r24, TIMSK1
    tst  r24
    brne 1f
    in   r25, SREG
    cli
    sts  TC4H, ZERO
    ldi  r24, 128
    sts  OCR4A, r24
    sts  data_audio_sample, r24
    sbi  DDRC, 6
    sbi  DDRC, 7
    ldi  r24, (_BV(COM4A0) | _BV(PWM4A))
    sts  TCCR4A, r24
    ldi  r24, _BV(CS40)
    sts  TCCR4B, r24
    rcall audio_timer1_start
    out  SREG, r25
1:
    ret

; Called with interrupts disabled; preserves r25 (saved SREG).
audio_timer1_start:
    ldi  r24, (_BV(WGM12) | _BV(CS11))
    sts  TCCR1B, r24
    ; Both clocks share a prescaler: Timer0 ticks every 64 CPU cycles, Timer1
    ; every 8. Seed Timer1 from Timer0's coarse phase instead of call timing.
    ; Eight cycles from the TCNT0 read to the TCNT1L latch (STS's second cycle) put
    ; audio deadlines 64..120 cycles after clock deadlines modulo 128, clear
    ; of Timer0's ISR. Keep this sequence's instruction timing unchanged.
    ; Do not reset the shared prescaler or alter the millisecond counter.
    sts  TCNT1H, ZERO
audio_enable_phase:
    in   r24, TCNT0
    lsl  r24
    lsl  r24
    lsl  r24
    andi r24, 127
    nop
    nop
    sts  TCNT1L, r24
    ldi  r24, _BV(OCF1A)
    out  TIFR1, r24
    ldi  r24, _BV(OCIE1A)
    sts  TIMSK1, r24
    ret

; Timer0 compare-A fires once per millisecond. Preserve the interrupted native
; state; the VM register file may be live in any AVR register when this runs.
timer0_compa_isr:
    push r0
    in   r0, SREG
    push r0

    lds  r0, data_millis+0
    inc  r0
    sts  data_millis+0, r0
    brne timer0_compa_isr_done

    lds  r0, data_millis+1
    inc  r0
    sts  data_millis+1, r0
    brne timer0_compa_isr_done

    lds  r0, data_millis+2
    inc  r0
    sts  data_millis+2, r0
    brne timer0_compa_isr_done

    lds  r0, data_millis+3
    inc  r0
    sts  data_millis+3, r0

timer0_compa_isr_done:
    pop  r0
    out  SREG, r0
    pop  r0
    reti

; Timer1 emits the held PWM value at a fixed 14-cycle body latency, then
; decodes exactly one signed PCM8 sample. No SPI, guest zero-register use,
; frame-sized PCM scratch, or unbounded work occurs in this interrupt.
timer1_compa_isr:
    push r0
    in   r0, SREG
    push r0
    push r20
timer1_synthesis:
    lds  r20, data_audio_sample
    clr  r0
    sts  TC4H, r0
timer1_endpoint_write:
    sts  OCR4A, r20
    push r1
    push r21
    push r22
    push r23
    push r24
    push r25
    push r26
    push r27
    push r30
    push r31
    lds  r20, data_audio_status
    cpi  r20, 1
    breq 1f
    rjmp .Laudio_isr_silence
1:
    lds  r20, data_audio_remaining
    lds  r21, data_audio_remaining+1
    lds  r22, data_audio_remaining+2
    lds  r23, data_audio_remaining+3
    or   r20, r21
    or   r20, r22
    or   r20, r23
    brne .Laudio_decode_sample
    lds  r20, data_audio_flags
    sbrs r20, 0
    rjmp .Laudio_isr_stop
    .set audio_i, 0
    .rept 4
        lds  r20, data_audio_total+audio_i
        sts  data_audio_remaining+audio_i, r20
        .set audio_i, audio_i+1
    .endr
    clr  r20
    sts  data_audio_frame_left, r20
.Laudio_decode_sample:
    lds  r20, data_audio_write
    lds  r21, data_audio_read
    sub  r20, r21
    cpi  r20, 33
    brsh 1f
    ldi  r21, 1
    sts  data_audio_ticks_pending, r21
1:
    lds  r21, data_audio_frame_left
    tst  r21
    brne .Laudio_residual
    cpi  r20, 2
    brsh 1f
    rjmp .Laudio_underrun
1:
    lds  r21, data_audio_bits
    tst  r21
    breq 1f
    rjmp .Laudio_isr_stop ; nonzero frame padding
1:
    rcall audio_pop
    mov  r20, r24
    rcall audio_pop
    mov  r22, r24
    andi r22, 0xc0
    cpi  r22, 0xc0
    breq .Laudio_invalid_frame
    mov  r22, r24
    andi r22, 0x30
    cpi  r22, 0x30
    breq .Laudio_invalid_frame
    cpi  r24, 0x40
    brsh 1f
    tst  r24
    brne .Laudio_invalid_frame ; hold parameter must be zero
1:
    sts  data_audio_parameter, r24
    mov  r30, r24
    andi r30, 15
    subi r30, lo8(-audio_steps)
    ldi  r31, hi8(audio_steps)
    lpm  r21, Z
    sts  data_audio_step, r21
    ldi  r21, 255
    sts  data_audio_frame_left, r21
    clr  r21
    sts  data_audio_bit_count, r21
    sts  data_audio_older, r20
    rjmp .Laudio_store_sample
.Laudio_invalid_frame:
    rjmp .Laudio_isr_stop
.Laudio_residual:
    lds  r23, data_audio_parameter
    cpi  r23, 0x40
    brsh .Laudio_read_symbol
    lds  r20, data_audio_previous
    rjmp .Laudio_residual_done
.Laudio_read_symbol:
    lds  r22, data_audio_bit_count
    tst  r22
    brne 1f
    tst  r20
    brne 2f
    rjmp .Laudio_underrun
2:
    rcall audio_pop
    sts  data_audio_bits, r24
    ldi  r22, 8
1:
    lds  r24, data_audio_bits
    mov  r21, r24
    andi r21, 3
    lsr  r24
    dec  r22
    sbrs r23, 7
    rjmp .Laudio_one_bit
    lsr  r24
    dec  r22
    rjmp .Laudio_symbol_ready
.Laudio_one_bit:
    andi r21, 1
    inc  r21 ; binary -S/+S maps to two-bit symbols 1/2
.Laudio_symbol_ready:
    sts  data_audio_bits, r24
    sts  data_audio_bit_count, r22
    mov  r22, r21
    lds  r20, data_audio_previous
    clr  r21
    sbrc r20, 7
    ser  r21
    andi r23, 0x30
    breq .Laudio_prediction_ready
    mov  r24, r20
    mov  r25, r21
    lds  r26, data_audio_older
    clr  r27
    sbrc r26, 7
    ser  r27
    sub  r24, r26
    sbc  r25, r27
    sbrs r23, 5
    rjmp 1f
    asr  r25
    ror  r24 ; floor(half slope), including negative odd slopes
1:
    add  r20, r24
    adc  r21, r25
.Laudio_prediction_ready:
    lds  r23, data_audio_step
    mov  r24, r23
    cpi  r22, 1
    breq 1f
    cpi  r22, 2
    breq 1f
    lsl  r24
    add  r24, r23 ; largest canonical 3*S is 126
1:
    clr  r25
    cpi  r22, 2
    brsh 1f
    neg  r24
    ser  r25
1:
    add  r20, r24
    adc  r21, r25
    tst  r21
    breq .Laudio_nonnegative
    cpi  r21, 255
    brne .Laudio_clamp
    sbrc r20, 7
    rjmp .Laudio_history
    rjmp .Laudio_clamp
.Laudio_nonnegative:
    sbrs r20, 7
    rjmp .Laudio_history
.Laudio_clamp:
    ldi  r20, 127
    sbrc r21, 7
    ldi  r20, 128
.Laudio_history:
    lds  r21, data_audio_previous
    sts  data_audio_older, r21
.Laudio_residual_done:
    lds  r21, data_audio_frame_left
    dec  r21
    sts  data_audio_frame_left, r21
.Laudio_store_sample:
    sts  data_audio_previous, r20
    ; Gain is applied after history reconstruction. Doubling the product's
    ; signed high byte detects overflow before the /128 conversion.
    lds  r21, data_audio_volume
    mulsu r20, r21
    mov  r20, r1
    lsl  r20
    brvs .Laudio_gain_clip
    clr  r21
    lsl  r0
    adc  r20, r21
    rjmp .Laudio_gain_bias
.Laudio_gain_clip:
    ldi  r20, 127
    sbrc r1, 7
    ldi  r20, 128
.Laudio_gain_bias:
    subi r20, 128
    sts  data_audio_sample, r20
    lds  r20, data_audio_remaining
    subi r20, 1
    sts  data_audio_remaining, r20
    brcc .Laudio_isr_done
    lds  r20, data_audio_remaining+1
    sbci r20, 0
    sts  data_audio_remaining+1, r20
    brcc .Laudio_isr_done
    lds  r20, data_audio_remaining+2
    sbci r20, 0
    sts  data_audio_remaining+2, r20
    brcc .Laudio_isr_done
    lds  r20, data_audio_remaining+3
    sbci r20, 0
    sts  data_audio_remaining+3, r20
    rjmp .Laudio_isr_done
.Laudio_underrun:
    lds  r20, data_audio_underruns
    cpi  r20, 255
    breq .Laudio_isr_silence
    inc  r20
    sts  data_audio_underruns, r20
    rjmp .Laudio_isr_silence
.Laudio_isr_stop:
    clr  r20
    sts  data_audio_status, r20
    sts  data_audio_ticks_pending, r20
.Laudio_isr_silence:
    ldi  r20, 128
    sts  data_audio_sample, r20
.Laudio_isr_done:
    pop  r31
    pop  r30
    pop  r27
    pop  r26
    pop  r25
    pop  r24
    pop  r23
    pop  r22
    pop  r21
    pop  r1
timer1_output_done:
    pop  r20
    pop  r0
    out  SREG, r0
    pop  r0
    reti

; ISR-only pop. Caller has checked availability for the complete operation.
; uint8 head wrap is independent of the physical ring's 64-byte wrap.
audio_pop:
    lds  r25, data_audio_read
    mov  r30, r25
    andi r30, 63
    subi r30, lo8(-data_audio_ring)
    ldi  r31, hi8(data_audio_ring)
    ld   r24, Z
    inc  r25
    sts  data_audio_read, r25
    ret

; Startup-only zero writes, in order. All timers below are stopped and masked
; before their remaining controls are reset. All addresses fit in data page 0;
; TC4H is cleared before writing TCNT4 and the Timer4 compare registers.
audio_init_zero_registers:
    .byte TCCR3B, TIMSK3, TCCR3A, TCCR3C
    .byte TCCR1B, TIMSK1, TCCR1A, TCCR1C, OCR1AH
    .byte TCCR4B, TIMSK4, TCCR4A, TCCR4C, TCCR4D, TCCR4E
    .byte DT4, TC4H, TCNT4
audio_init_zero_registers_end:

; Startup only, interrupts off. 96 MHz VCO / 1.5 = 64 MHz Timer4;
; USB postcaler remains 48 MHz (96 / 2). Datasheet sections 6.11 and 15.
audio_init_func:
    ldi  r24, _BV(PINDIV)
    out  PLLCSR, r24
    ldi  r24, 0x6a
    out  PLLFRQ, r24
    ldi  r24, (_BV(PINDIV) | _BV(PLLE))
    out  PLLCSR, r24
    ; Wait at least 100 us before checking lock, as required by Timer4.
    ldi  r24, 240 ; 1679 cycles = 104.9 us
1:
    delay_4
    dec  r24
    brne 1b
1:
    in   r24, PLLCSR
    sbrs r24, PLOCK
    rjmp 1b
    ; Timer0 initialization already cleared Timer1's power gate in PRR0.
    lds  r24, PRR1
    andi r24, (0xff ^ _BV(PRTIM4))
    sts  PRR1, r24
    ldi  r30, lo8(audio_init_zero_registers)
    ldi  r31, hi8(audio_init_zero_registers)
    ldi  r27, 0
    ldi  r24, (audio_init_zero_registers_end-audio_init_zero_registers)
1:
    lpm  r26, Z+
    st   X, ZERO
    dec  r24
    brne 1b
    ldi  r24, 127 ; 16 MHz / 8 / 128 = 15625 output samples/s
    sts  OCR1AL, r24
    cbi  PORTC, 6
    cbi  PORTC, 7
    cbi  DDRC, 6
    cbi  DDRC, 7
    ldi  r24, 255 ; Timer4 retains its 250 kHz carrier and 8-bit duty range
    sts  OCR4C, r24
    ldi  r24, 128
    sts  OCR4A, r24
    ldi  r24, 128 ; signed PCM8 unity gain (volume / 128)
    sts  data_audio_volume, r24
    ret
