# Streamed music demo

This example plays a small deterministic mixed one/two-bit music stream with
256-sample frames at 15,625 Hz while animating the display. A restarts the
loop; B pauses/resumes. Sound effects and synthesized tones are removed.

Build from the repository root (RelWithDebInfo):

```sh
cmake --build build --config RelWithDebInfo --target avm_audio_demo
```

The build refreshes `audio_demo.arduboy`. The tracked `music.h` allows SDK
builds without Python. `generate_music.py` reproduces that synthetic fixture;
`audio_demo_assets` runs it. To use a recording, run the SDK's
`avm_audio_pack.py song.avax music.h --loop --name music` on a mixed-256 AVAX
file from the evaluation harness. See [the audio guide](../../docs/audio.md).
