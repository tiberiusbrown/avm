"""Regenerate the small deterministic mixed-256 playback demonstration."""

import runpy
from pathlib import Path

root = Path(__file__).resolve().parent
packer = runpy.run_path(str(root.parents[1] / "tools/avm_audio_pack.py"))
payload = bytearray()
for i in range(96):
    payload += bytes([0, 0x40 + (i // 24) % 3 * 16 + 4])
    payload += bytes([0x55 if i % 2 else 0xAA]) * 31 + bytes([0x55 if i % 2 else 0x2A])
data = packer["native_asset"](payload, 96 * 256, True)
(root / "music.h").write_text(
    packer["c_array"](data, "music"), encoding="utf-8", newline="\n"
)
