"""Create a >64 KiB mixed-codec exporter fixture for C and C++."""

import runpy
import sys
from pathlib import Path

packer = runpy.run_path(
    str(Path(__file__).resolve().parents[2] / "tools/avm_audio_pack.py")
)
payload = bytes([17, 0]) * 33000
data = packer["native_asset"](payload, 33000 * 256, True)
output = Path(sys.argv[1])
output.parent.mkdir(parents=True, exist_ok=True)
output.write_text(packer["c_array"](data, "long_song"), encoding="utf-8")
