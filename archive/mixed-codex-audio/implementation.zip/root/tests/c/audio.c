#include <avm.h>
#include <math.h>
#include <stdio.h>
#include <string.h>

/* Looping 256-sample hold frame. Native format length includes payload only. */
static const uint8_t AVM_PROGMEM song[] = {
    'A','V','M','1', 2,0,0,1, 0,1,0,0, 17,0
};

int avm_test_main(void) {
    char text[48];
    avm_audio_play(song);
    if(avm_audio_status()!=1) return 1;
    uint16_t start=avm_millis();
    for(unsigned i=0;i<100;++i) {
        /* Native libm borrows the usual zero register. Timer ISRs must work
           while it is nonzero and the formatter workspace must stay safe. */
        volatile float angle=0.25f;
        float value=sinf(angle);
        if(value<0.24f || value>0.25f) return 2;
        snprintf(text,sizeof(text),"%lu %.2f",(unsigned long)i,(double)value);
        size_t length=strlen(text);
        if(length<4 || memcmp(text+length-4,"0.25",4)!=0) return 3;
    }
    if(avm_audio_status()!=1 || avm_millis()==start) return 4;
    avm_audio_pause();
    if(avm_audio_status()!=2) return 5;
    avm_audio_resume();
    if(avm_audio_status()!=1) return 6;
    avm_audio_volume(16);
    avm_audio_music_volume(128);
    if(avm_audio_status()!=1) return 7;
    avm_audio_stop();
    if(avm_audio_status()!=0) return 8;
    avm_audio_disable();
    return 0;
}
