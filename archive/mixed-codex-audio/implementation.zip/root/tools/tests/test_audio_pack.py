"""Native packaging agrees with the independently decoded experimental format."""

import struct
import sys
from pathlib import Path

import numpy as np
import pytest

sys.path.insert(0, str(Path(__file__).resolve().parents[1]))
from avm_audio.extended import ExtendedFormat, decode_extended
from avm_audio_pack import c_array, decode_payload, native_asset, pack_avax


@pytest.mark.parametrize("count", [1, 2, 7, 255, 256, 257, 511])
@pytest.mark.parametrize("parameter", [0, *range(0x40, 0x70), *range(0x80, 0xB0)])
def test_native_exact_payload(count, parameter):
    payload = bytearray()
    width = parameter >> 6
    for start in range(0, count, 256):
        payload += bytes([0x80 if start else 0x7F, parameter])
        bits = (min(256, count - start) - 1) * width
        payload += ((1 << bits) - 1).to_bytes((bits + 7) // 8, "little")
    avax = ExtendedFormat(6, 256, count).header() + payload
    native = pack_avax(avax, True)
    assert native[12:] == payload
    assert native[7] == 1
    assert struct.unpack_from("<I", native, 8)[0] == count
    reference, _, _ = decode_extended(avax)
    np.testing.assert_array_equal(list(decode_payload(native[12:], count)), reference)


@pytest.mark.parametrize("parameter", [1, 16, 48, 63, 0x70, 0xB0, 0xC0, 0xFF])
def test_invalid_parameters(parameter):
    with pytest.raises(ValueError):
        native_asset(bytes([0, parameter]), 1)


def test_bad_lengths_padding_and_header():
    for payload, count in [
        (b"", 1),
        (b"\0", 1),
        (b"\0\x80", 2),
        (b"\0\x80\xff", 2),
        (b"\0\0\0", 1),
        (b"\0\0", 0),
    ]:
        with pytest.raises(ValueError):
            native_asset(payload, count)
    good = ExtendedFormat(6, 256, 1).header() + b"\0\0"
    for at in range(34):
        if at == 10:  # A hold frame can legitimately contain 129 samples.
            continue
        bad = bytearray(good)
        bad[at] ^= 128
        with pytest.raises(ValueError):
            pack_avax(bad)


def test_large_c_array_has_no_internal_padding():
    data = native_asset(b"\x11\0" * 33000, 33000 * 256, True)
    text = c_array(data, "long_song")
    assert "part_0[8191]" in text and "part_1[" in text
    assert "#define long_song (&long_song_storage)" in text
    for name in ("", "0song", "bad-name", "song;", "two words"):
        with pytest.raises(ValueError):
            c_array(data, name)
