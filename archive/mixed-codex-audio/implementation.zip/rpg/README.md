# AVM Wayfarer — Nocturne Grove

C++20 exploration on the 128x64 Arduboy AVM display, with 16x16 terrain and
alpha-masked characters. D-pad moves, A reads the sign immediately north of the
starting position, and B opens the status/save menu. Two sample villagers show
standing and wandering characters using different rows of the actor atlas.

The soundtrack uses the two recordings evaluated by the codec harness,
encoded with mixed one/two-bit prediction and 256-sample frames at 15,625 Hz.
Both tracks loop. The six synthesized songs have been removed.

| Song | Target bits/sample | Native bytes | Duration |
|---|---:|---:|---:|
| TownTheme (default) | 1.75 | 333,030 | 97.454016 s |
| determined_pursuit_loop | 1.25 | 263,622 | 108 s |

Press **B**, choose **Switch music** (or press Up twice from Status), and press
**A** to alternate between the recordings. New Game and Continue start with
TownTheme; the selected title appears in the menu footer. Music continues
through dialogue and menus; the title screen stays silent. **B**, **Up**, **A**
pauses or resumes music. Playback always uses 15,625 Hz. The initial music gain
is 128 (unity); sound effects and synthesized tones are not supported.

The tracked `.avax` assets are the exact evaluated streams. Packaging removes
their general-purpose header, adds a native length/loop header, and copies
all compressed frames unchanged. See [asset provenance](assets/music/README.md).

The old outdoor/interior/hall maps and their quests have been replaced by one
18x12-tile forest clearing. **This development build rejects saves from versions
1–3.** Its save format is version 4; new saves still use 24 bytes.

- `assets/maps/outdoor.tmx`: authoritative sample map, collision and native handler anchors.
- `assets/tilesets/world.tsx`: row-major tile IDs, symbols and solidity.
- `assets_src/tiles16.png`: opaque 256x256 atlas; IDs 0x00–0xFE are usable.
- `assets_src/actors16.png`: 16 character rows, 12 frames per row, binary alpha.
- `src/logic/`: sign dialogue and sample NPC definitions, separate from generic mechanics.
- `assets/music/*.avax`: the two encoded recordings. `tools/generate_music.py`
  uses the SDK's `avm_audio_pack.py` to rebuild `generated/music.h` and
  `music_catalog.h`; no encoding or audio dependencies are needed at build time.
- `generated/`: deterministic program-memory assets and compile-time handler dispatch.
- `rpg.arduboy`: Arduboy FX package, refreshed by the default build.
- `rpg.fxc.arduboy`: Arduboy FX-C package, built from the same game with FX-C
  interpreter firmware (flash chip select on HWB/PE2), also refreshed by default.

The bottom-right atlas cell (0xFF) is reserved for the impassable outside-map
sentinel. Black cells retain their indices. Characters use direction order
north/east/south/west, rest on frame 1, and walk through 1,2,1,3.
Chunks cover 8x4 tiles; a 9x5 cache supports smooth scrolling and uses 108 fewer
RAM bytes than the previous 17x9 cache.

The installed SDK must include `bin/avm/interp.fxc.hex`. Update an older SDK
with the AVM checkout's `avm_sdk_install` CMake target before building.

From this repository root:

```powershell
./tools/build.ps1 -SdkRoot ../../build/avm-sdk-install
cmake --build build --config RelWithDebInfo --target rpg_integration
cmake --build build --config RelWithDebInfo --target rpg_audio_timing
python tools/collect_evidence.py --build build --write-docs
```

Audio uses Timer1 for output and predictive decoding at 15,625 Hz,
with the separate 1 kHz Timer0 clock. The optional full-device build also provides
`rpg_audio_timing`. It measures
Timer1 entry lateness, PWM write intervals, decoder cadence, ISR execution
time, and foreground interrupt-disabled spans in the packaged game. The full
run covers a complete song plus dialogue, menus, saving, walking, and collision;
it also checks FXC and calibrates against known NOP/CLI workloads. CSV and JSON
distributions are written to `build/audio-timing`; matplotlib adds PNG/SVG plots.
CTest's `audio_timing` runs shorter two-second gameplay windows. See
[the timing investigation](docs/audio_timing.md) for measured results and definitions.

See [Tiled/asset pipeline](docs/tiled_pipeline.md), [world architecture](docs/chunk_world.md),
[NPC mechanics](docs/essential_npcs.md) and [current measurements](docs/tiles16_measurements.md).
The M0 proof is an independent historical API diagnostic and retains its tiny test art.
