# Recorded soundtrack

These are the exact mixed-256 encodings selected from the AVM below-two-bit
experiments on the user-supplied Downloads files `TownTheme.mp3` and
`determined_pursuit_loop.wav`. TownTheme targets 1.75 bits/sample; pursuit targets
1.25 bits/sample. The source audio was converted to the shared 15,625 Hz mono
signed PCM8 reference without normalization. The source files are not required
to build the game. `manifest.json` records source and compressed-file hashes,
sample counts, sizes and actual rates. Both native assets loop at unity gain.

The source experiment artifacts were
`build/audio-codec-results/<song>/below2/mixed/mixed_f256_target<rate>.avax`.
The encoder search and measured quality are documented in
[the below-two-bit report](../../../../docs/audio-codec-below2-results.md).
`tools/generate_music.py` packages their unchanged frame payloads with the
SDK's standard-library-only `avm_audio_pack.py`. Native containers are 22 bytes
smaller than AVAX, without any additional audio loss.
