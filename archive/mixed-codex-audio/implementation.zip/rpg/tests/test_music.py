"""Verify the exact evaluated recordings, bitrate, and generated music bank."""

import argparse
import hashlib
import runpy
import struct
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "tools"))
from generate_music import SONGS, generate, generate_catalog

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument("--compiler", type=Path, required=True)
args = parser.parse_args()
packer = runpy.run_path(str(args.compiler))
assert (ROOT / "generated/music.h").read_text(encoding="utf-8") == generate(
    args.compiler
)
assert (ROOT / "generated/music_catalog.h").read_text(
    encoding="utf-8"
) == generate_catalog()
assert SONGS == ("TownTheme", "determined_pursuit_loop")
assert {p.name for p in (ROOT / "assets/music").glob("*.avax")} == {
    f"{s}.avax" for s in SONGS
}
assert not list((ROOT / "assets/music").glob("*.avms"))
for song, count, target, expected_hash in (
    (
        "TownTheme",
        1522719,
        1.75,
        "51587391e7a77d6f86f3defcd9c358ebda7766dd5cc5803147558d9d98442019",
    ),
    (
        "determined_pursuit_loop",
        1687500,
        1.25,
        "c80d74e121a5ef3eb96828009b42b9cf636d16db4c603737c0e780b7583ce961",
    ),
):
    source = (ROOT / f"assets/music/{song}.avax").read_bytes()
    assert hashlib.sha256(source).hexdigest() == expected_hash, (
        "evaluated stream changed"
    )
    assert struct.unpack_from("<I", source, 10)[0] == count
    assert target - 0.001 < len(source) * 8 / count <= target
    packed = packer["pack_avax"](source, loop=True)
    assert packed[:4] == b"AVM1" and packed[7] == 1
    assert packed[12:] == source[34:], "packaging changed codec payload"
    assert int.from_bytes(packed[4:7], "little") == len(packed) - 12
    assert struct.unpack_from("<I", packed, 8)[0] == count
    assert sum(1 for _ in packer["decode_payload"](packed[12:], count)) == count
    print(
        f"{song}: {count} samples, {len(packed)} native bytes, {len(packed) * 8 / count:.6f} bits/sample"
    )
print("two-track mixed-256 music bank verified")
